"""
CREST-NIDS Training & Evaluation — v4.1
NEW: AblationStudy class for systematic component ablation
"""
import os
import time
import json
import math
import copy
import numpy as np
from tqdm import tqdm
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR
from sklearn.metrics import (accuracy_score, f1_score, precision_score, recall_score,
                             roc_auc_score, roc_curve)
from config import *


class FocalLoss(nn.Module):
    def __init__(self, gamma=FOCAL_GAMMA, alpha=FOCAL_ALPHA, label_smoothing=LABEL_SMOOTHING,
                 weight=None):
        super().__init__()
        self.gamma = gamma
        self.label_smoothing = label_smoothing
        self.weight = weight
    
    def forward(self, logits, targets):
        num_classes = logits.size(-1)
        if self.label_smoothing > 0:
            with torch.no_grad():
                smooth = torch.zeros_like(logits)
                smooth.fill_(self.label_smoothing / (num_classes - 1))
                smooth.scatter_(1, targets.unsqueeze(1), 1.0 - self.label_smoothing)
        
        log_probs = F.log_softmax(logits, dim=-1)
        probs = torch.exp(log_probs)
        
        if self.label_smoothing > 0:
            focal_w = (1 - probs) ** self.gamma
            loss = -(focal_w * smooth * log_probs)
            if self.weight is not None:
                loss = loss * self.weight[targets].unsqueeze(1)
            return loss.mean()
        else:
            target_probs = probs.gather(1, targets.unsqueeze(1)).squeeze(1)
            focal_w = (1 - target_probs) ** self.gamma
            ce = F.cross_entropy(logits, targets, weight=self.weight, reduction='none')
            return (focal_w * ce).mean()


class Trainer:
    def __init__(self, model, train_loader, val_loader, class_weights=None, 
                 output_dir='./outputs', ablation_config=None):
        self.model = model.to(DEVICE)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.output_dir = output_dir
        self.ablation = ablation_config or {}
        os.makedirs(output_dir, exist_ok=True)
        
        self.criterion = FocalLoss(weight=class_weights)
        self.binary_criterion = nn.BCEWithLogitsLoss()
        self.optimizer = Adam(model.parameters(), lr=LR_INIT, weight_decay=1e-5)
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=MAX_EPOCHS, eta_min=LR_MIN)
        
        self.best_f1 = 0.0
        self.patience_counter = 0
        
        # Ablation overrides
        self._lambda = self.ablation.get('lambda', LAMBDA)
        self._mu = self.ablation.get('mu', MU)
        self._nu = self.ablation.get('nu', NU)
    
    def warmup_weight(self, epoch):
        return min(1.0, epoch / WARMUP_EPOCHS) if WARMUP_EPOCHS > 0 else 1.0
    
    def train_epoch(self, epoch):
        self.model.train()
        total_loss = 0
        total_ce = 0
        total_const = 0
        correct = 0
        total = 0
        w = self.warmup_weight(epoch)
        
        for X, y in self.train_loader:
            X, y = X.to(DEVICE), y.to(DEVICE)
            outputs = self.model(X, labels=y)
            
            l_ce = self.criterion(outputs['logits'], y)
            binary_targets = (y > 0).float()
            l_binary = self.binary_criterion(outputs['binary_logits'], binary_targets)
            l_const = outputs['constraint_energy']
            l_bind = outputs['binding_loss']
            l_cycle = outputs['cycle_loss']
            
            loss = (l_ce
                    + BINARY_WEIGHT * l_binary
                    + self._lambda * w * l_const
                    + self._mu * w * l_bind
                    + self._nu * l_cycle)
            
            self.optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += loss.item()
            total_ce += l_ce.item()
            total_const += (l_const.item() if isinstance(l_const, torch.Tensor) else l_const)
            preds = outputs['logits'].argmax(dim=-1)
            correct += (preds == y).sum().item()
            total += y.size(0)
        
        self.scheduler.step()
        n = len(self.train_loader)
        return {'loss': total_loss/n, 'l_ce': total_ce/n, 'l_const': total_const/n,
                'accuracy': correct/total, 'lr': self.optimizer.param_groups[0]['lr']}
    
    @torch.no_grad()
    def validate(self):
        self.model.eval()
        all_preds, all_labels = [], []
        for X, y in self.val_loader:
            X, y = X.to(DEVICE), y.to(DEVICE)
            preds = self.model(X)['logits'].argmax(dim=-1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(y.cpu().numpy())
        
        return {
            'accuracy': accuracy_score(all_labels, all_preds),
            'f1_macro': f1_score(all_labels, all_preds, average='macro', zero_division=0)
        }
    
    def train(self):
        ablation_tag = self.ablation.get('name', 'full')
        print(f"\n{'='*70}")
        print(f"CREST-NIDS Training [{ablation_tag}]")
        print(f"{'='*70}")
        
        params = self.model.count_parameters()
        for k, v in params.items():
            print(f"  {k}: {v:,}")
        print(f"  λ={self._lambda}, μ={self._mu}, ν={self._nu}")
        print(f"{'='*70}\n")
        
        start = time.time()
        for epoch in range(1, MAX_EPOCHS + 1):
            t0 = time.time()
            tm = self.train_epoch(epoch)
            vm = self.validate()
            dt = time.time() - t0
            
            print(f"Epoch {epoch:3d}/{MAX_EPOCHS} | "
                  f"L={tm['loss']:.4f} CE={tm['l_ce']:.4f} Cst={tm['l_const']:.4f} | "
                  f"TrAcc={tm['accuracy']:.4f} VAcc={vm['accuracy']:.4f} VF1={vm['f1_macro']:.4f} | "
                  f"lr={tm['lr']:.2e} | {dt:.0f}s")
            
            if vm['f1_macro'] > self.best_f1:
                self.best_f1 = vm['f1_macro']
                self.patience_counter = 0
                torch.save(self.model.state_dict(),
                          os.path.join(self.output_dir, f'best_{ablation_tag}.pt'))
                print(f"  → Best (F1={self.best_f1:.4f})")
            else:
                self.patience_counter += 1
            
            if self.patience_counter >= PATIENCE:
                print(f"\nEarly stop at epoch {epoch}")
                break
        
        print(f"\nDone in {time.time()-start:.0f}s")
        self.model.load_state_dict(
            torch.load(os.path.join(self.output_dir, f'best_{ablation_tag}.pt'), map_location=DEVICE, weights_only=True))
        return self.model


class Evaluator:
    def __init__(self, model, test_loader, osr_loader, class_names, class_to_idx,
                 rules, output_dir='./outputs', tag='full'):
        self.model = model.to(DEVICE)
        self.model.eval()
        self.test_loader = test_loader
        self.osr_loader = osr_loader
        self.class_names = class_names
        self.class_to_idx = class_to_idx
        self.rules = rules
        self.output_dir = output_dir
        self.tag = tag
        self.results = {}
    
    @torch.no_grad()
    def evaluate_detection(self):
        print(f"\n{'='*60}\n1. DETECTION [{self.tag}]\n{'='*60}")
        all_preds, all_labels, all_probs = [], [], []
        
        for X, y in self.test_loader:
            X, y = X.to(DEVICE), y.to(DEVICE)
            out = self.model(X)
            probs = F.softmax(out['logits'], dim=-1)
            all_preds.extend(out['logits'].argmax(-1).cpu().numpy())
            all_labels.extend(y.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
        
        P, L, Pr = np.array(all_preds), np.array(all_labels), np.array(all_probs)
        
        acc = accuracy_score(L, P)
        f1m = f1_score(L, P, average='macro', zero_division=0)
        f1w = f1_score(L, P, average='weighted', zero_division=0)
        prec = precision_score(L, P, average='macro', zero_division=0)
        rec = recall_score(L, P, average='macro', zero_division=0)
        
        try:
            valid = [c for c in np.unique(L) if (L == c).sum() >= 2]
            if len(valid) > 1:
                mask = np.isin(L, valid)
                auc = roc_auc_score(L[mask], Pr[mask][:, valid], multi_class='ovr', labels=valid)
            else:
                auc = 0.0
        except:
            auc = 0.0
        
        fn = ((P == 0) & (L != 0)).sum()
        for_rate = fn / ((P == 0).sum() + 1e-8)
        
        r = {'accuracy': acc, 'f1_macro': f1m, 'f1_weighted': f1w,
             'precision': prec, 'recall': rec, 'auc_roc': auc, 'FOR': for_rate}
        for k, v in r.items():
            print(f"  {k:16s}: {v:.4f}")
        self.results['detection'] = r
        return r
    
    @torch.no_grad()
    def evaluate_interpretability(self):
        print(f"\n{'='*60}\n2. INTERPRETABILITY [{self.tag}]\n{'='*60}")
        rule_E = {r['name']: [] for r in self.rules}
        concept_H, active_C = [], []
        
        for X, y in self.test_loader:
            X, y = X.to(DEVICE), y.to(DEVICE)
            out = self.model(X, labels=y)
            for name, e in out['rule_energies'].items():
                rule_E[name].append(e)
            if out['concept_entropy'] is not None:
                concept_H.append(out['concept_entropy'].item())
            cw = out['concept_weights']
            active_C.append((cw > 1.0/NUM_CONCEPTS).float().sum(-1).mean().item())
        
        sat = 0
        for name, energies in rule_E.items():
            me = np.mean(energies) if energies else 0.0
            ok = me < 0.01
            sat += ok
            print(f"    {'✓' if ok else '✗'} {name}: energy={me:.4f}")
        
        kb_sat = sat / len(self.rules) * 100 if self.rules else 100.0
        avg_H = np.mean(concept_H) if concept_H else 0.0
        avg_A = np.mean(active_C) if active_C else 0.0
        
        print(f"  KB Satisfaction: {kb_sat:.2f}%")
        print(f"  Active Concepts: {avg_A:.0f}")
        print(f"  Concept Entropy: {avg_H:.3f}")
        self.results['interpretability'] = {'kb_satisfaction': kb_sat, 'active_concepts': avg_A, 'concept_entropy': avg_H}
    
    def evaluate_adversarial(self):
        print(f"\n{'='*60}\n3. ADVERSARIAL [{self.tag}]\n{'='*60}")
        clean = self.results.get('detection', {}).get('accuracy', 0)
        print(f"  Clean: {clean:.4f}")
        r = {}
        for eps in FGSM_EPSILONS:
            fa = self._fgsm(eps)
            pa = self._pgd(eps)
            print(f"  ε={eps}: FGSM={fa:.4f} (↓{clean-fa:.4f})  PGD={pa:.4f} (↓{clean-pa:.4f})")
            r[f'fgsm_{eps}'] = fa
            r[f'pgd_{eps}'] = pa
        self.results['adversarial'] = r
    
    def _fgsm(self, eps):
        correct, total = 0, 0
        for X, y in tqdm(self.test_loader, desc=f'    FGSM ε={eps}', leave=False):
            X, y = X.to(DEVICE), y.to(DEVICE)
            X.requires_grad = True
            loss = F.cross_entropy(self.model(X)['logits'], y)
            self.model.zero_grad()
            loss.backward()
            Xa = X + eps * X.grad.sign()
            with torch.no_grad():
                correct += (self.model(Xa)['logits'].argmax(-1) == y).sum().item()
                total += len(y)
        return correct / total
    
    def _pgd(self, eps):
        correct, total = 0, 0
        for X, y in tqdm(self.test_loader, desc=f'    PGD  ε={eps}', leave=False):
            X, y = X.to(DEVICE), y.to(DEVICE)
            Xo = X.clone()
            Xa = X.clone() + torch.randn_like(X) * 0.001
            for _ in range(PGD_STEPS):
                Xa.requires_grad = True
                loss = F.cross_entropy(self.model(Xa)['logits'], y)
                self.model.zero_grad()
                loss.backward()
                Xa = Xa.detach() + PGD_ALPHA * Xa.grad.sign()
                Xa = Xo + torch.clamp(Xa - Xo, -eps, eps)
            with torch.no_grad():
                correct += (self.model(Xa)['logits'].argmax(-1) == y).sum().item()
                total += len(y)
        return correct / total
    
    @torch.no_grad()
    def evaluate_osr(self):
        print(f"\n{'='*60}\n4. OSR [{self.tag}]\n{'='*60}")
        if self.osr_loader is None:
            print("  No OSR holdout — skipping")
            self.results['osr'] = {}
            return
        
        known, unknown = [], []
        for X, _ in self.test_loader:
            known.extend(self.model(X.to(DEVICE))['osr_score'].cpu().numpy())
        for X, _ in self.osr_loader:
            unknown.extend(self.model(X.to(DEVICE))['osr_score'].cpu().numpy())
        
        known, unknown = np.array(known), np.array(unknown)
        all_s = np.concatenate([known, unknown])
        all_l = np.concatenate([np.zeros(len(known)), np.ones(len(unknown))])
        
        try:
            auc = roc_auc_score(all_l, all_s)
            fpr, tpr, thr = roc_curve(all_l, all_s)
            best_t = thr[(tpr - fpr).argmax()]
        except:
            auc, best_t = 0.0, 0.5
        
        tp = (unknown >= best_t).sum()
        fp = (known >= best_t).sum()
        fn = len(unknown) - tp
        osr_p = tp / (tp + fp + 1e-8)
        osr_r = tp / (tp + fn + 1e-8)
        osr_f1 = 2 * osr_p * osr_r / (osr_p + osr_r + 1e-8)
        
        r = {'auc_roc': auc, 'precision': osr_p, 'recall': osr_r, 'f1': osr_f1,
             'known_mean': known.mean(), 'unknown_mean': unknown.mean(),
             'gap': unknown.mean() - known.mean(), 'threshold': best_t}
        for k, v in r.items():
            print(f"  {k:20s}: {v:.4f}")
        self.results['osr'] = r
    
    def run_full_evaluation(self):
        self.evaluate_detection()
        self.evaluate_interpretability()
        self.evaluate_adversarial()
        self.evaluate_osr()
        
        path = os.path.join(self.output_dir, f'report_{self.tag}.json')
        with open(path, 'w') as f:
            json.dump(self.results, f, indent=2, default=lambda x: float(x) if isinstance(x, (np.floating, np.integer)) else str(x))
        print(f"\nReport saved: {path}")
        return self.results


# ============================================================
# NEW: Ablation Study
# ============================================================

ABLATION_CONFIGS = {
    'full': {},                                              # Full CREST-NIDS
    'no_constraint': {'lambda': 0.0, 'mu': 0.0},            # No Module B
    'no_binding': {'mu': 0.0, 'nu': 0.0},                   # No binding/cycle from Module C
    'no_hierarchy': {},                                       # No binary head (flag only)
    'no_kb': {'lambda': 0.0},                                # No KB constraints, keep binding
}


class AblationStudy:
    """Run systematic ablation: train + evaluate each configuration."""
    
    def __init__(self, build_model_fn, build_data_fn, rules, class_names, class_to_idx,
                 output_dir='./outputs', seed=42):
        self.build_model_fn = build_model_fn
        self.build_data_fn = build_data_fn
        self.rules = rules
        self.class_names = class_names
        self.class_to_idx = class_to_idx
        self.output_dir = output_dir
        self.seed = seed
        self.all_results = {}
    
    def run(self, configs=None):
        if configs is None:
            configs = ABLATION_CONFIGS
        
        for name, cfg in configs.items():
            print(f"\n{'#'*70}")
            print(f"# ABLATION: {name}")
            print(f"{'#'*70}")
            
            cfg['name'] = name
            
            # Rebuild data (same seed for fair comparison)
            torch.manual_seed(self.seed)
            np.random.seed(self.seed)
            train_loader, val_loader, test_loader, osr_loader = self.build_data_fn()
            
            # Build fresh model
            model = self.build_model_fn()
            
            # For 'no_hierarchy': disable binary head contribution by zeroing its weight
            # (model architecture stays the same, but binary_logits aren't used in logits)
            ablation_config = cfg.copy()
            
            # Train
            trainer = Trainer(model, train_loader, val_loader,
                             output_dir=self.output_dir, ablation_config=ablation_config)
            model = trainer.train()
            
            # Evaluate
            evaluator = Evaluator(model, test_loader, osr_loader, self.class_names,
                                 self.class_to_idx, self.rules, self.output_dir, tag=name)
            results = evaluator.run_full_evaluation()
            self.all_results[name] = results
        
        self._print_summary()
        self._save_summary()
        return self.all_results
    
    def _print_summary(self):
        print(f"\n{'='*80}")
        print("ABLATION STUDY SUMMARY")
        print(f"{'='*80}")
        
        header = f"{'Config':<20} {'Acc':>7} {'F1-M':>7} {'F1-W':>7} {'AUC':>7} {'KB%':>7} {'OSR-AUC':>8}"
        print(header)
        print("-" * len(header))
        
        for name, r in self.all_results.items():
            d = r.get('detection', {})
            i = r.get('interpretability', {})
            o = r.get('osr', {})
            print(f"{name:<20} "
                  f"{d.get('accuracy', 0):>7.4f} "
                  f"{d.get('f1_macro', 0):>7.4f} "
                  f"{d.get('f1_weighted', 0):>7.4f} "
                  f"{d.get('auc_roc', 0):>7.4f} "
                  f"{i.get('kb_satisfaction', 0):>6.1f}% "
                  f"{o.get('auc_roc', 0):>8.4f}")
    
    def _save_summary(self):
        path = os.path.join(self.output_dir, 'ablation_summary.json')
        with open(path, 'w') as f:
            json.dump(self.all_results, f, indent=2,
                     default=lambda x: float(x) if isinstance(x, (np.floating, np.integer)) else str(x))
        print(f"\nAblation summary saved: {path}")
