export default function LegalTermsPage() {
  return <div className="prose max-w-4xl mx-auto"><h1 className="text-3xl font-bold mb-6">Legal Terms & Conditions</h1><p className="text-lg text-gray-700">Terms of service and legal information...</p></div>
}
