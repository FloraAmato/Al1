export default function HelpPage() {
  return <div className="prose max-w-4xl mx-auto"><h1 className="text-3xl font-bold mb-6">Help & Documentation</h1><p className="text-lg text-gray-700">Comprehensive guide on how to use the CREA2 fair division platform...</p></div>
}
