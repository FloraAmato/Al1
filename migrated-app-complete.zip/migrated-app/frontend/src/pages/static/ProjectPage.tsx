export default function ProjectPage() {
  return <div className="prose max-w-4xl mx-auto"><h1 className="text-3xl font-bold mb-6">About the Project</h1><p className="text-lg text-gray-700">Information about the CREA2 fair division project and its objectives...</p></div>
}
