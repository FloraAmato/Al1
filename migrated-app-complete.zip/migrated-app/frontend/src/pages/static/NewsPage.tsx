export default function NewsPage() {
  return <div className="prose max-w-4xl mx-auto"><h1 className="text-3xl font-bold mb-6">News & Events</h1><p className="text-lg text-gray-700">Latest updates, news, and upcoming events...</p></div>
}
