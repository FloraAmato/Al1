"""
CREST-NIDS Model — v4 (all fixes applied)
FIX #2: binding_loss uses .mean() not .sum()
FIX #3: margin_max=1.5 + margin regularization penalty
FIX #9: concept_tau from config (0.1 for sharper concepts)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from config import (
    EMBEDDING_DIM, PROJECTION_DIM, NUM_CONCEPTS, CONCEPT_TAU,
    NUM_TRANSFORMER_LAYERS, NUM_HEADS, NUM_BINDING_HEADS,
    BOTTLENECK_DIM, COSINE_SCALE, ENCODER_CHANNELS, ENCODER_DROPOUT,
    CLASSIFIER_DROPOUT, MARGIN_INIT, MARGIN_MIN, MARGIN_MAX,
    MARGIN_REG_WEIGHT, UNCERTAINTY_ALPHA, DEVICE
)


# ============================================================
# Module A: Residual 1D-CNN Feature Encoder
# ============================================================

class ResidualBlock1D(nn.Module):
    def __init__(self, in_ch, out_ch, kernel_size=3):
        super().__init__()
        padding = kernel_size // 2
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size, padding=padding)
        self.bn1 = nn.BatchNorm1d(out_ch)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size, padding=padding)
        self.bn2 = nn.BatchNorm1d(out_ch)
        self.skip = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.skip_bn = nn.BatchNorm1d(out_ch) if in_ch != out_ch else nn.Identity()
    
    def forward(self, x):
        residual = self.skip_bn(self.skip(x))
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return F.relu(out + residual)


class FeatureEncoder(nn.Module):
    def __init__(self, input_dim, embed_dim=EMBEDDING_DIM, channels=None, dropout=ENCODER_DROPOUT):
        super().__init__()
        if channels is None:
            channels = ENCODER_CHANNELS
        
        # Initial conv
        self.input_conv = nn.Sequential(
            nn.Conv1d(1, channels[0], kernel_size=3, padding=1),
            nn.BatchNorm1d(channels[0]),
            nn.ReLU(),
        )
        
        # Residual blocks
        blocks = []
        in_ch = channels[0]
        for out_ch in channels[1:]:
            blocks.append(ResidualBlock1D(in_ch, out_ch))
            in_ch = out_ch
        # Two extra blocks at final channel size
        blocks.append(ResidualBlock1D(in_ch, in_ch))
        self.res_blocks = nn.Sequential(*blocks)
        
        # Dual pooling + projection
        self.projection = nn.Sequential(
            nn.Linear(in_ch * 2, embed_dim),
            nn.BatchNorm1d(embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
    
    def forward(self, x):
        # x: (batch, features)
        x = x.unsqueeze(1)  # (batch, 1, features)
        x = self.input_conv(x)
        x = self.res_blocks(x)
        
        # Dual pooling
        avg_pool = x.mean(dim=2)
        max_pool = x.max(dim=2).values
        pooled = torch.cat([avg_pool, max_pool], dim=1)
        
        h = self.projection(pooled)
        return h


# ============================================================
# Module B: Constraint-Field Regularizer
# ============================================================

class ConstraintField(nn.Module):
    def __init__(self, embed_dim, proj_dim, rules, num_classes):
        super().__init__()
        self.embed_dim = embed_dim
        self.proj_dim = proj_dim
        self.rules = rules
        self.num_classes = num_classes
        
        # Predicate projection heads — one per class
        self.predicate_heads = nn.ModuleDict()
        all_classes = set()
        for rule in rules:
            all_classes.update(rule['premise'])
            all_classes.update(rule['conclusion'])
        
        for cls_name in all_classes:
            safe_name = cls_name.replace(' ', '_').replace('-', '_').replace('\u2013', '_')
            self.predicate_heads[safe_name] = nn.Sequential(
                nn.Linear(embed_dim, proj_dim),
                nn.ReLU(),
                nn.Linear(proj_dim, proj_dim),
            )
        
        self._class_to_safe = {}
        for cls_name in all_classes:
            safe_name = cls_name.replace(' ', '_').replace('-', '_').replace('\u2013', '_')
            self._class_to_safe[cls_name] = safe_name
        
        # Learnable margins — one per rule
        self.margins = nn.ParameterList([
            nn.Parameter(torch.ones(1) * MARGIN_INIT) for _ in rules
        ])
        
        # Running centroids for per-sample energy
        self.register_buffer('centroids', torch.zeros(num_classes, proj_dim))
        self.register_buffer('centroid_counts', torch.zeros(num_classes))
    
    def _get_projection(self, h, class_name):
        safe = self._class_to_safe[class_name]
        return self.predicate_heads[safe](h)
    
    def forward(self, h, labels, class_names, class_to_idx):
        batch_size = h.size(0)
        total_energy = torch.tensor(0.0, device=h.device)
        rule_energies = {}
        n_active_rules = 0
        
        for rule_idx, rule in enumerate(self.rules):
            margin = torch.clamp(self.margins[rule_idx], MARGIN_MIN, MARGIN_MAX)
            
            if rule['type'] == 'implication':
                # Premise and conclusion classes should have similar projections
                rule_energy = torch.tensor(0.0, device=h.device)
                count = 0
                premise_classes = rule['premise']
                conclusion_classes = rule['conclusion']
                
                for p_cls in premise_classes:
                    if p_cls not in class_to_idx:
                        continue
                    p_idx = class_to_idx[p_cls]
                    p_mask = (labels == p_idx)
                    if p_mask.sum() == 0:
                        continue
                    p_proj = self._get_projection(h[p_mask], p_cls)
                    
                    for c_cls in conclusion_classes:
                        if c_cls not in class_to_idx:
                            continue
                        c_idx = class_to_idx[c_cls]
                        c_mask = (labels == c_idx)
                        if c_mask.sum() == 0:
                            continue
                        c_proj = self._get_projection(h[c_mask], c_cls)
                        
                        # Pairwise distance between centroids of projections
                        p_centroid = p_proj.mean(dim=0)
                        c_centroid = c_proj.mean(dim=0)
                        dist = torch.norm(p_centroid - c_centroid, p=2)
                        energy = F.relu(dist - margin)
                        rule_energy = rule_energy + energy
                        count += 1
                
                if count > 0:
                    rule_energy = rule_energy / count
                    total_energy = total_energy + rule_energy
                    n_active_rules += 1
                rule_energies[rule['name']] = rule_energy.item() if isinstance(rule_energy, torch.Tensor) else rule_energy
            
            elif rule['type'] == 'exclusion':
                # Premise and conclusion should be far apart
                rule_energy = torch.tensor(0.0, device=h.device)
                count = 0
                
                for p_cls in rule['premise']:
                    if p_cls not in class_to_idx:
                        continue
                    p_idx = class_to_idx[p_cls]
                    p_mask = (labels == p_idx)
                    if p_mask.sum() == 0:
                        continue
                    p_proj = self._get_projection(h[p_mask], p_cls)
                    
                    for c_cls in rule['conclusion']:
                        if c_cls not in class_to_idx:
                            continue
                        c_idx = class_to_idx[c_cls]
                        c_mask = (labels == c_idx)
                        if c_mask.sum() == 0:
                            continue
                        c_proj = self._get_projection(h[c_mask], c_cls)
                        
                        p_centroid = p_proj.mean(dim=0)
                        c_centroid = c_proj.mean(dim=0)
                        dist = torch.norm(p_centroid - c_centroid, p=2)
                        energy = F.relu(margin - dist)
                        rule_energy = rule_energy + energy
                        count += 1
                
                if count > 0:
                    rule_energy = rule_energy / count
                    total_energy = total_energy + rule_energy
                    n_active_rules += 1
                rule_energies[rule['name']] = rule_energy.item() if isinstance(rule_energy, torch.Tensor) else rule_energy
        
        if n_active_rules > 0:
            total_energy = total_energy / n_active_rules
        
        # FIX #3: Margin regularization — penalize large margins
        margin_reg = sum(m.mean() for m in self.margins) / len(self.margins)
        total_energy = total_energy + MARGIN_REG_WEIGHT * margin_reg
        
        # Update running centroids (for per-sample energy in uncertainty)
        with torch.no_grad():
            for cls_name, safe_name in self._class_to_safe.items():
                if cls_name in class_to_idx:
                    idx = class_to_idx[cls_name]
                    mask = (labels == idx)
                    if mask.sum() > 0:
                        proj = self.predicate_heads[safe_name](h[mask].detach())
                        new_centroid = proj.mean(dim=0)
                        # Exponential moving average
                        alpha = 0.1
                        if self.centroid_counts[idx] == 0:
                            self.centroids[idx] = new_centroid
                        else:
                            self.centroids[idx] = (1 - alpha) * self.centroids[idx] + alpha * new_centroid
                        self.centroid_counts[idx] += 1
        
        return total_energy, rule_energies
    
    def compute_sample_energy(self, h, class_to_idx):
        """Per-sample energy for uncertainty estimation."""
        batch_size = h.size(0)
        energies = torch.zeros(batch_size, device=h.device)
        
        # Compute distance to nearest centroid for each sample
        for cls_name, safe_name in self._class_to_safe.items():
            if cls_name not in class_to_idx:
                continue
            idx = class_to_idx[cls_name]
            if self.centroid_counts[idx] == 0:
                continue
            proj = self.predicate_heads[safe_name](h)
            dist = torch.norm(proj - self.centroids[idx].unsqueeze(0), p=2, dim=1)
            if energies.sum() == 0:
                energies = dist
            else:
                energies = torch.min(energies, dist)
        
        # Normalize to [0, 1]
        if energies.max() > 0:
            energies = energies / (energies.max() + 1e-8)
        
        return energies


# ============================================================
# Module C: Binding-Aware Transformer
# ============================================================

class BindingTransformerLayer(nn.Module):
    def __init__(self, d_model, n_heads, n_binding_heads, bottleneck_dim, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_binding = n_binding_heads
        self.n_standard = n_heads - n_binding_heads
        self.head_dim = d_model // n_heads
        
        assert d_model % n_heads == 0
        
        # Binding heads: separate role (Q) and filler (K, V) projections
        self.W_role = nn.Linear(d_model, self.n_binding * self.head_dim)
        self.W_filler_k = nn.Linear(d_model, self.n_binding * self.head_dim)
        self.W_filler_v = nn.Linear(d_model, self.n_binding * self.head_dim)
        
        # Standard attention heads
        if self.n_standard > 0:
            self.W_q = nn.Linear(d_model, self.n_standard * self.head_dim)
            self.W_k = nn.Linear(d_model, self.n_standard * self.head_dim)
            self.W_v = nn.Linear(d_model, self.n_standard * self.head_dim)
        
        # Output projection
        self.W_o = nn.Linear(d_model, d_model)
        
        # Relational bottleneck (Abstractor-style)
        self.bottleneck = nn.Sequential(
            nn.Linear(d_model, bottleneck_dim),
            nn.ReLU(),
            nn.Linear(bottleneck_dim, d_model),
        )
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 4, d_model),
            nn.Dropout(dropout),
        )
        
        self.ln1 = nn.LayerNorm(d_model)
        self.ln2 = nn.LayerNorm(d_model)
        self.ln3 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        
        self._binding_matrices = []
    
    def forward(self, x):
        # x: (batch, d_model) — single token per sample
        x_unsq = x.unsqueeze(1)  # (batch, 1, d_model)
        
        attn_outputs = []
        self._binding_matrices = []
        
        # Binding attention heads
        Q_r = self.W_role(x_unsq).view(-1, 1, self.n_binding, self.head_dim).transpose(1, 2)
        K_f = self.W_filler_k(x_unsq).view(-1, 1, self.n_binding, self.head_dim).transpose(1, 2)
        V_f = self.W_filler_v(x_unsq).view(-1, 1, self.n_binding, self.head_dim).transpose(1, 2)
        
        scale = math.sqrt(self.head_dim)
        bind_attn = torch.matmul(Q_r, K_f.transpose(-2, -1)) / scale
        bind_attn = F.softmax(bind_attn, dim=-1)
        self._binding_matrices.append(bind_attn)
        bind_out = torch.matmul(bind_attn, V_f)
        bind_out = bind_out.transpose(1, 2).contiguous().view(-1, 1, self.n_binding * self.head_dim)
        attn_outputs.append(bind_out)
        
        # Standard attention heads
        if self.n_standard > 0:
            Q = self.W_q(x_unsq).view(-1, 1, self.n_standard, self.head_dim).transpose(1, 2)
            K = self.W_k(x_unsq).view(-1, 1, self.n_standard, self.head_dim).transpose(1, 2)
            V = self.W_v(x_unsq).view(-1, 1, self.n_standard, self.head_dim).transpose(1, 2)
            
            std_attn = torch.matmul(Q, K.transpose(-2, -1)) / scale
            std_attn = F.softmax(std_attn, dim=-1)
            std_out = torch.matmul(std_attn, V)
            std_out = std_out.transpose(1, 2).contiguous().view(-1, 1, self.n_standard * self.head_dim)
            attn_outputs.append(std_out)
        
        # Combine heads
        combined = torch.cat(attn_outputs, dim=-1)
        combined = self.W_o(combined)
        combined = self.dropout(combined)
        
        # Residual + LayerNorm
        x_unsq = self.ln1(x_unsq + combined)
        
        # Relational bottleneck
        bottleneck_out = self.bottleneck(x_unsq)
        x_unsq = self.ln2(x_unsq + bottleneck_out)
        
        # FFN
        ffn_out = self.ffn(x_unsq)
        x_unsq = self.ln3(x_unsq + ffn_out)
        
        return x_unsq.squeeze(1)


class BindingTransformer(nn.Module):
    def __init__(self, d_model, n_layers, n_heads, n_binding_heads, bottleneck_dim, 
                 num_concepts, concept_tau, dropout=0.1):
        super().__init__()
        self.num_concepts = num_concepts
        self.concept_tau = concept_tau
        
        # Concept grounding
        self.concept_proj = nn.Linear(d_model, num_concepts)
        
        # Role vectors for binding
        self.role_embeddings = nn.Parameter(torch.randn(num_concepts, d_model) * 0.02)
        
        # Transformer layers
        self.layers = nn.ModuleList([
            BindingTransformerLayer(d_model, n_heads, n_binding_heads, bottleneck_dim, dropout)
            for _ in range(n_layers)
        ])
        
        # Unbinding projection (for cycle consistency)
        self.unbind_proj = nn.Linear(d_model, d_model)
    
    def forward(self, h):
        # Concept grounding (Eq. 4)
        concept_logits = self.concept_proj(h) / self.concept_tau
        concept_weights = F.softmax(concept_logits, dim=-1)  # (batch, K)
        
        # Weighted role embedding
        role = torch.matmul(concept_weights, self.role_embeddings)  # (batch, d_model)
        
        # Binding: element-wise product
        bound = h * role
        
        # Transformer layers
        out = bound
        for layer in self.layers:
            out = layer(out)
        
        # Compute binding orthogonality loss — FIX #2: .mean() not .sum()
        binding_loss = torch.tensor(0.0, device=h.device)
        n_matrices = 0
        for layer in self.layers:
            for B in layer._binding_matrices:
                # B: (batch, n_heads, 1, 1) — for single-token input
                batch = B.size(0)
                n_heads = B.size(1)
                B_flat = B.view(batch, n_heads, -1)  # (batch, n_heads, seq*seq)
                BTB = torch.matmul(B_flat.transpose(-2, -1), B_flat)
                I = torch.eye(BTB.size(-1), device=h.device).unsqueeze(0).unsqueeze(0)
                frob = ((BTB - I) ** 2).mean()  # FIX #2: .mean() instead of .sum()
                binding_loss = binding_loss + frob
                n_matrices += 1
        
        if n_matrices > 0:
            binding_loss = binding_loss / n_matrices
        
        # Cycle consistency loss
        unbound = self.unbind_proj(out) * role  # Unbind
        cycle_loss = F.mse_loss(unbound, h)
        
        return out, binding_loss, cycle_loss, concept_weights


# ============================================================
# Module D: Hierarchical Cosine Classifier + Uncertainty
# ============================================================

class UncertaintyClassifier(nn.Module):
    def __init__(self, d_model, num_classes, dropout=CLASSIFIER_DROPOUT, 
                 cosine_scale=COSINE_SCALE, alpha=UNCERTAINTY_ALPHA):
        super().__init__()
        self.num_classes = num_classes
        self.alpha = alpha
        
        # Shared refinement
        self.refine = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.BatchNorm1d(d_model),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        
        # Stage 1: Binary head (Benign vs Attack)
        self.binary_head = nn.Linear(d_model, 1)
        
        # Stage 2: Cosine prototype classifier
        self.prototypes = nn.Parameter(torch.randn(num_classes, d_model) * 0.02)
        self.cosine_scale = nn.Parameter(torch.ones(1) * cosine_scale)
    
    def forward(self, h, constraint_field=None, class_to_idx=None):
        h_refined = self.refine(h)
        
        # Stage 1: Binary
        binary_logits = self.binary_head(h_refined).squeeze(-1)
        p_attack = torch.sigmoid(binary_logits)
        
        # Stage 2: Cosine similarity to prototypes
        h_norm = F.normalize(h_refined, p=2, dim=-1)
        w_norm = F.normalize(self.prototypes, p=2, dim=-1)
        cosine_sim = torch.matmul(h_norm, w_norm.t()) * self.cosine_scale
        
        # Combined logits: binary gate boosts attack classes
        # Benign class is index 0 by convention; attack classes get p_attack multiplier
        combined_logits = cosine_sim.clone()
        if self.num_classes > 1:
            # Boost non-benign (attack) classes by p_attack
            combined_logits[:, 1:] = combined_logits[:, 1:] + p_attack.unsqueeze(1) * 2.0
        
        # Uncertainty estimation (Eq. 6)
        probs = F.softmax(combined_logits, dim=-1)
        entropy = -(probs * (probs + 1e-8).log()).sum(dim=-1)
        max_entropy = math.log(self.num_classes)
        norm_entropy = entropy / max_entropy  # [0, 1]
        
        # Energy-based uncertainty from constraint field
        if constraint_field is not None and class_to_idx is not None:
            sample_energy = constraint_field.compute_sample_energy(h, class_to_idx)
        else:
            sample_energy = torch.zeros_like(norm_entropy)
        
        # Cosine-based uncertainty: 1 - max cosine similarity
        max_cosine = cosine_sim.max(dim=-1).values
        cosine_unc = 1.0 - torch.sigmoid(max_cosine)  # high when max similarity is low
        
        # Combined uncertainty
        uncertainty = self.alpha * norm_entropy + (1 - self.alpha) * sample_energy
        
        # OSR score: combine uncertainty + cosine uncertainty
        osr_score = 0.5 * uncertainty + 0.5 * cosine_unc
        
        return {
            'logits': combined_logits,
            'cosine_sim': cosine_sim,
            'binary_logits': binary_logits,
            'p_attack': p_attack,
            'uncertainty': uncertainty,
            'osr_score': osr_score,
            'entropy': norm_entropy,
            'sample_energy': sample_energy,
            'concept_entropy': None,  # filled by transformer
        }


# ============================================================
# Full Model: CREST-NIDS
# ============================================================

class CREST_NIDS(nn.Module):
    def __init__(self, input_dim, num_classes, rules, class_to_idx):
        super().__init__()
        self.num_classes = num_classes
        self.class_to_idx = class_to_idx
        self.idx_to_class = {v: k for k, v in class_to_idx.items()}
        
        # Module A: Feature Encoder
        self.encoder = FeatureEncoder(input_dim, EMBEDDING_DIM)
        
        # Module B: Constraint Field
        self.constraint_field = ConstraintField(EMBEDDING_DIM, PROJECTION_DIM, rules, num_classes)
        
        # Module C: Binding Transformer
        self.transformer = BindingTransformer(
            EMBEDDING_DIM, NUM_TRANSFORMER_LAYERS, NUM_HEADS,
            NUM_BINDING_HEADS, BOTTLENECK_DIM, NUM_CONCEPTS, CONCEPT_TAU
        )
        
        # Module D: Classifier
        self.classifier = UncertaintyClassifier(EMBEDDING_DIM, num_classes)
    
    def forward(self, x, labels=None):
        # A: Encode
        h = self.encoder(x)
        
        # B: Constraint field (only during training with labels)
        constraint_energy = torch.tensor(0.0, device=x.device)
        rule_energies = {}
        if labels is not None:
            class_names = [self.idx_to_class.get(l.item(), 'unknown') for l in labels]
            constraint_energy, rule_energies = self.constraint_field(h, labels, class_names, self.class_to_idx)
        
        # C: Binding Transformer
        h_transformed, binding_loss, cycle_loss, concept_weights = self.transformer(h)
        
        # D: Classify
        outputs = self.classifier(h_transformed, self.constraint_field, self.class_to_idx)
        outputs['constraint_energy'] = constraint_energy
        outputs['binding_loss'] = binding_loss
        outputs['cycle_loss'] = cycle_loss
        outputs['rule_energies'] = rule_energies
        outputs['concept_weights'] = concept_weights
        outputs['embedding'] = h
        
        # Concept entropy
        concept_entropy = -(concept_weights * (concept_weights + 1e-8).log()).sum(dim=-1).mean()
        outputs['concept_entropy'] = concept_entropy
        
        return outputs
    
    def count_parameters(self):
        counts = {}
        counts['Encoder'] = sum(p.numel() for p in self.encoder.parameters())
        counts['ConstraintField'] = sum(p.numel() for p in self.constraint_field.parameters())
        counts['BindingTransformer'] = sum(p.numel() for p in self.transformer.parameters())
        counts['Classifier'] = sum(p.numel() for p in self.classifier.parameters())
        counts['Total'] = sum(counts.values())
        return counts
