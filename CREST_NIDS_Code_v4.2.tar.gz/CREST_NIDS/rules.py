"""
CREST-NIDS Knowledge Base — v4
FIX #4: ACI-IoT class names completely rewritten to match actual CSV
FIX #5: CIC-IDS uses em-dash (–) for WebAttack classes
FIX #8: BoT-IoT class names verified
"""


class KnowledgeBase:
    def __init__(self):
        self.rules = []
        self.class_names = set()
    
    def add_rule(self, name, rule_type, premise, conclusion, description=''):
        assert rule_type in ('implication', 'exclusion')
        self.rules.append({
            'name': name,
            'type': rule_type,
            'premise': premise,
            'conclusion': conclusion,
            'description': description,
        })
        self.class_names.update(premise)
        self.class_names.update(conclusion)
    
    def match_to_data(self, data_classes):
        """Filter rules to only those whose classes exist in the data."""
        matched = []
        skipped = []
        for rule in self.rules:
            all_classes = set(rule['premise']) | set(rule['conclusion'])
            if all_classes.issubset(set(data_classes)):
                matched.append(rule)
            else:
                missing = all_classes - set(data_classes)
                skipped.append((rule['name'], missing))
                print(f"  [WARNING] Rule '{rule['name']}' has unmatched classes {missing} - will be skipped")
        
        active_rules = matched
        print(f"  Knowledge base: {len(active_rules)}/{len(self.rules)} rules matched to data classes")
        return active_rules
    
    def print_summary(self):
        print(f"\nKnowledge Base: {len(self.rules)} rules over {len(self.class_names)} classes\n")
        for i, rule in enumerate(self.rules):
            print(f"  R{i+1} [{rule['type']}] {rule['name']}")
            print(f"      Premise:    {rule['premise']}")
            print(f"      Conclusion: {rule['conclusion']}")
            print(f"      {rule['description']}\n")


def build_cicids2017_kb():
    """CIC-IDS-2017 knowledge base.
    FIX #5: WebAttack classes use em-dash \u2013 not hyphen -.
    """
    kb = KnowledgeBase()
    
    # R1: DoS family cohesion (implication)
    kb.add_rule('DoS_family_cohesion', 'implication',
        premise=['DoS slowloris', 'DoS Slowhttptest', 'DoS Hulk', 'DoS GoldenEye'],
        conclusion=['DDoS'],
        description='All DoS subtypes share denial-of-service characteristics and should produce similar embeddings.')
    
    # R2: Patator family (implication)
    kb.add_rule('Patator_family_cohesion', 'implication',
        premise=['FTP-Patator', 'SSH-Patator'],
        conclusion=['FTP-Patator', 'SSH-Patator'],
        description='FTP and SSH Patator attacks share brute-force methodology.')
    
    # R3: WebAttack family (implication) — FIX: em-dash \u2013
    kb.add_rule('WebAttack_family_cohesion', 'implication',
        premise=['Web Attack \u2013 Brute Force', 'Web Attack \u2013 XSS', 'Web Attack \u2013 Sql Injection'],
        conclusion=['Web Attack \u2013 Brute Force', 'Web Attack \u2013 XSS', 'Web Attack \u2013 Sql Injection'],
        description='Web attack variants target the same application layer.')
    
    # R4: Benign vs DoS (exclusion)
    kb.add_rule('Benign_vs_DoS', 'exclusion',
        premise=['BENIGN'],
        conclusion=['DoS slowloris', 'DoS Slowhttptest', 'DoS Hulk', 'DoS GoldenEye', 'DDoS'],
        description='Benign traffic must be well-separated from DoS attacks.')
    
    # R5: Benign vs BruteForce (exclusion) — FIX: em-dash
    kb.add_rule('Benign_vs_BruteForce', 'exclusion',
        premise=['BENIGN'],
        conclusion=['FTP-Patator', 'SSH-Patator', 'Web Attack \u2013 Brute Force'],
        description='Benign traffic must be well-separated from brute-force attacks.')
    
    # R6: Benign vs Recon (exclusion)
    kb.add_rule('Benign_vs_Recon', 'exclusion',
        premise=['BENIGN'],
        conclusion=['PortScan', 'Infiltration'],
        description='Benign traffic must be well-separated from reconnaissance.')
    
    # R7: DoS vs WebAttack (exclusion) — FIX: em-dash
    kb.add_rule('DoS_vs_WebAttack', 'exclusion',
        premise=['DoS Hulk', 'DoS GoldenEye', 'DDoS'],
        conclusion=['Web Attack \u2013 XSS', 'Web Attack \u2013 Sql Injection'],
        description='Volume-based DoS and precision web attacks have fundamentally different traffic signatures.')
    
    # R8: Bot vs PortScan (exclusion)
    kb.add_rule('Bot_vs_PortScan', 'exclusion',
        premise=['Bot'],
        conclusion=['PortScan'],
        description='Botnet C2 traffic differs structurally from port scanning.')
    
    return kb


def build_aciiot_kb():
    """ACI-IoT-2023 knowledge base.
    FIX #4: Completely rewritten to match actual CSV class names:
    ['ARP Spoofing', 'Benign', 'DNS Flood', 'Dictionary Attack', 'ICMP Flood',
     'OS Scan', 'Ping Sweep', 'Port Scan', 'SYN Flood', 'Slowloris',
     'UDP Flood', 'Vulnerability Scan']
    """
    kb = KnowledgeBase()
    
    # R1: Flood family cohesion
    kb.add_rule('Flood_family', 'implication',
        premise=['ICMP Flood', 'DNS Flood', 'SYN Flood', 'UDP Flood'],
        conclusion=['ICMP Flood', 'DNS Flood', 'SYN Flood', 'UDP Flood'],
        description='Flood attack variants share volumetric characteristics.')
    
    # R2: Scan/Recon family
    kb.add_rule('Recon_family', 'implication',
        premise=['Port Scan', 'OS Scan', 'Ping Sweep', 'Vulnerability Scan'],
        conclusion=['Port Scan', 'OS Scan', 'Ping Sweep', 'Vulnerability Scan'],
        description='Reconnaissance activities share scanning behavior.')
    
    # R3: Application-layer DoS
    kb.add_rule('AppDoS_family', 'implication',
        premise=['Slowloris', 'Dictionary Attack'],
        conclusion=['Slowloris', 'Dictionary Attack'],
        description='Application-layer attacks share session-based patterns.')
    
    # R4: Benign separation
    kb.add_rule('Benign_separation', 'exclusion',
        premise=['Benign'],
        conclusion=['ICMP Flood', 'SYN Flood', 'DNS Flood', 'Port Scan'],
        description='Benign traffic must be well-separated from attacks.')
    
    # R5: Volumetric vs Precision
    kb.add_rule('Volumetric_vs_Precision', 'exclusion',
        premise=['ICMP Flood', 'UDP Flood'],
        conclusion=['Dictionary Attack', 'ARP Spoofing'],
        description='Volumetric floods differ from precision attacks.')
    
    # R6: Recon vs Flood
    kb.add_rule('Recon_vs_Flood', 'exclusion',
        premise=['Port Scan', 'OS Scan'],
        conclusion=['ICMP Flood', 'DNS Flood'],
        description='Scanning behavior differs from flooding behavior.')
    
    return kb


def build_botiot_kb():
    """NF-BoT-IoT-V2 knowledge base.
    FIX #8: Class names verified against actual CSV.
    Expected classes: ['Benign', 'DDoS', 'DoS', 'Reconnaissance', 'Theft']
    """
    kb = KnowledgeBase()
    
    # R1: Attack separation from Benign
    kb.add_rule('Benign_vs_Attacks', 'exclusion',
        premise=['Benign'],
        conclusion=['DDoS', 'DoS', 'Reconnaissance', 'Theft'],
        description='Benign traffic must be well-separated from all attacks.')
    
    # R2: DoS/DDoS family
    kb.add_rule('DoS_DDoS_cohesion', 'implication',
        premise=['DDoS'],
        conclusion=['DoS'],
        description='DDoS and DoS share denial-of-service characteristics.')
    
    # R3: Volume vs Stealth
    kb.add_rule('Volume_vs_Stealth', 'exclusion',
        premise=['DDoS', 'DoS'],
        conclusion=['Reconnaissance', 'Theft'],
        description='Volume-based attacks differ from stealth/recon activities.')
    
    # R4: Recon vs Theft
    kb.add_rule('Recon_vs_Theft', 'exclusion',
        premise=['Reconnaissance'],
        conclusion=['Theft'],
        description='Reconnaissance scanning differs from data exfiltration.')
    
    return kb


def get_kb_for_dataset(dataset_name):
    """Return the appropriate KB builder for a dataset."""
    builders = {
        'CIC-IDS-2017': build_cicids2017_kb,
        'ACI-IoT-2023': build_aciiot_kb,
        'NF-BoT-IoT-V2': build_botiot_kb,
    }
    if dataset_name not in builders:
        raise ValueError(f"Unknown dataset: {dataset_name}. Available: {list(builders.keys())}")
    return builders[dataset_name]()
