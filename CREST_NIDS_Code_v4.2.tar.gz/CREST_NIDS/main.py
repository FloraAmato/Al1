"""
CREST-NIDS Main — v4.1 with multi-seed and ablation study

Usage:
  # Standard run (3 seeds, reports mean±std):
  python main.py --dataset ACI-IoT-2023 --data_path .\data\aciiot\

  # Single seed (faster):
  python main.py --dataset ACI-IoT-2023 --data_path .\data\aciiot\ --single_seed 42

  # Ablation study (1 seed, 5 configs):
  python main.py --dataset ACI-IoT-2023 --data_path .\data\aciiot\ --ablation

  # Both datasets:
  python main.py --dataset CIC-IDS-2017 --data_path .\data\cicids2017\
  python main.py --dataset ACI-IoT-2023 --data_path .\data\aciiot\

  # Quick test:
  python main.py --synthetic --epochs 5
"""
import argparse
import os
import json
import numpy as np
import torch

from config import (DEVICE, MAX_EPOCHS, LAMBDA, MU, NU, EMBEDDING_DIM,
                    NUM_TRANSFORMER_LAYERS, NUM_HEADS, NUM_CONCEPTS, SEEDS)
from data import DataPreprocessor, create_synthetic_dataset
from rules import get_kb_for_dataset, KnowledgeBase
from model import CREST_NIDS
from train import Trainer, Evaluator, AblationStudy


def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def run_single(args, seed, active_rules, class_names=None, class_to_idx=None):
    """Run a single training + evaluation cycle with a given seed."""
    print(f"\n{'*'*70}")
    print(f"* SEED = {seed}")
    print(f"{'*'*70}")
    
    set_seed(seed)
    
    tag = f"seed{seed}"
    out_dir = os.path.join(args.output_dir, tag)
    os.makedirs(out_dir, exist_ok=True)
    
    if args.synthetic:
        train_loader, val_loader, test_loader, osr_loader, nf, nc, cn, c2i = \
            create_synthetic_dataset(seed=seed)
        cw = None
    else:
        preprocessor = DataPreprocessor(args.dataset, args.data_path, args.max_samples, seed=seed)
        train_loader, val_loader, test_loader, osr_loader = preprocessor.load_and_preprocess()
        nf = preprocessor.num_features
        nc = preprocessor.num_classes
        cn = preprocessor.class_names
        c2i = preprocessor.class_to_idx
        cw = preprocessor.class_weights
    
    # Use passed class_names/class_to_idx for consistency across seeds
    if class_names is not None:
        cn = class_names
    if class_to_idx is not None:
        c2i = class_to_idx
    
    model = CREST_NIDS(nf, nc, active_rules, c2i)
    
    if seed == SEEDS[0]:  # Print params only for first seed
        params = model.count_parameters()
        print(f"\nModel: {params['Total']:,} parameters")
        print(f"  Config: λ={LAMBDA}, μ={MU}, ν={NU}")
    
    # Try torch.compile for extra speed (PyTorch 2.x)
    try:
        model = torch.compile(model)
        if seed == SEEDS[0]:
            print("  torch.compile: ON (first epoch will be slower)")
    except Exception as e:
        if seed == SEEDS[0]:
            print(f"  torch.compile: OFF ({e})")
    
    trainer = Trainer(model, train_loader, val_loader, cw, out_dir)
    model = trainer.train()
    
    evaluator = Evaluator(model, test_loader, osr_loader, cn, c2i, active_rules, out_dir, tag)
    results = evaluator.run_full_evaluation()
    
    torch.save(model.state_dict(), os.path.join(out_dir, 'model_final.pt'))
    return results, nf, nc, cn, c2i


def aggregate_results(all_results, seeds):
    """Compute mean ± std across seeds for all metrics."""
    print(f"\n{'='*70}")
    print(f"AGGREGATED RESULTS ({len(seeds)} seeds: {seeds})")
    print(f"{'='*70}")
    
    # Collect all metric paths
    aggregated = {}
    
    for section in ['detection', 'interpretability', 'adversarial', 'osr']:
        aggregated[section] = {}
        # Get all keys from any seed's results
        sample = all_results[seeds[0]].get(section, {})
        for key in sample:
            vals = []
            for s in seeds:
                v = all_results[s].get(section, {}).get(key, None)
                if v is not None and isinstance(v, (int, float, np.floating)):
                    vals.append(float(v))
            if vals:
                mean = np.mean(vals)
                std = np.std(vals)
                aggregated[section][key] = {'mean': mean, 'std': std, 'values': vals}
    
    # Print nicely
    for section, metrics in aggregated.items():
        print(f"\n  [{section.upper()}]")
        for key, stats in metrics.items():
            print(f"    {key:20s}: {stats['mean']:.4f} ± {stats['std']:.4f}")
    
    return aggregated


def main():
    parser = argparse.ArgumentParser(description='CREST-NIDS v4.1')
    parser.add_argument('--dataset', type=str, default='CIC-IDS-2017',
                        choices=['CIC-IDS-2017', 'ACI-IoT-2023', 'NF-BoT-IoT-V2'])
    parser.add_argument('--data_path', type=str, default='./data/cicids2017/')
    parser.add_argument('--output_dir', type=str, default='./outputs')
    parser.add_argument('--max_samples', type=int, default=None)
    parser.add_argument('--epochs', type=int, default=None)
    parser.add_argument('--single_seed', type=int, default=None,
                        help='Run with a single seed instead of all 3')
    parser.add_argument('--ablation', action='store_true',
                        help='Run ablation study (5 configs, seed=42)')
    parser.add_argument('--synthetic', action='store_true')
    args = parser.parse_args()
    
    print(f"Device: {DEVICE}")
    
    if args.epochs is not None:
        import config
        config.MAX_EPOCHS = args.epochs
        global MAX_EPOCHS
        MAX_EPOCHS = args.epochs
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Determine seeds
    if args.single_seed is not None:
        seeds = [args.single_seed]
    else:
        seeds = SEEDS
    
    # ========================
    # ABLATION MODE
    # ========================
    if args.ablation:
        print("\n" + "#" * 70)
        print("# ABLATION STUDY MODE")
        print("#" * 70)
        
        seed = 42
        set_seed(seed)
        
        # Load data once
        if args.synthetic:
            train_loader, val_loader, test_loader, osr_loader, nf, nc, cn, c2i = \
                create_synthetic_dataset(seed=seed)
            cw = None
            kb = KnowledgeBase()
            kb.add_rule('test', 'implication', ['Class_0', 'Class_1'], ['Class_2'])
            active_rules = kb.match_to_data(cn)
        else:
            preprocessor = DataPreprocessor(args.dataset, args.data_path, args.max_samples, seed=seed)
            train_loader, val_loader, test_loader, osr_loader = preprocessor.load_and_preprocess()
            nf, nc, cn, c2i, cw = (preprocessor.num_features, preprocessor.num_classes,
                                    preprocessor.class_names, preprocessor.class_to_idx,
                                    preprocessor.class_weights)
            kb = get_kb_for_dataset(args.dataset)
            kb.print_summary()
            active_rules = kb.match_to_data(cn)
        
        def build_model():
            return CREST_NIDS(nf, nc, active_rules, c2i)
        
        def build_data():
            # Re-process data with same seed for each ablation config
            if args.synthetic:
                trl, vl, tel, osrl, _, _, _, _ = create_synthetic_dataset(seed=seed)
                return trl, vl, tel, osrl
            else:
                p = DataPreprocessor(args.dataset, args.data_path, args.max_samples, seed=seed)
                return p.load_and_preprocess()
        
        ablation = AblationStudy(build_model, build_data, active_rules, cn, c2i,
                                 args.output_dir, seed=seed)
        ablation.run()
        return
    
    # ========================
    # MULTI-SEED MODE
    # ========================
    
    # Build KB once
    if args.synthetic:
        kb = KnowledgeBase()
        kb.add_rule('test', 'implication', ['Class_0', 'Class_1'], ['Class_2'])
        active_rules = kb.match_to_data(['Class_0', 'Class_1', 'Class_2', 'Class_3', 'Class_4'])
        cn_global, c2i_global = None, None
    else:
        kb = get_kb_for_dataset(args.dataset)
        kb.print_summary()
        # Quick load to get class names (first seed)
        pre = DataPreprocessor(args.dataset, args.data_path, args.max_samples, seed=seeds[0])
        pre.load_and_preprocess()
        active_rules = kb.match_to_data(pre.class_names)
        cn_global = pre.class_names
        c2i_global = pre.class_to_idx
    
    all_results = {}
    
    for seed in seeds:
        results, nf, nc, cn, c2i = run_single(args, seed, active_rules, cn_global, c2i_global)
        all_results[seed] = results
    
    # Aggregate if multiple seeds
    if len(seeds) > 1:
        agg = aggregate_results(all_results, seeds)
        
        # Save aggregate
        agg_path = os.path.join(args.output_dir, 'results_aggregated.json')
        with open(agg_path, 'w') as f:
            json.dump(agg, f, indent=2,
                     default=lambda x: float(x) if isinstance(x, (np.floating, np.integer)) else
                     x.tolist() if isinstance(x, np.ndarray) else str(x))
        print(f"\nAggregated results saved: {agg_path}")
    
    print("\nAll done!")


if __name__ == '__main__':
    main()
