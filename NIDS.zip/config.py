"""
CREST-NIDS Configuration
========================
Constraint-Regularized Embedding-Space Transformer
for Network Intrusion Detection

All hyperparameters and paths are defined here.
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Optional


@dataclass
class EncoderConfig:
    """1D-CNN Feature Encoder configuration."""
    input_dim: int = 78                # Number of input features (CIC-IDS-2017 has 78)
    conv_channels: List[int] = field(default_factory=lambda: [32, 64, 128])
    kernel_size: int = 3
    embedding_dim: int = 128           # Output embedding dimension d
    dropout: float = 0.2


@dataclass
class ConstraintFieldConfig:
    """Constraint-Field Regularizer configuration."""
    embedding_dim: int = 128           # Must match encoder output
    projection_dim: int = 64           # Predicate projection dimension k
    margin_init: float = 0.5           # Initial learnable margin ε
    margin_min: float = 0.01           # Minimum margin clamp
    margin_max: float = 2.0            # Maximum margin clamp
    distance_metric: str = "cosine"    # "cosine" or "euclidean"


@dataclass
class BindingTransformerConfig:
    """Binding-Aware Transformer configuration."""
    embedding_dim: int = 128           # Must match encoder output
    num_layers: int = 2                # Number of transformer layers
    num_heads: int = 4                 # Attention heads
    num_role_heads: int = 2            # Binding-specific heads (subset of num_heads)
    concept_vocab_size: int = 32       # Concept vocabulary K
    concept_temperature: float = 0.5   # Softmax temperature τ
    bottleneck_dim: int = 32           # Relational bottleneck dimension
    ff_dim: int = 256                  # Feed-forward hidden dimension
    dropout: float = 0.1


@dataclass
class ClassifierConfig:
    """Uncertainty-Aware Classifier configuration."""
    embedding_dim: int = 128           # Must match encoder output
    hidden_dim: int = 64
    num_classes: int = 15              # CIC-IDS-2017: 15 classes
    uncertainty_alpha: float = 0.5     # Balance entropy vs constraint energy
    osr_threshold: float = 0.7         # Open-set recognition threshold


@dataclass
class TrainingConfig:
    """Training hyperparameters."""
    # Loss weights (Eq. 7 in paper)
    lambda_constraint: float = 0.5     # λ: constraint-field energy weight
    mu_binding: float = 0.05           # μ: binding orthogonality weight
    nu_cycle: float = 0.05            # ν: cycle-consistency weight

    # Optimizer
    learning_rate: float = 1e-3
    min_learning_rate: float = 1e-5
    weight_decay: float = 1e-4
    epochs: int = 50
    batch_size: int = 512
    patience: int = 7                  # Early stopping patience

    # Data
    train_split: float = 0.8
    val_split: float = 0.1             # From training set
    random_seed: int = 42
    num_workers: int = 4


@dataclass
class CRESTConfig:
    """Master configuration for CREST-NIDS."""
    encoder: EncoderConfig = field(default_factory=EncoderConfig)
    constraint: ConstraintFieldConfig = field(default_factory=ConstraintFieldConfig)
    transformer: BindingTransformerConfig = field(default_factory=BindingTransformerConfig)
    classifier: ClassifierConfig = field(default_factory=ClassifierConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)

    # Dataset selection
    dataset: str = "CIC-IDS-2017"      # "CIC-IDS-2017", "NF-BoT-IoT-V2", "ACI-IoT-2023"
    data_path: str = "./data/"

    def __post_init__(self):
        """Ensure dimensional consistency across modules."""
        d = self.encoder.embedding_dim
        self.constraint.embedding_dim = d
        self.transformer.embedding_dim = d
        self.classifier.embedding_dim = d


# ── Predefined dataset configurations ──

DATASET_CONFIGS = {
    "CIC-IDS-2017": {
        "input_dim": 78,
        "num_classes": 15,
        "class_names": [
            "BENIGN", "FTP-Patator", "SSH-Patator", "DoS slowloris",
            "DoS Slowhttptest", "DoS Hulk", "DoS GoldenEye", "Heartbleed",
            "Web Attack - Brute Force", "Web Attack - XSS",
            "Web Attack - Sql Injection", "Infiltration", "Bot",
            "PortScan", "DDoS"
        ],
        # OSR: hold out Slowloris as unknown, following ODXU [8]
        "osr_holdout_class": "DoS slowloris",
    },
    "NF-BoT-IoT-V2": {
        "input_dim": 12,
        "num_classes": 5,
        "class_names": ["Benign", "DDoS", "DoS", "Reconnaissance", "Theft"],
        "osr_holdout_class": "Theft",
    },
    "ACI-IoT-2023": {
        "input_dim": 46,
        "num_classes": 19,
        "class_names": [
            "Benign", "DDoS-ICMP_Flood", "DDoS-UDP_Flood",
            "DDoS-TCP_Flood", "DDoS-PSHACK_Flood", "DDoS-SYN_Flood",
            "DDoS-RSTFINFlood", "DDoS-SynonymousIP_Flood",
            "DoS-UDP_Flood", "DoS-TCP_Flood", "DoS-HTTP_Flood",
            "Mirai-greeth_flood", "Mirai-greip_flood", "Mirai-udpplain",
            "Recon-HostDiscovery", "Recon-OSScan", "Recon-PortScan",
            "VulnerabilityScan", "BrowserHijacking"
        ],
        "osr_holdout_class": "BrowserHijacking",
    }
}
