# CREST-NIDS

**Constraint-Regularized Embedding-Space Transformer for Network Intrusion Detection**

A novel neuro-symbolic framework that replaces fuzzy logic satisfaction (Logic Tensor Networks) with geometric constraint fields in latent space and introduces binding-aware attention for compositional attack-pattern reasoning.

## Architecture

```
Raw Network Traffic (packets / flows)
            │
   ┌────────┴────────┐
   │ (A) 1D-CNN      │   Feature Encoder: 3 conv layers → d-dim embeddings
   │    Encoder       │
   └────────┬────────┘
            │  h_i ∈ R^d
   ┌────────┴────────┐
   │(B) Constraint   │──▶ E_total (rule energy, Eq. 1-3)
   │  Field Module   │   Geometric rule enforcement in embedding space
   └────────┬────────┘
            │
   ┌────────┴────────┐
   │(C) Binding-Aware│   Role-filler attention + relational bottleneck
   │  Transformer    │   Concept grounding (Eq. 4) + Binding attention (Eq. 5)
   └────────┬────────┘
            │
   ┌────────┴────────┐
   │(D) Uncertainty  │──▶ Classification + OSR (Eq. 6)
   │  Classifier     │   Dual uncertainty: entropy + constraint energy
   └─────────────────┘
```

## Quick Start

```bash
# Test pipeline with synthetic data
python main.py --synthetic --epochs 10

# Run ablation study
python main.py --synthetic --ablation --epochs 10

# Train on CIC-IDS-2017
python main.py --dataset CIC-IDS-2017 --data_path ./data/cicids2017/

# Train on NF-BoT-IoT-V2
python main.py --dataset NF-BoT-IoT-V2 --data_path ./data/botiot/

# Train on ACI-IoT-2023
python main.py --dataset ACI-IoT-2023 --data_path ./data/aciiot/

# Custom hyperparameters
python main.py --synthetic \
  --embedding_dim 128 \
  --transformer_layers 2 \
  --num_heads 4 \
  --lambda_c 0.5 \
  --mu_b 0.05 \
  --nu_cy 0.05 \
  --epochs 50 \
  --batch_size 512
```

## Requirements

```
torch >= 2.0
numpy
pandas
scikit-learn
```

## Files

| File | Description |
|------|-------------|
| `config.py` | All hyperparameters and dataset configurations |
| `rules.py` | Symbolic knowledge base (rules per dataset) |
| `model.py` | Core architecture: Encoder, ConstraintField, BindingTransformer, Classifier |
| `data.py` | Data preprocessing for CIC-IDS-2017, NF-BoT-IoT-V2, ACI-IoT-2023 |
| `train.py` | Training engine, evaluator, adversarial testing, ablation support |
| `main.py` | Entry point with CLI |

## Training Objective (Eq. 7)

```
L = L_CE + λ·E_total + μ·L_bind + ν·L_cycle
```

- **L_CE**: Cross-entropy classification loss
- **E_total**: Constraint-field energy (geometric rule enforcement)
- **L_bind**: Binding matrix orthogonality (‖B^T B − I‖²)
- **L_cycle**: Bind/unbind cycle consistency

## Evaluation Dimensions

1. **Detection**: Accuracy, F1, Precision, Recall, AUC-ROC, FOR
2. **Interpretability**: KB satisfaction rate, concept entropy, rule extraction
3. **Adversarial robustness**: FGSM + PGD at ε ∈ {0.01, 0.05, 0.1}
4. **Open-set recognition**: Unknown attack detection via dual uncertainty

## Reference Benchmarks (from Literature)

| Method | Dataset | Accuracy | Source |
|--------|---------|----------|--------|
| ODXU (NSAI SOTA) | CIC-IDS-2017 | ~97.5% | Tran et al., 2025 |
| Dual ANN+CNN | NF-BoT-IoT-V2 | >98% | Nature Sci. Reports, 2025 |
| LTN Classifier | KDD-99 | ~95% | Onchis et al., 2022 |
| FcNN | CIC-IDS-2017 | ~95.2% | Tran et al., 2025 |
| 1D-CNN | CIC-IDS-2017 | ~96.1% | Tran et al., 2025 |

CREST-NIDS targets surpassing these benchmarks through its unified
constraint-field + binding-aware architecture.
