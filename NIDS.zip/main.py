#!/usr/bin/env python3
"""
CREST-NIDS: Main Entry Point
==============================
Constraint-Regularized Embedding-Space Transformer
for Network Intrusion Detection

Usage:
  # Train on CIC-IDS-2017 (requires dataset download)
  python main.py --dataset CIC-IDS-2017 --data_path ./data/cicids2017/

  # Train on synthetic data (for testing pipeline)
  python main.py --synthetic

  # Run ablation study
  python main.py --synthetic --ablation

  # Custom hyperparameters
  python main.py --synthetic --epochs 30 --batch_size 256 --lambda_c 0.5
"""

import argparse
import json
import os
import sys
import time

import numpy as np
import torch

from config import CRESTConfig, DATASET_CONFIGS
from rules import build_knowledge_base
from model import CREST_NIDS
from data import DataPreprocessor, NIDSDataset, create_synthetic_dataset
from train import Trainer, Evaluator, AblationStudy

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, WeightedRandomSampler


def parse_args():
    parser = argparse.ArgumentParser(description="CREST-NIDS Training Pipeline")

    # Dataset
    parser.add_argument("--dataset", type=str, default="CIC-IDS-2017",
                        choices=list(DATASET_CONFIGS.keys()))
    parser.add_argument("--data_path", type=str, default="./data/")
    parser.add_argument("--synthetic", action="store_true",
                        help="Use synthetic data for pipeline testing")
    parser.add_argument("--synthetic_samples", type=int, default=20000)

    # Architecture
    parser.add_argument("--embedding_dim", type=int, default=128)
    parser.add_argument("--transformer_layers", type=int, default=2)
    parser.add_argument("--num_heads", type=int, default=4)
    parser.add_argument("--concept_vocab", type=int, default=32)
    parser.add_argument("--bottleneck_dim", type=int, default=32)

    # Training
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--patience", type=int, default=7)

    # Loss weights (Eq. 7)
    parser.add_argument("--lambda_c", type=float, default=0.5,
                        help="λ: constraint-field weight")
    parser.add_argument("--mu_b", type=float, default=0.05,
                        help="μ: binding orthogonality weight")
    parser.add_argument("--nu_cy", type=float, default=0.05,
                        help="ν: cycle-consistency weight")

    # Evaluation
    parser.add_argument("--ablation", action="store_true",
                        help="Run full ablation study")
    parser.add_argument("--no_adversarial", action="store_true",
                        help="Skip adversarial evaluation")

    # Output
    parser.add_argument("--save_dir", type=str, default="./outputs")
    parser.add_argument("--seed", type=int, default=42)

    return parser.parse_args()


def build_config(args) -> CRESTConfig:
    """Build CREST-NIDS configuration from command-line arguments."""
    cfg = CRESTConfig()
    cfg.dataset = args.dataset
    cfg.data_path = args.data_path

    ds_cfg = DATASET_CONFIGS[args.dataset]

    # Encoder
    cfg.encoder.input_dim = ds_cfg["input_dim"]
    cfg.encoder.embedding_dim = args.embedding_dim

    # Constraint field
    cfg.constraint.embedding_dim = args.embedding_dim

    # Binding transformer
    cfg.transformer.embedding_dim = args.embedding_dim
    cfg.transformer.num_layers = args.transformer_layers
    cfg.transformer.num_heads = args.num_heads
    cfg.transformer.concept_vocab_size = args.concept_vocab
    cfg.transformer.bottleneck_dim = args.bottleneck_dim

    # Classifier
    cfg.classifier.embedding_dim = args.embedding_dim
    cfg.classifier.num_classes = ds_cfg["num_classes"]

    # Training
    cfg.training.epochs = args.epochs
    cfg.training.batch_size = args.batch_size
    cfg.training.learning_rate = args.lr
    cfg.training.patience = args.patience
    cfg.training.random_seed = args.seed
    cfg.training.lambda_constraint = args.lambda_c
    cfg.training.mu_binding = args.mu_b
    cfg.training.nu_cycle = args.nu_cy

    return cfg


def prepare_synthetic_data(args, cfg):
    """Prepare synthetic dataset for pipeline testing."""
    ds_cfg = DATASET_CONFIGS[args.dataset]
    n_features = ds_cfg["input_dim"]
    n_classes = ds_cfg["num_classes"]

    print(f"Generating synthetic dataset: {args.synthetic_samples} samples, "
          f"{n_features} features, {n_classes} classes")

    features, labels = create_synthetic_dataset(
        n_samples=args.synthetic_samples,
        n_features=n_features,
        n_classes=n_classes,
        random_seed=args.seed,
    )

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        features, labels, test_size=0.2, random_state=args.seed, stratify=labels
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_train, y_train, test_size=0.1, random_state=args.seed, stratify=y_train
    )

    # Standardize
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    # Weighted sampler
    class_counts = np.bincount(y_train, minlength=n_classes)
    weights = 1.0 / (class_counts[y_train] + 1e-8)
    sampler = WeightedRandomSampler(weights, len(y_train), replacement=True)

    bs = cfg.training.batch_size
    data = {
        "train_loader": DataLoader(
            NIDSDataset(X_train, y_train), batch_size=bs,
            sampler=sampler, drop_last=True
        ),
        "val_loader": DataLoader(
            NIDSDataset(X_val, y_val), batch_size=bs, shuffle=False
        ),
        "test_loader": DataLoader(
            NIDSDataset(X_test, y_test), batch_size=bs, shuffle=False
        ),
        "class_names": ds_cfg["class_names"],
        "input_dim": n_features,
        "num_classes": n_classes,
    }

    # Create OSR test set (add the last class as "unknown")
    holdout_class = n_classes - 1
    known_mask = y_test != holdout_class
    osr_labels = np.where(known_mask, y_test, n_classes)
    data["osr_test_loader"] = DataLoader(
        NIDSDataset(scaler.transform(features[labels != holdout_class][-1000:]),
                    np.zeros(1000, dtype=np.int64)),
        batch_size=bs, shuffle=False
    )

    # Simpler OSR: mix test set + relabeled holdout
    osr_features = np.copy(X_test)
    osr_labels = np.copy(y_test)
    osr_labels[y_test == holdout_class] = n_classes
    data["osr_test_loader"] = DataLoader(
        NIDSDataset(osr_features, osr_labels), batch_size=bs, shuffle=False
    )

    return data


def main():
    args = parse_args()

    # ── Setup ──
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    os.makedirs(args.save_dir, exist_ok=True)

    # ── Configuration ──
    cfg = build_config(args)

    # ── Knowledge Base ──
    kb = build_knowledge_base(args.dataset)
    print(f"\n{kb.summary()}")

    # ── Data ──
    if args.synthetic:
        data = prepare_synthetic_data(args, cfg)
    else:
        preprocessor = DataPreprocessor(cfg)
        data = preprocessor.prepare(args.data_path)
        # Update config with actual dimensions
        cfg.encoder.input_dim = data["input_dim"]
        cfg.classifier.num_classes = data["num_classes"]

    print(f"\nConfiguration:")
    print(f"  Encoder:     {cfg.encoder.input_dim}→{cfg.encoder.embedding_dim}")
    print(f"  Transformer: {cfg.transformer.num_layers} layers, "
          f"{cfg.transformer.num_heads} heads")
    print(f"  Concepts:    K={cfg.transformer.concept_vocab_size}")
    print(f"  Loss weights: λ={cfg.training.lambda_constraint}, "
          f"μ={cfg.training.mu_binding}, ν={cfg.training.nu_cycle}")

    # ── Build Model ──
    model = CREST_NIDS(cfg, kb)
    params = model.count_parameters()
    print(f"\nModel Parameters:")
    for name, count in params.items():
        print(f"  {name}: {count:,}")

    # ── Ablation Study ──
    if args.ablation:
        print("\n" + "="*70)
        print("ABLATION STUDY")
        print("="*70)
        results = AblationStudy.run_ablation_suite(
            cfg, kb,
            data["train_loader"], data["val_loader"], data["test_loader"],
            device, data.get("class_names")
        )

        # Save ablation results
        save_path = os.path.join(args.save_dir, "ablation_results.json")
        with open(save_path, "w") as f:
            json.dump(
                {k: {kk: vv for kk, vv in v.items()
                     if not isinstance(vv, np.ndarray)}
                 for k, v in results.items()},
                f, indent=2, default=str
            )
        print(f"\nAblation results saved to {save_path}")
        return

    # ── Training ──
    trainer = Trainer(
        model, cfg, device,
        save_dir=os.path.join(args.save_dir, "checkpoints")
    )

    t0 = time.time()
    history = trainer.train(
        data["train_loader"], data["val_loader"], verbose=True
    )
    train_time = time.time() - t0
    print(f"\nTraining completed in {train_time:.1f}s")

    # Save training history
    history_path = os.path.join(args.save_dir, "training_history.json")
    with open(history_path, "w") as f:
        json.dump(history, f, indent=2)

    # ── Full Evaluation ──
    evaluator = Evaluator(model, device)
    report = evaluator.full_evaluation(
        test_loader=data["test_loader"],
        osr_loader=data.get("osr_test_loader"),
        class_names=data.get("class_names"),
        num_known_classes=cfg.classifier.num_classes,
        adversarial=not args.no_adversarial,
        verbose=True,
    )

    # ── Interpretability Demo ──
    print("\n" + "="*60)
    print("SAMPLE EXPLANATIONS")
    print("="*60)
    sample_batch = next(iter(data["test_loader"]))
    features, labels = sample_batch
    features = features[:5].to(device)
    labels_sample = labels[:5].to(device)

    explanations = model.explain(features, labels_sample)
    for i in range(min(5, features.size(0))):
        pred = explanations["predicted_class"][i].item()
        conf = explanations["confidence"][i].item()
        unc = explanations["uncertainty_score"][i].item()
        unknown = explanations["is_unknown_attack"][i].item()

        class_name = data["class_names"][pred] if pred < len(data.get("class_names", [])) else f"Class_{pred}"
        print(f"\n  Sample {i+1}:")
        print(f"    Prediction: {class_name} (confidence={conf:.3f})")
        print(f"    Uncertainty: {unc:.3f} {'[UNKNOWN ATTACK]' if unknown else ''}")
        if "rule_satisfaction" in explanations:
            for rule, status in explanations["rule_satisfaction"].items():
                print(f"    Rule '{rule}': {status}")

    # ── Save Final Report ──
    report["training_time_seconds"] = train_time
    report["parameters"] = params
    report_path = os.path.join(args.save_dir, "evaluation_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2, default=str)
    print(f"\nFull report saved to {report_path}")

    # ── Save Model ──
    model_path = os.path.join(args.save_dir, "crest_nids_final.pt")
    torch.save({
        "model_state_dict": model.state_dict(),
        "config": cfg,
        "class_names": data.get("class_names"),
    }, model_path)
    print(f"Model saved to {model_path}")


if __name__ == "__main__":
    main()
