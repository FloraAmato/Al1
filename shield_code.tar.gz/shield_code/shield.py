"""
SHIELD Framework
================
Wraps a base classifier with Mondrian Conformal Prediction for:
- Guaranteed coverage
- Selective classification
- Adversarial detection
- OOD / novel attack recognition
- Concept drift monitoring
"""

import numpy as np
from conformal import (
    MondrianConformalPredictor, ConformalPredictor,
    compute_score_entropy, DriftMonitor,
    compute_ncm_scores
)
from train_base import get_predictions, get_device
import config


class SHIELD:
    """
    SHIELD: Selective Hardened IoT Ensemble Learning with Distributional awareness.
    
    Usage:
        shield = SHIELD(model, num_classes, alpha=0.10, use_mondrian=True)
        shield.calibrate(X_cal, y_cal)
        results = shield.predict(X_test)
        metrics = shield.evaluate(X_test, y_test)
    """
    
    def __init__(self, model, num_classes, alpha=None, ncm_type=None,
                 use_mondrian=None, device=None):
        self.model = model
        self.num_classes = num_classes
        self.alpha = alpha or config.DEFAULT_ALPHA
        self.ncm_type = ncm_type or config.NCM_TYPE
        self.use_mondrian = use_mondrian if use_mondrian is not None else config.USE_MONDRIAN
        self.device = device or get_device()
        
        # Build conformal predictor
        if self.use_mondrian:
            self.cp = MondrianConformalPredictor(self.alpha, self.ncm_type)
        else:
            self.cp = ConformalPredictor(self.alpha, self.ncm_type)
        
        self.drift_monitor = None
        self.is_calibrated = False
    
    def calibrate(self, X_cal, y_cal):
        """
        Calibrate SHIELD on the calibration set.
        Computes nonconformity scores and conformal quantiles.
        """
        print(f"\n{'='*60}")
        print(f"SHIELD Calibration (alpha={self.alpha}, NCM={self.ncm_type}, "
              f"Mondrian={self.use_mondrian})")
        print(f"{'='*60}")
        
        # Get model predictions on calibration set
        cal_logits, cal_probs, cal_preds = get_predictions(
            self.model, X_cal, self.device)
        
        cal_acc = (cal_preds == y_cal).mean()
        print(f"[SHIELD] Base model calibration accuracy: {cal_acc:.4f}")
        
        # Calibrate conformal predictor
        self.cp.calibrate(cal_probs, cal_logits, y_cal)
        
        # Initialize drift monitor
        cal_scores = compute_ncm_scores(cal_probs, cal_logits, y_cal, self.ncm_type)
        self.drift_monitor = DriftMonitor(cal_scores)
        
        self.is_calibrated = True
        print(f"[SHIELD] Calibration complete.\n")
    
    def predict(self, X):
        """
        Run SHIELD prediction on test data.
        
        Returns dict with:
            - pred_sets: list of prediction sets
            - set_sizes: array of set sizes
            - point_preds: point predictions (argmax of softmax)
            - shield_preds: SHIELD predictions (point pred if |set|=1, else -1)
            - probs: softmax probabilities
            - logits: raw logits
            - pvalues: conformal p-values (Mondrian only)
            - score_entropy: entropy of p-value distribution
            - decisions: array of {0: predict, 1: abstain, 2: alarm}
        """
        assert self.is_calibrated, "SHIELD must be calibrated first. Call calibrate()."
        
        logits, probs, point_preds = get_predictions(self.model, X, self.device)
        
        # Prediction sets
        pred_sets, set_sizes = self.cp.predict_sets(probs, logits)
        
        # SHIELD decisions
        decisions = np.zeros(len(X), dtype=int)
        shield_preds = np.full(len(X), -1, dtype=int)
        
        for i in range(len(X)):
            if len(pred_sets[i]) == 1:
                decisions[i] = 0  # Confident prediction
                shield_preds[i] = pred_sets[i][0]
            elif len(pred_sets[i]) > 1:
                decisions[i] = 1  # Abstain
            else:
                decisions[i] = 2  # Alarm (empty set)
        
        # P-values and score entropy (Mondrian only)
        pvalues = None
        score_entropy = None
        if self.use_mondrian and hasattr(self.cp, 'compute_pvalues'):
            pvalues = self.cp.compute_pvalues(probs, logits)
            score_entropy = compute_score_entropy(pvalues)
        
        return {
            "pred_sets": pred_sets,
            "set_sizes": set_sizes,
            "point_preds": point_preds,
            "shield_preds": shield_preds,
            "probs": probs,
            "logits": logits,
            "pvalues": pvalues,
            "score_entropy": score_entropy,
            "decisions": decisions,
        }
    
    def evaluate(self, X, y, label="test"):
        """
        Full evaluation of SHIELD on labeled data.
        
        Returns dict of metrics.
        """
        results = self.predict(X)
        
        n = len(y)
        set_sizes = results["set_sizes"]
        decisions = results["decisions"]
        shield_preds = results["shield_preds"]
        point_preds = results["point_preds"]
        pred_sets = results["pred_sets"]
        
        # ── Coverage ──
        coverage = np.mean([y[i] in pred_sets[i] for i in range(n)])
        
        # ── Class-conditional coverage ──
        class_coverage = {}
        for k in range(self.num_classes):
            mask = (y == k)
            if mask.sum() > 0:
                class_coverage[k] = np.mean([y[i] in pred_sets[i] 
                                             for i in range(n) if y[i] == k])
        
        # ── Average prediction set size ──
        apss = np.mean(set_sizes)
        
        # ── Selective accuracy (on |set|=1 samples) ──
        confident_mask = (decisions == 0)
        n_confident = confident_mask.sum()
        if n_confident > 0:
            sel_acc = (shield_preds[confident_mask] == y[confident_mask]).mean()
        else:
            sel_acc = 0.0
        sel_coverage = n_confident / n
        
        # ── Decision distribution ──
        n_predict = (decisions == 0).sum()
        n_abstain = (decisions == 1).sum()
        n_alarm = (decisions == 2).sum()
        
        # ── Base model accuracy (for comparison) ──
        base_acc = (point_preds == y).mean()
        
        metrics = {
            "label": label,
            "n_samples": n,
            "alpha": self.alpha,
            "base_accuracy": base_acc,
            "empirical_coverage": coverage,
            "target_coverage": 1 - self.alpha,
            "coverage_gap": coverage - (1 - self.alpha),
            "apss": apss,
            "selective_accuracy": sel_acc,
            "selective_coverage": sel_coverage,
            "n_predict": n_predict,
            "n_abstain": n_abstain,
            "n_alarm": n_alarm,
            "frac_predict": n_predict / n,
            "frac_abstain": n_abstain / n,
            "frac_alarm": n_alarm / n,
            "class_conditional_coverage": class_coverage,
        }
        
        # Print summary
        print(f"\n{'─'*60}")
        print(f"SHIELD Evaluation [{label}]  (alpha={self.alpha})")
        print(f"{'─'*60}")
        print(f"  Base model accuracy:     {base_acc:.4f}")
        print(f"  Empirical coverage:      {coverage:.4f}  (target: {1-self.alpha:.4f})")
        print(f"  Avg prediction set size: {apss:.3f}")
        print(f"  Selective accuracy:      {sel_acc:.4f}")
        print(f"  Selective coverage:      {sel_coverage:.4f}")
        print(f"  Decisions: Predict={n_predict} ({n_predict/n:.1%}) | "
              f"Abstain={n_abstain} ({n_abstain/n:.1%}) | "
              f"Alarm={n_alarm} ({n_alarm/n:.1%})")
        print(f"{'─'*60}\n")
        
        return metrics, results
    
    def evaluate_adversarial(self, X_clean, X_adv, y, adv_mask):
        """
        Evaluate SHIELD's adversarial detection performance.
        
        Args:
            X_clean: original clean samples
            X_adv: adversarial samples
            y: true labels
            adv_mask: boolean mask of which samples are adversarial
        
        Returns: dict of adversarial detection metrics
        """
        # Evaluate on clean
        res_clean = self.predict(X_clean)
        
        # Evaluate on adversarial
        res_adv = self.predict(X_adv)
        
        # Base model accuracy drop
        base_clean_acc = (res_clean["point_preds"] == y).mean()
        base_adv_acc = (res_adv["point_preds"][adv_mask] == y[adv_mask]).mean()
        
        # SHIELD: adversarial samples flagged via alarm (empty set) or abstain
        adv_decisions = res_adv["decisions"][adv_mask]
        adv_detected_alarm = (adv_decisions == 2).mean()     # empty set
        adv_detected_any = (adv_decisions != 0).mean()       # abstain or alarm
        
        # Clean samples incorrectly flagged (false positive)
        clean_mask = ~adv_mask
        clean_decisions = res_adv["decisions"][clean_mask]
        clean_false_alarm = (clean_decisions == 2).mean()
        clean_false_any = (clean_decisions != 0).mean()
        
        # SHIELD selective accuracy on adversarial data
        confident_mask_adv = (res_adv["decisions"] == 0)
        if confident_mask_adv.sum() > 0:
            sel_acc_adv = (res_adv["shield_preds"][confident_mask_adv] == 
                          y[confident_mask_adv]).mean()
        else:
            sel_acc_adv = 1.0  # vacuously correct if everything is rejected
        
        metrics = {
            "base_clean_accuracy": base_clean_acc,
            "base_adv_accuracy": base_adv_acc,
            "accuracy_drop": base_clean_acc - base_adv_acc,
            "adv_detection_rate_alarm": adv_detected_alarm,
            "adv_detection_rate_any": adv_detected_any,
            "clean_false_alarm_rate": clean_false_alarm,
            "clean_false_any_rate": clean_false_any,
            "shield_selective_accuracy_adv": sel_acc_adv,
            "n_adversarial": adv_mask.sum(),
            "n_clean": clean_mask.sum(),
        }
        
        print(f"\n{'─'*60}")
        print(f"SHIELD Adversarial Evaluation")
        print(f"{'─'*60}")
        print(f"  Base clean accuracy:   {base_clean_acc:.4f}")
        print(f"  Base adv accuracy:     {base_adv_acc:.4f}  (drop: {base_clean_acc-base_adv_acc:.4f})")
        print(f"  Adv detected (alarm):  {adv_detected_alarm:.4f}")
        print(f"  Adv detected (any):    {adv_detected_any:.4f}")
        print(f"  Clean false alarm:     {clean_false_alarm:.4f}")
        print(f"  SHIELD selective acc:  {sel_acc_adv:.4f}")
        print(f"{'─'*60}\n")
        
        return metrics
    
    def evaluate_open_set(self, X_known, y_known, X_novel, y_novel):
        """
        Evaluate SHIELD's open-set recognition.
        Novel samples should produce empty prediction sets.
        """
        # Known classes
        res_known = self.predict(X_known)
        known_coverage = np.mean([y_known[i] in res_known["pred_sets"][i] 
                                  for i in range(len(y_known))])
        known_alarm_rate = (res_known["decisions"] == 2).mean()
        
        # Novel classes
        res_novel = self.predict(X_novel)
        novel_empty_rate = (res_novel["set_sizes"] == 0).mean()
        novel_abstain_rate = (res_novel["decisions"] == 1).mean()
        novel_detected_any = (res_novel["decisions"] != 0).mean()
        
        # Score entropy analysis (if available)
        entropy_stats = {}
        if res_novel["score_entropy"] is not None and res_known["score_entropy"] is not None:
            entropy_stats = {
                "known_entropy_mean": np.mean(res_known["score_entropy"]),
                "novel_entropy_mean": np.mean(res_novel["score_entropy"]),
            }
        
        metrics = {
            "known_coverage": known_coverage,
            "known_alarm_rate": known_alarm_rate,
            "novel_empty_rate": novel_empty_rate,
            "novel_abstain_rate": novel_abstain_rate,
            "novel_detected_any": novel_detected_any,
            "n_known": len(X_known),
            "n_novel": len(X_novel),
            **entropy_stats,
        }
        
        print(f"\n{'─'*60}")
        print(f"SHIELD Open-Set Evaluation")
        print(f"{'─'*60}")
        print(f"  Known coverage:       {known_coverage:.4f}")
        print(f"  Known alarm rate:     {known_alarm_rate:.4f}")
        print(f"  Novel empty set rate: {novel_empty_rate:.4f}")
        print(f"  Novel detected (any): {novel_detected_any:.4f}")
        if entropy_stats:
            print(f"  Known entropy (mean): {entropy_stats['known_entropy_mean']:.4f}")
            print(f"  Novel entropy (mean): {entropy_stats['novel_entropy_mean']:.4f}")
        print(f"{'─'*60}\n")
        
        return metrics
    
    def evaluate_drift(self, X_test_drift, y_test_drift):
        """
        Evaluate SHIELD's performance under concept drift.
        Also tests drift detection capability.
        """
        # Standard evaluation on drifted data
        metrics, results = self.evaluate(X_test_drift, y_test_drift, label="drift")
        
        # Drift detection
        scores_drift = compute_ncm_scores(
            results["probs"], results["logits"], y_test_drift, self.ncm_type)
        
        drift_detected, drift_mean, drift_frac = self.drift_monitor.batch_check(scores_drift)
        
        drift_metrics = {
            **metrics,
            "drift_detected": drift_detected,
            "drift_mean_score": drift_mean,
            "drift_frac_exceeding": drift_frac,
        }
        
        print(f"  Drift detected: {drift_detected}")
        print(f"  Drift mean score: {drift_mean:.4f} (threshold: {self.drift_monitor.threshold:.4f})")
        
        return drift_metrics
    
    def multi_alpha_evaluation(self, X, y, alpha_values=None, label="test"):
        """
        Evaluate across multiple alpha values for risk-coverage curves.
        """
        alpha_values = alpha_values or config.ALPHA_VALUES
        all_metrics = []
        
        original_alpha = self.alpha
        
        for alpha in alpha_values:
            self.alpha = alpha
            # Rebuild CP with new alpha but same calibration data
            # We need to recalibrate (just recomputes quantiles)
            if hasattr(self.cp, 'class_scores') and self.cp.class_scores:
                # Mondrian: recompute quantiles from existing scores
                for k in range(self.num_classes):
                    scores_k = self.cp.class_scores.get(k, np.array([]))
                    if len(scores_k) == 0:
                        self.cp.class_quantiles[k] = np.inf
                        continue
                    n_k = len(scores_k)
                    q_level = np.ceil((n_k + 1) * (1 - alpha)) / n_k
                    q_level = min(q_level, 1.0)
                    self.cp.class_quantiles[k] = np.quantile(scores_k, q_level)
                self.cp.alpha = alpha
            else:
                n = len(self.cp.cal_scores)
                q_level = np.ceil((n + 1) * (1 - alpha)) / n
                q_level = min(q_level, 1.0)
                self.cp.quantile = np.quantile(self.cp.cal_scores, q_level)
                self.cp.alpha = alpha
            
            metrics, _ = self.evaluate(X, y, label=f"{label}_alpha={alpha}")
            all_metrics.append(metrics)
        
        # Restore original alpha
        self.alpha = original_alpha
        
        return all_metrics
