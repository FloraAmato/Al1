"""
SHIELD Data Loader
==================
Handles loading, preprocessing, and splitting CIC-IoT-2023 and ACI-IoT-2023.
Supports both single CSV and multi-CSV folder formats.
"""

import os
import glob
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
import torch
from torch.utils.data import TensorDataset, DataLoader
import config


def detect_label_column(df):
    """Auto-detect the label/target column."""
    candidates = ['label', 'Label', 'LABEL', 'attack_type', 'Attack_type',
                  'class', 'Class', 'category', 'Category', 'target', 'Target']
    for c in candidates:
        if c in df.columns:
            return c
    # Fallback: last column
    print(f"[WARN] No standard label column found. Using last column: '{df.columns[-1]}'")
    return df.columns[-1]


def load_csv_or_folder(path, is_folder=False, max_rows=None):
    """Load a single CSV or concatenate all CSVs in a folder."""
    if is_folder and os.path.isdir(path):
        csv_files = sorted(glob.glob(os.path.join(path, "*.csv")))
        if not csv_files:
            raise FileNotFoundError(f"No CSV files found in {path}")
        print(f"[INFO] Loading {len(csv_files)} CSV files from {path}")
        dfs = []
        rows_loaded = 0
        for f in csv_files:
            df = pd.read_csv(f, low_memory=False)
            dfs.append(df)
            rows_loaded += len(df)
            if max_rows and rows_loaded >= max_rows:
                break
        df = pd.concat(dfs, ignore_index=True)
    else:
        print(f"[INFO] Loading CSV: {path}")
        df = pd.read_csv(path, low_memory=False, nrows=max_rows)
    print(f"[INFO] Loaded {len(df)} rows, {len(df.columns)} columns")
    return df


def preprocess(df, label_col=None, scaler=None, label_encoder=None, fit=True):
    """
    Preprocess the dataframe:
    - Detect/use label column
    - Drop non-numeric, inf, NaN
    - Encode labels
    - Scale features
    
    Returns: X (np.array), y (np.array), scaler, label_encoder, feature_names, label_col
    """
    # Detect label column
    if label_col is None:
        label_col = config.LABEL_COL if config.LABEL_COL else detect_label_column(df)
    
    print(f"[INFO] Label column: '{label_col}'")
    print(f"[INFO] Unique labels: {df[label_col].nunique()}")
    
    # Separate features and labels
    y_raw = df[label_col].copy()
    X_df = df.drop(columns=[label_col])
    
    # Drop non-numeric columns (e.g., timestamps, IPs)
    non_numeric = X_df.select_dtypes(exclude=[np.number]).columns.tolist()
    if non_numeric:
        print(f"[INFO] Dropping non-numeric columns: {non_numeric}")
        X_df = X_df.drop(columns=non_numeric)
    
    # Replace inf with NaN, then fill NaN with 0
    X_df = X_df.replace([np.inf, -np.inf], np.nan)
    X_df = X_df.fillna(0)
    
    feature_names = X_df.columns.tolist()
    X = X_df.values.astype(np.float32)
    
    # Encode labels
    if fit:
        label_encoder = LabelEncoder()
        y = label_encoder.fit_transform(y_raw)
    else:
        # Handle unseen labels during transform
        known_classes = set(label_encoder.classes_)
        y_raw_mapped = y_raw.map(lambda x: x if x in known_classes else "UNKNOWN")
        # Temporarily add UNKNOWN if needed
        if "UNKNOWN" not in known_classes:
            label_encoder.classes_ = np.append(label_encoder.classes_, "UNKNOWN")
        y = label_encoder.transform(y_raw_mapped)
    
    # Scale features
    if fit:
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
    else:
        X = scaler.transform(X)
    
    print(f"[INFO] Features shape: {X.shape}, Labels shape: {y.shape}")
    print(f"[INFO] Class distribution:\n{pd.Series(y).value_counts().to_string()}")
    
    return X, y, scaler, label_encoder, feature_names, label_col


def split_data(X, y, train_ratio=None, cal_ratio=None, test_ratio=None, seed=None):
    """
    Split into train / calibration / test sets.
    """
    train_ratio = train_ratio or config.TRAIN_RATIO
    cal_ratio = cal_ratio or config.CAL_RATIO
    test_ratio = test_ratio or config.TEST_RATIO
    seed = seed or config.SEED
    
    assert abs(train_ratio + cal_ratio + test_ratio - 1.0) < 1e-6, \
        "Ratios must sum to 1.0"
    
    # First split: train vs (cal + test)
    X_train, X_rest, y_train, y_rest = train_test_split(
        X, y, test_size=(cal_ratio + test_ratio),
        random_state=seed, stratify=y
    )
    
    # Second split: cal vs test
    cal_frac = cal_ratio / (cal_ratio + test_ratio)
    X_cal, X_test, y_cal, y_test = train_test_split(
        X_rest, y_rest, test_size=(1 - cal_frac),
        random_state=seed, stratify=y_rest
    )
    
    print(f"[INFO] Split sizes - Train: {len(X_train)}, Cal: {len(X_cal)}, Test: {len(X_test)}")
    return X_train, y_train, X_cal, y_cal, X_test, y_test


def prepare_open_set(X, y, label_encoder, holdout_classes=None, num_auto_holdout=None):
    """
    Prepare open-set scenario: remove specified classes from train/cal,
    keep them only in test.
    
    Returns: X_known, y_known, X_novel, y_novel, known_mask, novel_mask
    """
    holdout_classes = holdout_classes or config.HOLDOUT_CLASSES
    num_auto_holdout = num_auto_holdout or config.NUM_AUTO_HOLDOUT
    
    class_names = label_encoder.classes_
    
    if not holdout_classes:
        # Auto-select rarest classes
        unique, counts = np.unique(y, return_counts=True)
        sorted_idx = np.argsort(counts)
        holdout_indices = unique[sorted_idx[:num_auto_holdout]]
        holdout_classes = [class_names[i] for i in holdout_indices]
    
    print(f"[INFO] Open-set holdout classes: {holdout_classes}")
    
    holdout_indices = [np.where(class_names == c)[0][0] for c in holdout_classes 
                       if c in class_names]
    
    known_mask = ~np.isin(y, holdout_indices)
    novel_mask = np.isin(y, holdout_indices)
    
    X_known, y_known = X[known_mask], y[known_mask]
    X_novel, y_novel = X[novel_mask], y[novel_mask]
    
    print(f"[INFO] Known samples: {len(X_known)}, Novel samples: {len(X_novel)}")
    return X_known, y_known, X_novel, y_novel, holdout_classes, holdout_indices


def make_dataloaders(X_train, y_train, X_cal, y_cal, X_test, y_test, batch_size=None):
    """Create PyTorch DataLoaders."""
    batch_size = batch_size or config.BATCH_SIZE
    
    train_ds = TensorDataset(
        torch.FloatTensor(X_train), torch.LongTensor(y_train))
    cal_ds = TensorDataset(
        torch.FloatTensor(X_cal), torch.LongTensor(y_cal))
    test_ds = TensorDataset(
        torch.FloatTensor(X_test), torch.LongTensor(y_test))
    
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    cal_loader = DataLoader(cal_ds, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)
    
    return train_loader, cal_loader, test_loader


def load_dataset(dataset_name="ciciot"):
    """
    High-level function to load and preprocess a dataset.
    
    Args:
        dataset_name: "ciciot" or "aciiot"
    
    Returns:
        dict with all data splits and metadata
    """
    if dataset_name == "ciciot":
        path = config.CICIOT_PATH
        is_folder = config.CICIOT_IS_FOLDER
    elif dataset_name == "aciiot":
        path = config.ACIIOT_PATH
        is_folder = config.ACIIOT_IS_FOLDER
    else:
        raise ValueError(f"Unknown dataset: {dataset_name}")
    
    df = load_csv_or_folder(path, is_folder=is_folder)
    X, y, scaler, le, feature_names, label_col = preprocess(df)
    X_train, y_train, X_cal, y_cal, X_test, y_test = split_data(X, y)
    
    num_classes = len(le.classes_)
    num_features = X.shape[1]
    
    return {
        "X_train": X_train, "y_train": y_train,
        "X_cal": X_cal, "y_cal": y_cal,
        "X_test": X_test, "y_test": y_test,
        "scaler": scaler, "label_encoder": le,
        "feature_names": feature_names,
        "num_classes": num_classes,
        "num_features": num_features,
        "label_col": label_col,
        "dataset_name": dataset_name,
    }
