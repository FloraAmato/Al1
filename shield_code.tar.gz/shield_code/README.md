# SHIELD: Conformal Prediction for Resilient IoT Intrusion Detection

## Quick Start

### 1. Setup
```bash
pip install -r requirements.txt
```

### 2. Prepare Data
Place your datasets in `./data/`:

**Option A: Folder of CSVs** (recommended for large datasets)
```
data/
├── CICIoT2023/          # folder with multiple CSV files
│   ├── part1.csv
│   ├── part2.csv
│   └── ...
└── ACI-IoT-2023/        # folder with multiple CSV files
    ├── part1.csv
    └── ...
```

**Option B: Single CSV**
```
data/
├── CICIoT2023.csv
└── ACI-IoT-2023.csv
```

Then edit `config.py`:
- Set `DATA_DIR`, `CICIOT_PATH`, `ACIIOT_PATH`
- Set `CICIOT_IS_FOLDER` / `ACIIOT_IS_FOLDER` accordingly
- Set `LABEL_COL` if your label column has a non-standard name

### 3. Run Full Experiment
```bash
# CIC-IoT-2023 with 1D-CNN
python main.py --dataset ciciot --model 1d_cnn

# ACI-IoT-2023 with Attention-DNN
python main.py --dataset aciiot --model attention_dnn

# Custom alpha and NCM
python main.py --dataset ciciot --model 1d_cnn --alpha 0.05 --ncm energy

# Skip training (load pre-trained model)
python main.py --dataset ciciot --model 1d_cnn --model-path results/ciciot_1d_cnn_*/base_model.pt
```

### 4. Results
Results are saved to `./results/<run_name>/`:
- `results.json` — all metrics (clean, adversarial, open-set, baselines)
- `base_model.pt` — trained base classifier weights

## Project Structure

```
shield_code/
├── config.py           # All hyperparameters and paths
├── data_loader.py      # Data loading, preprocessing, splitting
├── models.py           # Base classifiers (1D-CNN, Attention-DNN)
├── train_base.py       # Training loop with early stopping
├── conformal.py        # Core CP: NCMs, Mondrian CP, p-values, drift monitor
├── shield.py           # SHIELD framework (ties everything together)
├── adversarial.py      # FGSM and PGD attack generation
├── main.py             # Full experiment pipeline
├── requirements.txt
└── README.md
```

## What the Pipeline Does

1. **Loads & preprocesses** CIC-IoT-2023 or ACI-IoT-2023
2. **Trains** a base DNN classifier (1D-CNN or Attention-DNN)
3. **Calibrates SHIELD** with Mondrian Conformal Prediction on the calibration set
4. **Evaluates clean performance**: coverage, APSS, selective accuracy
5. **Evaluates adversarial resilience**: FGSM (eps=0.01/0.05/0.10) and PGD (eps=0.05)
6. **Evaluates open-set recognition**: holds out rare attack classes as novel
7. **Runs baselines**: Softmax thresholding, MC-Dropout, Standard CP
8. **Saves all results** to JSON

## Key Configurations (config.py)

| Parameter | Default | Description |
|-----------|---------|-------------|
| `DEFAULT_ALPHA` | 0.10 | Significance level (1-α = target coverage) |
| `NCM_TYPE` | "aps" | Nonconformity measure: "softmax", "aps", "energy" |
| `USE_MONDRIAN` | True | Class-conditional CP for uniform coverage |
| `MODEL_TYPE` | "1d_cnn" | Base classifier architecture |
| `NUM_AUTO_HOLDOUT` | 2 | Number of classes to hold out for open-set |
| `ADV_EPSILONS` | [0.01, 0.05, 0.10] | FGSM perturbation budgets |
