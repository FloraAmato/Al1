"""
SHIELD Base Classifiers
=======================
Two architectures: 1D-CNN and Attention-DNN.
Both output logits (pre-softmax) which SHIELD uses for nonconformity scoring.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class CNN1D(nn.Module):
    """
    1D-CNN for tabular network traffic classification.
    Input: (batch, num_features) -> reshaped to (batch, 1, num_features)
    """
    def __init__(self, num_features, num_classes, hidden_dim=128, dropout=0.3):
        super().__init__()
        self.num_features = num_features
        
        # Conv blocks
        self.conv1 = nn.Sequential(
            nn.Conv1d(1, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2)
        )
        self.conv2 = nn.Sequential(
            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(2)
        )
        self.conv3 = nn.Sequential(
            nn.Conv1d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        
        # FC layers
        self.classifier = nn.Sequential(
            nn.Linear(256, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_classes)
        )
    
    def forward(self, x):
        # x: (batch, num_features)
        x = x.unsqueeze(1)  # (batch, 1, num_features)
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = x.squeeze(-1)   # (batch, 256)
        logits = self.classifier(x)
        return logits
    
    def get_logits(self, x):
        """Alias for forward - returns logits."""
        return self.forward(x)
    
    def predict_proba(self, x):
        """Returns softmax probabilities."""
        logits = self.forward(x)
        return F.softmax(logits, dim=-1)


class MultiHeadSelfAttention(nn.Module):
    """Multi-head self-attention for tabular features."""
    def __init__(self, embed_dim, num_heads=4, dropout=0.1):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        assert embed_dim % num_heads == 0
        
        self.qkv = nn.Linear(embed_dim, 3 * embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.dropout = nn.Dropout(dropout)
        self.scale = math.sqrt(self.head_dim)
    
    def forward(self, x):
        B, N, D = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        attn = (q @ k.transpose(-2, -1)) / self.scale
        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)
        
        out = (attn @ v).transpose(1, 2).reshape(B, N, D)
        out = self.out_proj(out)
        return out


class AttentionDNN(nn.Module):
    """
    Attention-based DNN for tabular classification.
    Treats each feature as a token, applies self-attention, then classifies.
    """
    def __init__(self, num_features, num_classes, hidden_dim=128, num_heads=4, dropout=0.3):
        super().__init__()
        self.num_features = num_features
        
        # Feature embedding: project each scalar feature to hidden_dim
        # We group features into chunks to create a sequence
        self.chunk_size = max(1, num_features // 16)  # ~16 tokens
        self.num_tokens = math.ceil(num_features / self.chunk_size)
        self.pad_size = self.num_tokens * self.chunk_size - num_features
        
        self.embed = nn.Linear(self.chunk_size, hidden_dim)
        self.pos_embed = nn.Parameter(torch.randn(1, self.num_tokens, hidden_dim) * 0.02)
        
        # Attention block
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.attn = MultiHeadSelfAttention(hidden_dim, num_heads, dropout)
        self.norm2 = nn.LayerNorm(hidden_dim)
        self.ffn = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Dropout(dropout),
        )
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_classes)
        )
    
    def forward(self, x):
        B = x.shape[0]
        
        # Pad and reshape into tokens
        if self.pad_size > 0:
            x = F.pad(x, (0, self.pad_size))
        x = x.view(B, self.num_tokens, self.chunk_size)
        
        # Embed
        x = self.embed(x) + self.pos_embed
        
        # Attention block (pre-norm)
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        
        # Pool: mean over tokens
        x = x.mean(dim=1)
        
        logits = self.classifier(x)
        return logits
    
    def get_logits(self, x):
        return self.forward(x)
    
    def predict_proba(self, x):
        logits = self.forward(x)
        return F.softmax(logits, dim=-1)


def build_model(num_features, num_classes, model_type=None, hidden_dim=None, dropout=None):
    """Factory function to build a model."""
    import config as cfg
    model_type = model_type or cfg.MODEL_TYPE
    hidden_dim = hidden_dim or cfg.HIDDEN_DIM
    dropout = dropout or cfg.DROPOUT
    
    if model_type == "1d_cnn":
        return CNN1D(num_features, num_classes, hidden_dim, dropout)
    elif model_type == "attention_dnn":
        return AttentionDNN(num_features, num_classes, hidden_dim, dropout=dropout)
    else:
        raise ValueError(f"Unknown model type: {model_type}")
