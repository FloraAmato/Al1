"""
SHIELD Main Experiment Pipeline
================================
Runs the full experiment:
1. Load & preprocess data
2. Train base classifier
3. Calibrate SHIELD
4. Evaluate: clean, adversarial, drift, open-set
5. Compare baselines (MC-Dropout, Deep Ensemble, Standard CP)
6. Export results

Usage:
    python main.py --dataset ciciot --model 1d_cnn
    python main.py --dataset aciiot --model attention_dnn
    python main.py --dataset ciciot --skip-train --model-path results/ciciot_1d_cnn.pt
"""

import os
import sys
import json
import time
import argparse
import numpy as np
import pandas as pd
import torch
from datetime import datetime

import config
from data_loader import load_dataset, prepare_open_set, make_dataloaders, split_data
from models import build_model
from train_base import train_model, get_predictions, save_model, load_model, get_device
from conformal import MondrianConformalPredictor, ConformalPredictor, compute_ncm_scores
from shield import SHIELD
from adversarial import generate_adversarial


def set_seed(seed=None):
    seed = seed or config.SEED
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def run_baseline_softmax(model, X_test, y_test, threshold=0.9, device=None):
    """Baseline: softmax thresholding."""
    _, probs, preds = get_predictions(model, X_test, device)
    max_probs = probs.max(axis=1)
    
    confident = max_probs >= threshold
    n_confident = confident.sum()
    
    if n_confident > 0:
        sel_acc = (preds[confident] == y_test[confident]).mean()
    else:
        sel_acc = 0.0
    
    return {
        "method": f"Softmax (tau={threshold})",
        "base_accuracy": (preds == y_test).mean(),
        "selective_accuracy": sel_acc,
        "selective_coverage": n_confident / len(y_test),
        "n_predict": int(n_confident),
        "n_abstain": int(len(y_test) - n_confident),
    }


def run_baseline_mc_dropout(model, X_test, y_test, n_forward=50, 
                            threshold=None, device=None):
    """Baseline: MC-Dropout uncertainty."""
    device = device or get_device()
    model = model.to(device)
    
    # Enable dropout at test time
    def enable_dropout(m):
        if isinstance(m, torch.nn.Dropout):
            m.train()
    
    all_probs = []
    for _ in range(n_forward):
        model.eval()
        model.apply(enable_dropout)
        
        with torch.no_grad():
            probs_list = []
            for i in range(0, len(X_test), config.BATCH_SIZE):
                X_b = torch.FloatTensor(X_test[i:i+config.BATCH_SIZE]).to(device)
                logits = model(X_b)
                probs_list.append(torch.softmax(logits, dim=-1).cpu().numpy())
            all_probs.append(np.concatenate(probs_list))
    
    model.eval()  # restore
    
    # Stack: (n_forward, n_samples, n_classes)
    stacked = np.stack(all_probs, axis=0)
    mean_probs = stacked.mean(axis=0)
    preds = mean_probs.argmax(axis=1)
    
    # Predictive entropy as uncertainty
    entropy = -np.sum(mean_probs * np.log(mean_probs + 1e-10), axis=1)
    
    # Threshold: reject high entropy
    if threshold is None:
        threshold = np.percentile(entropy, 80)  # top 20% most uncertain
    
    confident = entropy <= threshold
    n_confident = confident.sum()
    
    if n_confident > 0:
        sel_acc = (preds[confident] == y_test[confident]).mean()
    else:
        sel_acc = 0.0
    
    return {
        "method": "MC-Dropout",
        "base_accuracy": (preds == y_test).mean(),
        "selective_accuracy": sel_acc,
        "selective_coverage": n_confident / len(y_test),
        "n_predict": int(n_confident),
        "n_abstain": int(len(y_test) - n_confident),
        "entropy_threshold": float(threshold),
    }


def run_baseline_standard_cp(model, X_cal, y_cal, X_test, y_test, 
                              alpha=None, device=None):
    """Baseline: standard (non-Mondrian) conformal prediction."""
    alpha = alpha or config.DEFAULT_ALPHA
    device = device or get_device()
    
    cal_logits, cal_probs, _ = get_predictions(model, X_cal, device)
    test_logits, test_probs, _ = get_predictions(model, X_test, device)
    
    cp = ConformalPredictor(alpha=alpha, ncm_type=config.NCM_TYPE)
    cp.calibrate(cal_probs, cal_logits, y_cal)
    
    pred_sets, set_sizes = cp.predict_sets(test_probs, test_logits)
    
    coverage = np.mean([y_test[i] in pred_sets[i] for i in range(len(y_test))])
    apss = np.mean(set_sizes)
    
    confident = (set_sizes == 1)
    n_confident = confident.sum()
    if n_confident > 0:
        shield_preds = np.array([pred_sets[i][0] if len(pred_sets[i]) == 1 else -1 
                                 for i in range(len(y_test))])
        sel_acc = (shield_preds[confident] == y_test[confident]).mean()
    else:
        sel_acc = 0.0
    
    return {
        "method": "Standard CP",
        "alpha": alpha,
        "empirical_coverage": float(coverage),
        "apss": float(apss),
        "selective_accuracy": float(sel_acc),
        "selective_coverage": float(n_confident / len(y_test)),
        "n_predict": int(n_confident),
        "n_abstain": int((set_sizes > 1).sum()),
        "n_alarm": int((set_sizes == 0).sum()),
    }


def main(args):
    set_seed()
    device = get_device()
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_name = f"{args.dataset}_{args.model}_{timestamp}"
    run_dir = os.path.join(config.OUTPUT_DIR, run_name)
    os.makedirs(run_dir, exist_ok=True)
    
    print(f"\n{'='*70}")
    print(f"  SHIELD Experiment: {run_name}")
    print(f"  Dataset: {args.dataset} | Model: {args.model}")
    print(f"  Device: {device}")
    print(f"{'='*70}\n")
    
    all_results = {}
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 1: Load Data
    # ══════════════════════════════════════════════════════════════════════════
    print("[STEP 1] Loading data...")
    data = load_dataset(args.dataset)
    
    X_train, y_train = data["X_train"], data["y_train"]
    X_cal, y_cal = data["X_cal"], data["y_cal"]
    X_test, y_test = data["X_test"], data["y_test"]
    num_features = data["num_features"]
    num_classes = data["num_classes"]
    le = data["label_encoder"]
    
    print(f"\n  Classes ({num_classes}): {list(le.classes_)}")
    
    # Create DataLoaders
    train_loader, cal_loader, test_loader = make_dataloaders(
        X_train, y_train, X_cal, y_cal, X_test, y_test)
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 2: Train or Load Base Classifier
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 2] Building base classifier...")
    model = build_model(num_features, num_classes, model_type=args.model)
    print(f"  Model: {args.model}, Parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    if args.model_path and os.path.exists(args.model_path):
        model = load_model(model, args.model_path, device)
    else:
        print("\n  Training base classifier...")
        model, history = train_model(model, train_loader, cal_loader, device=device)
        
        if config.SAVE_MODELS:
            model_path = os.path.join(run_dir, "base_model.pt")
            save_model(model, model_path)
    
    # Base model evaluation
    _, _, base_preds = get_predictions(model, X_test, device)
    base_acc = (base_preds == y_test).mean()
    print(f"\n  Base model test accuracy: {base_acc:.4f}")
    all_results["base_accuracy"] = float(base_acc)
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 3: Calibrate SHIELD
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 3] Calibrating SHIELD...")
    shield = SHIELD(model, num_classes, alpha=config.DEFAULT_ALPHA,
                    ncm_type=config.NCM_TYPE, use_mondrian=True, device=device)
    shield.calibrate(X_cal, y_cal)
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 4: Evaluate on Clean Test Data
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 4] Evaluating on clean test data...")
    clean_metrics, clean_results = shield.evaluate(X_test, y_test, label="clean_test")
    all_results["clean_test"] = clean_metrics
    
    # Multi-alpha evaluation
    print("\n  Multi-alpha evaluation...")
    multi_alpha = shield.multi_alpha_evaluation(X_test, y_test, label="clean")
    all_results["multi_alpha"] = multi_alpha
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 5: Adversarial Resilience (Scenario 1)
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 5] Adversarial evaluation...")
    adv_results = {}
    
    for attack in ["fgsm", "pgd"]:
        epsilons = config.ADV_EPSILONS if attack == "fgsm" else [0.05]
        for eps in epsilons:
            print(f"\n  --- {attack.upper()} eps={eps} ---")
            X_adv, adv_mask = generate_adversarial(
                model, X_test, y_test, attack_type=attack, epsilon=eps, device=device)
            
            adv_metrics = shield.evaluate_adversarial(X_test, X_adv, y_test, adv_mask)
            key = f"{attack}_eps{eps}"
            adv_results[key] = adv_metrics
    
    all_results["adversarial"] = adv_results
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 6: Open-Set Novel Attack Detection (Scenario 3)
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 6] Open-set evaluation...")
    
    # Reload full data and create open-set split
    data_full = load_dataset(args.dataset)
    X_all = np.concatenate([data_full["X_train"], data_full["X_cal"], data_full["X_test"]])
    y_all = np.concatenate([data_full["y_train"], data_full["y_cal"], data_full["y_test"]])
    
    X_known, y_known, X_novel, y_novel, holdout_names, holdout_idx = prepare_open_set(
        X_all, y_all, le)
    
    if len(X_novel) > 0:
        # Re-split known data
        X_tr_os, y_tr_os, X_cal_os, y_cal_os, X_te_os, y_te_os = split_data(X_known, y_known)
        
        # Re-encode labels for known classes only (contiguous)
        from sklearn.preprocessing import LabelEncoder
        le_known = LabelEncoder()
        y_tr_os = le_known.fit_transform(y_tr_os)
        y_cal_os = le_known.transform(y_cal_os)
        y_te_os = le_known.transform(y_te_os)
        num_known = len(le_known.classes_)
        
        # Train new model on known classes only
        print(f"\n  Training open-set model ({num_known} known classes)...")
        model_os = build_model(num_features, num_known, model_type=args.model)
        train_loader_os, cal_loader_os, _ = make_dataloaders(
            X_tr_os, y_tr_os, X_cal_os, y_cal_os, X_te_os, y_te_os)
        model_os, _ = train_model(model_os, train_loader_os, cal_loader_os, 
                                   device=device, verbose=False)
        
        # Calibrate SHIELD on known classes
        shield_os = SHIELD(model_os, num_known, alpha=config.DEFAULT_ALPHA,
                           ncm_type=config.NCM_TYPE, use_mondrian=True, device=device)
        shield_os.calibrate(X_cal_os, y_cal_os)
        
        # Evaluate open-set
        # Limit novel samples to keep evaluation manageable
        n_novel_eval = min(len(X_novel), len(X_te_os))
        openset_metrics = shield_os.evaluate_open_set(
            X_te_os, y_te_os, X_novel[:n_novel_eval], y_novel[:n_novel_eval])
        all_results["open_set"] = openset_metrics
    else:
        print("  [SKIP] Not enough novel classes for open-set evaluation.")
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 7: Baselines Comparison
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 7] Running baselines...")
    baselines = {}
    
    # Softmax thresholding
    for tau in [0.8, 0.9, 0.95]:
        res = run_baseline_softmax(model, X_test, y_test, threshold=tau, device=device)
        baselines[f"softmax_tau{tau}"] = res
        print(f"  Softmax (tau={tau}): SelAcc={res['selective_accuracy']:.4f}, "
              f"Coverage={res['selective_coverage']:.4f}")
    
    # MC-Dropout
    print("  Running MC-Dropout (50 passes)...")
    mc_res = run_baseline_mc_dropout(model, X_test, y_test, device=device)
    baselines["mc_dropout"] = mc_res
    print(f"  MC-Dropout: SelAcc={mc_res['selective_accuracy']:.4f}, "
          f"Coverage={mc_res['selective_coverage']:.4f}")
    
    # Standard (non-Mondrian) CP
    std_cp_res = run_baseline_standard_cp(
        model, X_cal, y_cal, X_test, y_test, device=device)
    baselines["standard_cp"] = std_cp_res
    print(f"  Standard CP: SelAcc={std_cp_res['selective_accuracy']:.4f}, "
          f"Coverage={std_cp_res['selective_coverage']:.4f}")
    
    all_results["baselines"] = baselines
    
    # ══════════════════════════════════════════════════════════════════════════
    # STEP 8: Save Results
    # ══════════════════════════════════════════════════════════════════════════
    print("\n[STEP 8] Saving results...")
    
    # Convert numpy types for JSON serialization
    def convert(obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        elif isinstance(obj, (np.floating,)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert(v) for v in obj]
        return obj
    
    results_path = os.path.join(run_dir, "results.json")
    with open(results_path, "w") as f:
        json.dump(convert(all_results), f, indent=2)
    print(f"  Results saved to {results_path}")
    
    # ══════════════════════════════════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════════════════════════════════
    print(f"\n{'='*70}")
    print(f"  SHIELD EXPERIMENT COMPLETE")
    print(f"{'='*70}")
    print(f"  Dataset:        {args.dataset}")
    print(f"  Model:          {args.model}")
    print(f"  Base Accuracy:  {base_acc:.4f}")
    print(f"  SHIELD SelAcc:  {clean_metrics['selective_accuracy']:.4f} "
          f"(coverage: {clean_metrics['selective_coverage']:.4f})")
    print(f"  Coverage:       {clean_metrics['empirical_coverage']:.4f} "
          f"(target: {1-config.DEFAULT_ALPHA:.4f})")
    print(f"  APSS:           {clean_metrics['apss']:.3f}")
    print(f"  Results:        {run_dir}")
    print(f"{'='*70}\n")
    
    return all_results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SHIELD Experiment Pipeline")
    parser.add_argument("--dataset", type=str, default="ciciot",
                        choices=["ciciot", "aciiot"],
                        help="Dataset to use")
    parser.add_argument("--model", type=str, default="1d_cnn",
                        choices=["1d_cnn", "attention_dnn"],
                        help="Base classifier architecture")
    parser.add_argument("--model-path", type=str, default=None,
                        help="Path to pre-trained model (skip training)")
    parser.add_argument("--alpha", type=float, default=None,
                        help="Override default alpha")
    parser.add_argument("--ncm", type=str, default=None,
                        choices=["softmax", "aps", "energy"],
                        help="Override NCM type")
    
    args = parser.parse_args()
    
    if args.alpha:
        config.DEFAULT_ALPHA = args.alpha
    if args.ncm:
        config.NCM_TYPE = args.ncm
    
    main(args)
