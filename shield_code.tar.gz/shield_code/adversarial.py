"""
SHIELD Adversarial Attack Generation
=====================================
Implements FGSM and PGD attacks on network traffic features.
Includes feature constraint enforcement.
"""

import numpy as np
import torch
import torch.nn as nn
import config


def fgsm_attack(model, X, y, epsilon, device=None):
    """
    Fast Gradient Sign Method (Goodfellow et al., 2014).
    
    Args:
        model: PyTorch model
        X: numpy array (n, d)
        y: numpy array (n,) true labels
        epsilon: perturbation budget
        device: torch device
    
    Returns:
        X_adv: numpy array of adversarial examples
    """
    from train_base import get_device
    device = device or get_device()
    model = model.to(device)
    model.eval()
    
    X_t = torch.FloatTensor(X).to(device)
    y_t = torch.LongTensor(y).to(device)
    X_t.requires_grad = True
    
    logits = model(X_t)
    loss = nn.CrossEntropyLoss()(logits, y_t)
    loss.backward()
    
    # FGSM perturbation
    grad_sign = X_t.grad.data.sign()
    X_adv = X_t + epsilon * grad_sign
    X_adv = X_adv.detach().cpu().numpy()
    
    return X_adv


def pgd_attack(model, X, y, epsilon, step_size=None, num_steps=None, device=None):
    """
    Projected Gradient Descent (Madry et al., 2018).
    
    Args:
        model: PyTorch model
        X: numpy array (n, d)
        y: numpy array (n,) true labels
        epsilon: perturbation budget (L-inf)
        step_size: per-step size (default: epsilon/4)
        num_steps: number of PGD steps
        device: torch device
    
    Returns:
        X_adv: numpy array of adversarial examples
    """
    from train_base import get_device
    device = device or get_device()
    step_size = step_size or config.PGD_STEP_SIZE
    num_steps = num_steps or config.PGD_STEPS
    
    model = model.to(device)
    model.eval()
    
    X_orig = torch.FloatTensor(X).to(device)
    y_t = torch.LongTensor(y).to(device)
    
    # Initialize with random perturbation within epsilon ball
    delta = torch.zeros_like(X_orig).uniform_(-epsilon, epsilon).to(device)
    delta.requires_grad = True
    
    for step in range(num_steps):
        X_adv = X_orig + delta
        logits = model(X_adv)
        loss = nn.CrossEntropyLoss()(logits, y_t)
        loss.backward()
        
        # PGD step
        grad_sign = delta.grad.data.sign()
        delta.data = delta.data + step_size * grad_sign
        
        # Project back to epsilon ball
        delta.data = torch.clamp(delta.data, -epsilon, epsilon)
        
        delta.grad.zero_()
    
    X_adv = (X_orig + delta).detach().cpu().numpy()
    return X_adv


def generate_adversarial(model, X, y, attack_type="fgsm", epsilon=0.05,
                         attack_only_classes=None, device=None):
    """
    Generate adversarial examples.
    
    Args:
        model: trained PyTorch model
        X: numpy array (n, d)
        y: numpy array (n,)
        attack_type: "fgsm" or "pgd"
        epsilon: perturbation budget
        attack_only_classes: if set, only perturb samples of these classes
                            (e.g., attack classes to evade as benign)
        device: torch device
    
    Returns:
        X_adv: adversarial examples (same shape as X)
        adv_mask: boolean mask indicating which samples were perturbed
    """
    # Select which samples to attack
    if attack_only_classes is not None:
        adv_mask = np.isin(y, attack_only_classes)
    else:
        # Attack all non-benign samples (assuming class 0 is benign)
        adv_mask = (y != 0)
    
    X_adv = X.copy()
    
    if adv_mask.sum() == 0:
        print("[ADV] No samples to attack.")
        return X_adv, adv_mask
    
    X_to_attack = X[adv_mask]
    y_to_attack = y[adv_mask]
    
    print(f"[ADV] Generating {attack_type.upper()} (eps={epsilon}) "
          f"on {len(X_to_attack)} samples...")
    
    # Process in batches to avoid OOM
    batch_size = min(2048, len(X_to_attack))
    adv_parts = []
    
    for i in range(0, len(X_to_attack), batch_size):
        X_batch = X_to_attack[i:i+batch_size]
        y_batch = y_to_attack[i:i+batch_size]
        
        if attack_type == "fgsm":
            adv_batch = fgsm_attack(model, X_batch, y_batch, epsilon, device)
        elif attack_type == "pgd":
            adv_batch = pgd_attack(model, X_batch, y_batch, epsilon, device=device)
        else:
            raise ValueError(f"Unknown attack type: {attack_type}")
        
        adv_parts.append(adv_batch)
    
    X_adv[adv_mask] = np.concatenate(adv_parts, axis=0)
    
    # Report attack effectiveness
    from train_base import get_predictions
    _, _, preds_clean = get_predictions(model, X[adv_mask], device)
    _, _, preds_adv = get_predictions(model, X_adv[adv_mask], device)
    
    clean_acc = (preds_clean == y[adv_mask]).mean()
    adv_acc = (preds_adv == y[adv_mask]).mean()
    evasion_rate = 1.0 - adv_acc
    
    print(f"[ADV] Clean accuracy on attacked samples: {clean_acc:.4f}")
    print(f"[ADV] Adversarial accuracy: {adv_acc:.4f}")
    print(f"[ADV] Evasion rate: {evasion_rate:.4f}")
    
    return X_adv, adv_mask
