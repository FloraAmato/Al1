"""
SHIELD Base Classifier Training
================================
Standard training loop with early stopping.
"""

import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import classification_report, accuracy_score
import config


def get_device():
    if config.DEVICE == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(config.DEVICE)


def train_model(model, train_loader, val_loader=None, num_epochs=None,
                lr=None, patience=None, device=None, verbose=True):
    """
    Train the base classifier with cross-entropy loss and early stopping.
    
    If val_loader is None, uses train loss for early stopping (not ideal but functional).
    """
    num_epochs = num_epochs or config.NUM_EPOCHS
    lr = lr or config.LEARNING_RATE
    patience = patience or config.PATIENCE
    device = device or get_device()
    
    model = model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', 
                                                       factor=0.5, patience=5)
    
    best_loss = float('inf')
    best_state = None
    patience_counter = 0
    history = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
    
    print(f"[TRAIN] Device: {device}, Epochs: {num_epochs}, LR: {lr}")
    
    for epoch in range(num_epochs):
        # ── Training ──
        model.train()
        train_loss = 0.0
        correct = 0
        total = 0
        
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            
            optimizer.zero_grad()
            logits = model(X_batch)
            loss = criterion(logits, y_batch)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            train_loss += loss.item() * X_batch.size(0)
            preds = logits.argmax(dim=-1)
            correct += (preds == y_batch).sum().item()
            total += y_batch.size(0)
        
        train_loss /= total
        train_acc = correct / total
        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        
        # ── Validation ──
        val_loss, val_acc = train_loss, train_acc  # defaults if no val_loader
        if val_loader is not None:
            val_loss, val_acc = evaluate_model(model, val_loader, criterion, device)
        
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)
        
        scheduler.step(val_loss)
        
        # ── Early stopping ──
        if val_loss < best_loss:
            best_loss = val_loss
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience_counter = 0
        else:
            patience_counter += 1
        
        if verbose and (epoch + 1) % 5 == 0:
            print(f"  Epoch {epoch+1}/{num_epochs} | "
                  f"Train Loss: {train_loss:.4f} Acc: {train_acc:.4f} | "
                  f"Val Loss: {val_loss:.4f} Acc: {val_acc:.4f} | "
                  f"Patience: {patience_counter}/{patience}")
        
        if patience_counter >= patience:
            print(f"[TRAIN] Early stopping at epoch {epoch+1}")
            break
    
    # Restore best model
    if best_state is not None:
        model.load_state_dict(best_state)
        model = model.to(device)
    
    print(f"[TRAIN] Done. Best val loss: {best_loss:.4f}")
    return model, history


def evaluate_model(model, loader, criterion=None, device=None):
    """Evaluate model on a DataLoader. Returns (loss, accuracy)."""
    device = device or get_device()
    if criterion is None:
        criterion = nn.CrossEntropyLoss()
    
    model.eval()
    total_loss = 0.0
    correct = 0
    total = 0
    
    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            logits = model(X_batch)
            loss = criterion(logits, y_batch)
            total_loss += loss.item() * X_batch.size(0)
            preds = logits.argmax(dim=-1)
            correct += (preds == y_batch).sum().item()
            total += y_batch.size(0)
    
    return total_loss / total, correct / total


def get_predictions(model, X, device=None, batch_size=None):
    """
    Get logits and softmax probabilities for a numpy array X.
    
    Returns: logits (np.array), probs (np.array), preds (np.array)
    """
    device = device or get_device()
    batch_size = batch_size or config.BATCH_SIZE
    model = model.to(device)
    model.eval()
    
    all_logits = []
    all_probs = []
    all_preds = []
    
    with torch.no_grad():
        for i in range(0, len(X), batch_size):
            X_batch = torch.FloatTensor(X[i:i+batch_size]).to(device)
            logits = model.get_logits(X_batch)
            probs = torch.softmax(logits, dim=-1)
            preds = probs.argmax(dim=-1)
            
            all_logits.append(logits.cpu().numpy())
            all_probs.append(probs.cpu().numpy())
            all_preds.append(preds.cpu().numpy())
    
    return (np.concatenate(all_logits),
            np.concatenate(all_probs),
            np.concatenate(all_preds))


def save_model(model, path):
    """Save model weights."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(model.state_dict(), path)
    print(f"[SAVE] Model saved to {path}")


def load_model(model, path, device=None):
    """Load model weights."""
    device = device or get_device()
    model.load_state_dict(torch.load(path, map_location=device))
    model = model.to(device)
    model.eval()
    print(f"[LOAD] Model loaded from {path}")
    return model
