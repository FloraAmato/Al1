"""
SHIELD Configuration
====================
Central configuration for all experiments.
Adjust DATA_DIR to point to your CIC-IoT-2023 and ACI-IoT-2023 CSV files.
"""

import os

# ── Data paths ────────────────────────────────────────────────────────────────
DATA_DIR = "./data"  # <-- Change this to your data folder
CICIOT_PATH = os.path.join(DATA_DIR, "CICIoT2023.csv")      # or folder of CSVs
ACIIOT_PATH = os.path.join(DATA_DIR, "ACI-IoT-2023.csv")    # or folder of CSVs

# If your datasets are split across multiple CSVs in a folder, set these:
CICIOT_IS_FOLDER = True   # True if DATA_DIR/CICIoT2023/ contains multiple CSVs
ACIIOT_IS_FOLDER = True

# ── Label column name (auto-detected if None) ────────────────────────────────
LABEL_COL = None  # Will auto-detect: 'label', 'Label', 'attack_type', etc.

# ── Splits ────────────────────────────────────────────────────────────────────
TRAIN_RATIO = 0.60
CAL_RATIO   = 0.20
TEST_RATIO  = 0.20

# ── Model ─────────────────────────────────────────────────────────────────────
MODEL_TYPE = "1d_cnn"       # "1d_cnn" or "attention_dnn"
HIDDEN_DIM = 128
NUM_EPOCHS = 50
BATCH_SIZE = 1024
LEARNING_RATE = 1e-3
DROPOUT = 0.3
PATIENCE = 10               # Early stopping patience

# ── Conformal Prediction ──────────────────────────────────────────────────────
ALPHA_VALUES = [0.01, 0.05, 0.10, 0.15, 0.20]  # Significance levels to evaluate
DEFAULT_ALPHA = 0.10
NCM_TYPE = "aps"            # "softmax", "aps", or "energy"
ENERGY_TEMPERATURE = 1.0
USE_MONDRIAN = True         # True = class-conditional CP

# ── Adversarial Attacks ───────────────────────────────────────────────────────
ADV_EPSILONS = [0.01, 0.05, 0.10]
PGD_STEPS = 20
PGD_STEP_SIZE = 0.01

# ── Concept Drift ─────────────────────────────────────────────────────────────
DRIFT_WINDOW_SIZE = 1000    # Sliding window for drift monitoring
DRIFT_THRESHOLD_PERCENTILE = 95  # Percentile of calibration scores for drift alert

# ── Open-Set ──────────────────────────────────────────────────────────────────
# Classes to hold out as "novel" (by name). If empty, auto-selects 2 rarest classes.
HOLDOUT_CLASSES = []
NUM_AUTO_HOLDOUT = 2        # Number of classes to auto-hold-out if HOLDOUT_CLASSES is empty

# ── Output ────────────────────────────────────────────────────────────────────
OUTPUT_DIR = "./results"
SAVE_MODELS = True
DEVICE = "auto"             # "auto", "cuda", "cpu"
SEED = 42
