"""
SHIELD Conformal Prediction Core
=================================
Implements:
- Nonconformity Measures: Softmax, APS, Energy
- Inductive Conformal Prediction (standard + Mondrian)
- Prediction set construction
- Conformal p-values
- Adaptive recalibration for drift
"""

import numpy as np
from collections import defaultdict
import config


# ═══════════════════════════════════════════════════════════════════════════════
# NONCONFORMITY MEASURES (NCMs)
# ═══════════════════════════════════════════════════════════════════════════════

def ncm_softmax(probs, y):
    """
    Simple softmax NCM: s(x,y) = 1 - f(x)_y
    Higher = more nonconforming.
    """
    return 1.0 - probs[np.arange(len(y)), y]


def ncm_aps(probs, y):
    """
    Adaptive Prediction Sets (APS) NCM (Romano et al., 2020).
    Accumulates sorted softmax mass until the true class is included.
    Uses randomization for exact coverage.
    """
    n = len(y)
    scores = np.zeros(n)
    
    for i in range(n):
        p = probs[i]
        sorted_idx = np.argsort(-p)  # descending
        cumsum = 0.0
        u = np.random.uniform(0, 1)
        for j, idx in enumerate(sorted_idx):
            if idx == y[i]:
                scores[i] = cumsum + u * p[idx]
                break
            cumsum += p[idx]
    
    return scores


def ncm_energy(logits, y, T=None):
    """
    Energy-based NCM (Liu et al., 2020).
    s(x,y) = -T * log(exp(z_y/T) / sum(exp(z_k/T)))
    Equivalent to -T * log_softmax(z/T)_y  =  T * (-log_softmax)_y
    """
    T = T or config.ENERGY_TEMPERATURE
    # Log-softmax at temperature T
    z = logits / T
    z_max = z.max(axis=1, keepdims=True)
    log_sum_exp = np.log(np.exp(z - z_max).sum(axis=1, keepdims=True)) + z_max
    log_softmax = z - log_sum_exp
    
    scores = -T * log_softmax[np.arange(len(y)), y]
    return scores


def compute_ncm_scores(probs, logits, y, ncm_type=None):
    """Compute nonconformity scores given the NCM type."""
    ncm_type = ncm_type or config.NCM_TYPE
    
    if ncm_type == "softmax":
        return ncm_softmax(probs, y)
    elif ncm_type == "aps":
        return ncm_aps(probs, y)
    elif ncm_type == "energy":
        return ncm_energy(logits, y)
    else:
        raise ValueError(f"Unknown NCM type: {ncm_type}")


def compute_ncm_all_classes(probs, logits, num_classes, ncm_type=None):
    """
    Compute NCM scores for ALL classes for each sample.
    Returns: (n_samples, num_classes) array of scores.
    Used for prediction set construction.
    """
    ncm_type = ncm_type or config.NCM_TYPE
    n = len(probs)
    all_scores = np.zeros((n, num_classes))
    
    for k in range(num_classes):
        y_k = np.full(n, k)
        if ncm_type == "softmax":
            all_scores[:, k] = ncm_softmax(probs, y_k)
        elif ncm_type == "aps":
            all_scores[:, k] = ncm_aps(probs, y_k)
        elif ncm_type == "energy":
            all_scores[:, k] = ncm_energy(logits, y_k)
    
    return all_scores


# ═══════════════════════════════════════════════════════════════════════════════
# CONFORMAL PREDICTION
# ═══════════════════════════════════════════════════════════════════════════════

class ConformalPredictor:
    """
    Inductive Conformal Predictor (standard marginal).
    """
    
    def __init__(self, alpha=None, ncm_type=None):
        self.alpha = alpha or config.DEFAULT_ALPHA
        self.ncm_type = ncm_type or config.NCM_TYPE
        self.cal_scores = None
        self.quantile = None
        self.num_classes = None
    
    def calibrate(self, cal_probs, cal_logits, cal_y):
        """Compute calibration scores and conformal quantile."""
        self.num_classes = cal_probs.shape[1]
        self.cal_scores = compute_ncm_scores(cal_probs, cal_logits, cal_y, self.ncm_type)
        
        n = len(self.cal_scores)
        q_level = np.ceil((n + 1) * (1 - self.alpha)) / n
        q_level = min(q_level, 1.0)
        self.quantile = np.quantile(self.cal_scores, q_level)
        
        print(f"[CP] Calibrated with {n} samples. Quantile ({1-self.alpha:.0%}): {self.quantile:.4f}")
    
    def predict_sets(self, test_probs, test_logits):
        """
        Construct prediction sets for test samples.
        
        Returns:
            sets: list of lists (prediction sets)
            set_sizes: np.array of set sizes
        """
        all_scores = compute_ncm_all_classes(
            test_probs, test_logits, self.num_classes, self.ncm_type)
        
        sets = []
        for i in range(len(test_probs)):
            pred_set = [k for k in range(self.num_classes) 
                        if all_scores[i, k] <= self.quantile]
            sets.append(pred_set)
        
        set_sizes = np.array([len(s) for s in sets])
        return sets, set_sizes


class MondrianConformalPredictor:
    """
    Mondrian (Class-Conditional) Conformal Predictor.
    Maintains separate calibration per class for uniform coverage.
    """
    
    def __init__(self, alpha=None, ncm_type=None):
        self.alpha = alpha or config.DEFAULT_ALPHA
        self.ncm_type = ncm_type or config.NCM_TYPE
        self.class_scores = {}     # {class_k: np.array of scores}
        self.class_quantiles = {}  # {class_k: float}
        self.num_classes = None
    
    def calibrate(self, cal_probs, cal_logits, cal_y):
        """Compute per-class calibration scores and quantiles."""
        self.num_classes = cal_probs.shape[1]
        
        # Compute scores for each sample w.r.t. its true class
        all_cal_scores = compute_ncm_scores(cal_probs, cal_logits, cal_y, self.ncm_type)
        
        # Group by class
        self.class_scores = {}
        self.class_quantiles = {}
        
        for k in range(self.num_classes):
            mask = (cal_y == k)
            if mask.sum() == 0:
                print(f"[MONDRIAN] Warning: class {k} has 0 calibration samples")
                self.class_scores[k] = np.array([])
                self.class_quantiles[k] = np.inf  # Never include this class
                continue
            
            scores_k = all_cal_scores[mask]
            self.class_scores[k] = scores_k
            
            n_k = len(scores_k)
            q_level = np.ceil((n_k + 1) * (1 - self.alpha)) / n_k
            q_level = min(q_level, 1.0)
            self.class_quantiles[k] = np.quantile(scores_k, q_level)
        
        print(f"[MONDRIAN] Calibrated {self.num_classes} classes. "
              f"Quantiles range: [{min(self.class_quantiles.values()):.4f}, "
              f"{max(self.class_quantiles.values()):.4f}]")
    
    def predict_sets(self, test_probs, test_logits):
        """
        Construct Mondrian prediction sets.
        Each class k is included if s(x, k) <= q_hat_k.
        """
        all_scores = compute_ncm_all_classes(
            test_probs, test_logits, self.num_classes, self.ncm_type)
        
        sets = []
        for i in range(len(test_probs)):
            pred_set = [k for k in range(self.num_classes) 
                        if all_scores[i, k] <= self.class_quantiles.get(k, np.inf)]
            sets.append(pred_set)
        
        set_sizes = np.array([len(s) for s in sets])
        return sets, set_sizes
    
    def compute_pvalues(self, test_probs, test_logits):
        """
        Compute conformal p-values for each test sample w.r.t. each class.
        
        Returns: (n_test, num_classes) array of p-values.
        """
        all_scores = compute_ncm_all_classes(
            test_probs, test_logits, self.num_classes, self.ncm_type)
        
        n_test = len(test_probs)
        pvalues = np.zeros((n_test, self.num_classes))
        
        for k in range(self.num_classes):
            cal_k = self.class_scores.get(k, np.array([]))
            n_k = len(cal_k)
            if n_k == 0:
                pvalues[:, k] = 0.0
                continue
            
            for i in range(n_test):
                # p_k(x) = (|{s_j >= s(x,k)}| + 1) / (n_k + 1)
                pvalues[i, k] = (np.sum(cal_k >= all_scores[i, k]) + 1) / (n_k + 1)
        
        return pvalues
    
    def recalibrate(self, new_probs, new_logits, new_y):
        """
        Adaptive recalibration with new labeled data (for drift handling).
        Replaces calibration scores and recomputes quantiles.
        """
        print(f"[MONDRIAN] Recalibrating with {len(new_y)} new samples...")
        self.calibrate(new_probs, new_logits, new_y)


# ═══════════════════════════════════════════════════════════════════════════════
# SCORE ENTROPY (for distinguishing adversarial vs. novel attacks)
# ═══════════════════════════════════════════════════════════════════════════════

def compute_score_entropy(pvalues):
    """
    Score entropy from p-values. High entropy = uniformly nonconforming (adversarial).
    Low entropy = selectively nonconforming (novel attack).
    
    Args:
        pvalues: (n, num_classes) array
    Returns:
        entropy: (n,) array
    """
    # Normalize p-values to form a distribution
    psum = pvalues.sum(axis=1, keepdims=True)
    psum[psum == 0] = 1e-10  # avoid division by zero
    p_norm = pvalues / psum
    
    # Compute entropy
    p_norm = np.clip(p_norm, 1e-10, 1.0)
    entropy = -np.sum(p_norm * np.log(p_norm), axis=1)
    
    return entropy


# ═══════════════════════════════════════════════════════════════════════════════
# DRIFT MONITOR
# ═══════════════════════════════════════════════════════════════════════════════

class DriftMonitor:
    """
    Monitors nonconformity scores over time to detect concept drift.
    Uses a sliding window and compares to calibration baseline.
    """
    
    def __init__(self, cal_scores, window_size=None, threshold_pct=None):
        self.window_size = window_size or config.DRIFT_WINDOW_SIZE
        self.threshold_pct = threshold_pct or config.DRIFT_THRESHOLD_PERCENTILE
        
        self.baseline_mean = np.mean(cal_scores)
        self.baseline_std = np.std(cal_scores)
        self.threshold = np.percentile(cal_scores, self.threshold_pct)
        
        self.score_buffer = []
        self.drift_alerts = []
    
    def update(self, score, timestamp=None):
        """Add a new score and check for drift."""
        self.score_buffer.append(score)
        
        if len(self.score_buffer) >= self.window_size:
            window = self.score_buffer[-self.window_size:]
            window_mean = np.mean(window)
            
            is_drift = window_mean > self.threshold
            if is_drift:
                self.drift_alerts.append({
                    "timestamp": timestamp or len(self.score_buffer),
                    "window_mean": window_mean,
                    "threshold": self.threshold,
                })
            
            return is_drift, window_mean
        
        return False, None
    
    def batch_check(self, scores):
        """
        Check a batch of scores for drift.
        Returns: drift_detected (bool), mean_score, fraction_exceeding_threshold
        """
        mean_score = np.mean(scores)
        frac_exceeding = np.mean(scores > self.threshold)
        drift_detected = mean_score > self.threshold
        
        return drift_detected, mean_score, frac_exceeding
