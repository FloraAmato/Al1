"""
CREST-NIDS: Training Pipeline and Evaluation
==============================================

Full training loop with:
  - Multi-component loss optimization (Eq. 7)
  - Cosine annealing learning rate schedule
  - Early stopping with best-model checkpointing
  - Comprehensive evaluation metrics
  - Adversarial robustness testing (FGSM/PGD)
  - Open-set recognition evaluation
  - Ablation study support
"""

import os
import time
import json
import numpy as np
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

try:
    from tqdm import tqdm
except ImportError:
    # Fallback: simple progress indicator if tqdm not installed
    class tqdm:
        def __init__(self, iterable=None, **kwargs):
            self.iterable = iterable
            self.total = kwargs.get("total", None)
            self.desc = kwargs.get("desc", "")
            self.n = 0
        def __iter__(self):
            for obj in self.iterable:
                yield obj
                self.n += 1
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def set_postfix_str(self, s): pass

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import CosineAnnealingLR

from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    roc_auc_score, classification_report, confusion_matrix
)

from config import CRESTConfig
from model import CREST_NIDS
from rules import KnowledgeBase


# ═══════════════════════════════════════════════════════════
# TRAINING ENGINE
# ═══════════════════════════════════════════════════════════

class Trainer:
    """
    Training engine for CREST-NIDS.

    Handles:
      - Training with multi-component loss (Eq. 7)
      - Validation with early stopping
      - Learning rate scheduling (cosine annealing)
      - Checkpoint management
      - Training history logging
    """

    def __init__(
        self,
        model: CREST_NIDS,
        cfg: CRESTConfig,
        device: torch.device,
        save_dir: str = "./checkpoints"
    ):
        self.model = model.to(device)
        self.cfg = cfg
        self.device = device
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

        # Optimizer
        self.optimizer = torch.optim.Adam(
            model.parameters(),
            lr=cfg.training.learning_rate,
            weight_decay=cfg.training.weight_decay
        )

        # Cosine annealing scheduler
        self.scheduler = CosineAnnealingLR(
            self.optimizer,
            T_max=cfg.training.epochs,
            eta_min=cfg.training.min_learning_rate
        )

        # Training state
        self.best_val_loss = float('inf')
        self.best_val_f1 = 0.0
        self.patience_counter = 0
        self.history = defaultdict(list)

    def train_epoch(self, train_loader: DataLoader, epoch: int = 0, total_epochs: int = 0) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        epoch_losses = defaultdict(list)
        all_preds = []
        all_labels = []

        pbar = tqdm(
            train_loader,
            desc=f"Epoch {epoch+1}/{total_epochs} [Train]",
            leave=False,
            bar_format="{l_bar}{bar:30}{r_bar}"
        )

        for batch_idx, (features, labels) in enumerate(pbar):
            features = features.to(self.device)
            labels = labels.to(self.device)

            # Forward pass
            self.optimizer.zero_grad()
            results = self.model(features, labels)

            # Compute multi-component loss (Eq. 7)
            total_loss, loss_components = self.model.compute_loss(
                results, labels, self.cfg.training
            )

            # Backward pass
            total_loss.backward()

            # Gradient clipping for stability
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            self.optimizer.step()

            # Record losses
            for k, v in loss_components.items():
                epoch_losses[k].append(v)

            # Record predictions
            preds = results["logits"].argmax(dim=-1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())

            # Update progress bar
            pbar.set_postfix_str(
                f"loss={loss_components['L_total']:.4f} "
                f"CE={loss_components['L_CE']:.4f} "
                f"Cst={loss_components['L_constraint']:.4f}"
            )

        # Compute epoch metrics
        metrics = {k: np.mean(v) for k, v in epoch_losses.items()}
        metrics["train_accuracy"] = accuracy_score(all_labels, all_preds)
        metrics["train_f1_macro"] = f1_score(
            all_labels, all_preds, average='macro', zero_division=0
        )
        metrics["lr"] = self.optimizer.param_groups[0]['lr']

        return metrics

    @torch.no_grad()
    def validate(self, val_loader: DataLoader) -> Dict[str, float]:
        """Evaluate on validation set."""
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []
        total_loss = 0.0
        n_batches = 0

        for features, labels in tqdm(val_loader, desc="Validating", leave=False, bar_format="{l_bar}{bar:30}{r_bar}"):
            features = features.to(self.device)
            labels = labels.to(self.device)

            results = self.model(features, labels)
            loss, _ = self.model.compute_loss(results, labels, self.cfg.training)

            total_loss += loss.item()
            n_batches += 1

            all_preds.extend(results["logits"].argmax(dim=-1).cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(results["probs"].cpu().numpy())

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)
        all_probs = np.array(all_probs)

        metrics = {
            "val_loss": total_loss / max(n_batches, 1),
            "val_accuracy": accuracy_score(all_labels, all_preds),
            "val_f1_macro": f1_score(
                all_labels, all_preds, average='macro', zero_division=0
            ),
            "val_f1_weighted": f1_score(
                all_labels, all_preds, average='weighted', zero_division=0
            ),
            "val_precision_macro": precision_score(
                all_labels, all_preds, average='macro', zero_division=0
            ),
            "val_recall_macro": recall_score(
                all_labels, all_preds, average='macro', zero_division=0
            ),
        }

        # AUC-ROC (multiclass)
        try:
            metrics["val_auc_roc"] = roc_auc_score(
                all_labels, all_probs, multi_class='ovr', average='macro'
            )
        except ValueError:
            metrics["val_auc_roc"] = 0.0

        return metrics

    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        verbose: bool = True
    ) -> Dict[str, List[float]]:
        """
        Full training loop with early stopping.

        Returns training history.
        """
        tcfg = self.cfg.training

        if verbose:
            print(f"\n{'='*70}")
            print(f"CREST-NIDS Training")
            print(f"{'='*70}")
            params = self.model.count_parameters()
            for name, count in params.items():
                print(f"  {name}: {count:,} parameters")
            print(f"{'='*70}\n")

        for epoch in range(tcfg.epochs):
            t0 = time.time()

            # Train
            self.model._current_epoch = epoch  # For constraint warmup
            train_metrics = self.train_epoch(train_loader, epoch, tcfg.epochs)

            # Validate
            val_metrics = self.validate(val_loader)

            # Update scheduler
            self.scheduler.step()

            # Record history
            for k, v in {**train_metrics, **val_metrics}.items():
                self.history[k].append(v)

            elapsed = time.time() - t0

            # Logging
            if verbose:
                print(
                    f"Epoch {epoch+1:3d}/{tcfg.epochs} "
                    f"| L_total={train_metrics['L_total']:.4f} "
                    f"| L_CE={train_metrics['L_CE']:.4f} "
                    f"| L_const={train_metrics['L_constraint']:.4f} "
                    f"| TrainAcc={train_metrics['train_accuracy']:.4f} "
                    f"| ValAcc={val_metrics['val_accuracy']:.4f} "
                    f"| ValF1={val_metrics['val_f1_macro']:.4f} "
                    f"| lr={train_metrics['lr']:.2e} "
                    f"| {elapsed:.1f}s"
                )

            # Early stopping check
            improved = False
            if val_metrics["val_f1_macro"] > self.best_val_f1:
                self.best_val_f1 = val_metrics["val_f1_macro"]
                self.best_val_loss = val_metrics["val_loss"]
                improved = True
                self.patience_counter = 0

                # Save best model
                self._save_checkpoint(epoch, val_metrics)
                if verbose:
                    print(f"  → New best model saved (F1={self.best_val_f1:.4f})")
            else:
                self.patience_counter += 1

            if self.patience_counter >= tcfg.patience:
                if verbose:
                    print(f"\nEarly stopping at epoch {epoch+1} "
                          f"(patience={tcfg.patience})")
                break

        # Load best model
        self._load_best_checkpoint()

        return dict(self.history)

    def _save_checkpoint(self, epoch: int, metrics: Dict):
        path = os.path.join(self.save_dir, "best_model.pt")
        torch.save({
            "epoch": epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "metrics": metrics,
        }, path)

    def _load_best_checkpoint(self):
        path = os.path.join(self.save_dir, "best_model.pt")
        if os.path.exists(path):
            checkpoint = torch.load(path, map_location=self.device, weights_only=False)
            self.model.load_state_dict(checkpoint["model_state_dict"])


# ═══════════════════════════════════════════════════════════
# EVALUATION ENGINE
# ═══════════════════════════════════════════════════════════

class Evaluator:
    """
    Comprehensive evaluation for CREST-NIDS.

    Covers all four evaluation dimensions:
      1. Detection performance (accuracy, F1, precision, recall, AUC)
      2. Interpretability (rule satisfaction, concept analysis)
      3. Adversarial robustness (FGSM, PGD)
      4. Open-set recognition (unknown attack detection)
    """

    def __init__(self, model: CREST_NIDS, device: torch.device):
        self.model = model
        self.device = device

    # ──────────────────────────────────────────────
    # 1. Detection Performance
    # ──────────────────────────────────────────────

    @torch.no_grad()
    def evaluate_detection(
        self, test_loader: DataLoader, class_names: Optional[List[str]] = None
    ) -> Dict:
        """Full detection performance evaluation."""
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []

        for features, labels in test_loader:
            features = features.to(self.device)
            results = self.model(features)
            all_preds.extend(results["logits"].argmax(dim=-1).cpu().numpy())
            all_labels.extend(labels.numpy())
            all_probs.extend(results["probs"].cpu().numpy())

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)
        all_probs = np.array(all_probs)

        metrics = {
            "accuracy": accuracy_score(all_labels, all_preds),
            "f1_macro": f1_score(all_labels, all_preds, average='macro', zero_division=0),
            "f1_weighted": f1_score(all_labels, all_preds, average='weighted', zero_division=0),
            "precision_macro": precision_score(all_labels, all_preds, average='macro', zero_division=0),
            "recall_macro": recall_score(all_labels, all_preds, average='macro', zero_division=0),
        }

        # AUC-ROC (with fallback for sparse classes)
        try:
            # Filter to classes present in both labels and probs
            present_classes = np.unique(all_labels)
            if len(present_classes) > 2:
                # Use 'ovr' but only for present classes
                filtered_probs = all_probs[:, present_classes] if all_probs.shape[1] > len(present_classes) else all_probs
                # Re-normalize filtered probs
                filtered_probs = filtered_probs / (filtered_probs.sum(axis=1, keepdims=True) + 1e-8)
                # Remap labels to 0..N-1
                label_map = {c: i for i, c in enumerate(present_classes)}
                remapped = np.array([label_map[l] for l in all_labels])
                metrics["auc_roc"] = roc_auc_score(
                    remapped, filtered_probs, multi_class='ovr', average='macro'
                )
            elif len(present_classes) == 2:
                metrics["auc_roc"] = roc_auc_score(all_labels, all_probs[:, 1])
            else:
                metrics["auc_roc"] = 0.0
        except (ValueError, IndexError) as e:
            print(f"  [WARNING] AUC-ROC failed: {e}")
            metrics["auc_roc"] = 0.0

        # False Omission Rate
        cm = confusion_matrix(all_labels, all_preds)
        fn = cm.sum(axis=1) - np.diag(cm)
        tn = cm.sum() - (cm.sum(axis=0) + cm.sum(axis=1) - np.diag(cm))
        for_rate = fn / (fn + tn + 1e-8)
        metrics["false_omission_rate"] = for_rate.mean()

        # Per-class report
        if class_names:
            report = classification_report(
                all_labels, all_preds,
                target_names=class_names[:len(set(all_labels))],
                output_dict=True, zero_division=0
            )
            metrics["per_class_report"] = report

        metrics["confusion_matrix"] = cm

        return metrics

    # ──────────────────────────────────────────────
    # 2. Interpretability Assessment
    # ──────────────────────────────────────────────

    @torch.no_grad()
    def evaluate_interpretability(
        self, test_loader: DataLoader
    ) -> Dict:
        """
        Evaluate interpretability:
          (a) Knowledge-base satisfiability
          (b) Concept utilization analysis
          (c) Rule extraction rate
        """
        self.model.eval()
        all_rule_energies = defaultdict(list)
        all_concept_dists = []
        all_uncertainties = []

        for features, labels in test_loader:
            features = features.to(self.device)
            labels = labels.to(self.device)
            results = self.model(features, labels)

            if "rule_energies" in results:
                for name, energy in results["rule_energies"].items():
                    all_rule_energies[name].append(energy)

            all_concept_dists.append(results["concept_dist"].cpu().numpy())
            all_uncertainties.extend(results["uncertainty"].cpu().numpy())

        # (a) Knowledge-base satisfiability
        kb_satisfaction = {}
        for name, energies in all_rule_energies.items():
            mean_energy = np.mean(energies)
            satisfied = mean_energy < 0.1  # Threshold
            kb_satisfaction[name] = {
                "mean_energy": mean_energy,
                "satisfied": satisfied,
            }

        total_rules = len(all_rule_energies)
        satisfied_rules = sum(
            1 for v in kb_satisfaction.values() if v["satisfied"]
        )
        satisfaction_rate = satisfied_rules / max(total_rules, 1)

        # (b) Concept utilization
        concept_dists = np.vstack(all_concept_dists)
        concept_usage = concept_dists.mean(axis=0)
        active_concepts = (concept_usage > 0.01).sum()  # Concepts used >1%

        # Concept entropy (higher = more distributed = more interpretable)
        concept_entropy = -(
            concept_usage * np.log(concept_usage + 1e-8)
        ).sum()

        return {
            "kb_satisfaction_rate": satisfaction_rate,
            "rule_satisfaction": kb_satisfaction,
            "active_concepts": int(active_concepts),
            "concept_entropy": float(concept_entropy),
            "mean_uncertainty": float(np.mean(all_uncertainties)),
        }

    # ──────────────────────────────────────────────
    # 3. Adversarial Robustness
    # ──────────────────────────────────────────────

    def fgsm_attack(
        self, features: torch.Tensor, labels: torch.Tensor,
        epsilon: float = 0.05
    ) -> torch.Tensor:
        """
        Fast Gradient Sign Method (FGSM) adapted for tabular data.

        Generates adversarial examples:
            x_adv = x + ε · sign(∇_x L(x, y))
        """
        features_adv = features.clone().detach().requires_grad_(True)

        results = self.model(features_adv, labels)
        loss = F.cross_entropy(results["logits"], labels)
        loss.backward()

        # FGSM perturbation
        perturbation = epsilon * features_adv.grad.sign()
        features_adv = features + perturbation
        features_adv = features_adv.detach()

        return features_adv

    def pgd_attack(
        self, features: torch.Tensor, labels: torch.Tensor,
        epsilon: float = 0.05, alpha: float = 0.01, num_steps: int = 10
    ) -> torch.Tensor:
        """
        Projected Gradient Descent (PGD) attack for tabular data.

        Iterative FGSM with projection back to ε-ball:
            x_{t+1} = Π_{ε}(x_t + α · sign(∇_x L(x_t, y)))
        """
        features_adv = features.clone().detach()
        features_orig = features.clone().detach()

        for _ in range(num_steps):
            features_adv.requires_grad_(True)

            results = self.model(features_adv, labels)
            loss = F.cross_entropy(results["logits"], labels)
            loss.backward()

            # Gradient step
            perturbation = alpha * features_adv.grad.sign()
            features_adv = features_adv.detach() + perturbation

            # Project back to ε-ball
            delta = features_adv - features_orig
            delta = torch.clamp(delta, -epsilon, epsilon)
            features_adv = features_orig + delta

        return features_adv.detach()

    def evaluate_adversarial(
        self, test_loader: DataLoader,
        epsilons: List[float] = [0.01, 0.05, 0.1]
    ) -> Dict:
        """
        Evaluate adversarial robustness under FGSM and PGD attacks.

        Reports accuracy drop at each epsilon level.
        """
        self.model.eval()
        results = {}

        # Clean accuracy first
        clean_preds = []
        clean_labels = []
        for features, labels in test_loader:
            features = features.to(self.device)
            with torch.no_grad():
                out = self.model(features)
            clean_preds.extend(out["logits"].argmax(dim=-1).cpu().numpy())
            clean_labels.extend(labels.numpy())

        clean_acc = accuracy_score(clean_labels, clean_preds)
        results["clean_accuracy"] = clean_acc

        for eps in epsilons:
            for attack_name, attack_fn in [
                ("FGSM", self.fgsm_attack), ("PGD", self.pgd_attack)
            ]:
                adv_preds = []
                adv_labels = []

                for features, labels in test_loader:
                    features = features.to(self.device)
                    labels = labels.to(self.device)

                    # Generate adversarial examples
                    self.model.train()  # Enable gradients
                    features_adv = attack_fn(features, labels, epsilon=eps)

                    # Evaluate on adversarial examples
                    self.model.eval()
                    with torch.no_grad():
                        out = self.model(features_adv)
                    adv_preds.extend(out["logits"].argmax(dim=-1).cpu().numpy())
                    adv_labels.extend(labels.cpu().numpy())

                adv_acc = accuracy_score(adv_labels, adv_preds)
                acc_drop = clean_acc - adv_acc
                results[f"{attack_name}_eps{eps}_accuracy"] = adv_acc
                results[f"{attack_name}_eps{eps}_drop"] = acc_drop

        return results

    # ──────────────────────────────────────────────
    # 4. Open-Set Recognition
    # ──────────────────────────────────────────────

    @torch.no_grad()
    def evaluate_osr(
        self, osr_loader: DataLoader, num_known_classes: int
    ) -> Dict:
        """
        Evaluate open-set recognition.

        Samples with label == num_known_classes are "unknown" attacks
        (the held-out class). Evaluate how well the uncertainty signal
        separates known from unknown.
        """
        self.model.eval()
        all_uncertainties = []
        all_is_unknown = []
        all_osr_flags = []

        for features, labels in osr_loader:
            features = features.to(self.device)
            results = self.model(features)

            uncertainties = results["uncertainty"].cpu().numpy()
            osr_flags = results["osr_flag"].cpu().numpy()
            is_unknown = (labels.numpy() == num_known_classes)

            all_uncertainties.extend(uncertainties)
            all_is_unknown.extend(is_unknown)
            all_osr_flags.extend(osr_flags)

        all_uncertainties = np.array(all_uncertainties)
        all_is_unknown = np.array(all_is_unknown)
        all_osr_flags = np.array(all_osr_flags)

        # Known vs unknown uncertainty distributions
        known_unc = all_uncertainties[~all_is_unknown]
        unknown_unc = all_uncertainties[all_is_unknown]

        # OSR detection metrics (treating unknown detection as binary)
        if len(unknown_unc) > 0:
            try:
                osr_auc = roc_auc_score(
                    all_is_unknown.astype(int),
                    all_uncertainties
                )
            except ValueError:
                osr_auc = 0.0

            # Detection rate at fixed threshold
            tp = all_osr_flags[all_is_unknown].sum()
            fn = (~all_osr_flags[all_is_unknown]).sum()
            fp = all_osr_flags[~all_is_unknown].sum()
            tn = (~all_osr_flags[~all_is_unknown]).sum()

            osr_precision = tp / (tp + fp + 1e-8)
            osr_recall = tp / (tp + fn + 1e-8)
            osr_f1 = 2 * osr_precision * osr_recall / (
                osr_precision + osr_recall + 1e-8
            )
        else:
            osr_auc = 0.0
            osr_precision = osr_recall = osr_f1 = 0.0

        return {
            "osr_auc_roc": osr_auc,
            "osr_precision": osr_precision,
            "osr_recall": osr_recall,
            "osr_f1": osr_f1,
            "known_uncertainty_mean": float(known_unc.mean()) if len(known_unc) > 0 else 0,
            "unknown_uncertainty_mean": float(unknown_unc.mean()) if len(unknown_unc) > 0 else 0,
            "uncertainty_gap": float(
                unknown_unc.mean() - known_unc.mean()
            ) if len(unknown_unc) > 0 and len(known_unc) > 0 else 0,
        }

    # ──────────────────────────────────────────────
    # Full Evaluation Report
    # ──────────────────────────────────────────────

    def full_evaluation(
        self,
        test_loader: DataLoader,
        osr_loader: Optional[DataLoader] = None,
        class_names: Optional[List[str]] = None,
        num_known_classes: int = 15,
        adversarial: bool = True,
        verbose: bool = True
    ) -> Dict:
        """Run all evaluation dimensions and produce a complete report."""

        report = {}

        # 1. Detection performance
        if verbose:
            print("\n" + "="*60)
            print("1. DETECTION PERFORMANCE")
            print("="*60)
        det = self.evaluate_detection(test_loader, class_names)
        report["detection"] = {k: v for k, v in det.items()
                               if k != "confusion_matrix" and k != "per_class_report"}
        if verbose:
            print(f"  Accuracy:       {det['accuracy']:.4f}")
            print(f"  F1 (macro):     {det['f1_macro']:.4f}")
            print(f"  F1 (weighted):  {det['f1_weighted']:.4f}")
            print(f"  Precision:      {det['precision_macro']:.4f}")
            print(f"  Recall:         {det['recall_macro']:.4f}")
            print(f"  AUC-ROC:        {det['auc_roc']:.4f}")
            print(f"  FOR:            {det['false_omission_rate']:.4f}")

        # 2. Interpretability
        if verbose:
            print("\n" + "="*60)
            print("2. INTERPRETABILITY")
            print("="*60)
        interp = self.evaluate_interpretability(test_loader)
        report["interpretability"] = interp
        if verbose:
            print(f"  KB Satisfaction: {interp['kb_satisfaction_rate']:.2%}")
            print(f"  Active Concepts: {interp['active_concepts']}")
            print(f"  Concept Entropy: {interp['concept_entropy']:.3f}")
            for rule, info in interp["rule_satisfaction"].items():
                status = "✓" if info["satisfied"] else "✗"
                print(f"    {status} {rule}: energy={info['mean_energy']:.4f}")

        # 3. Adversarial robustness
        if adversarial:
            if verbose:
                print("\n" + "="*60)
                print("3. ADVERSARIAL ROBUSTNESS")
                print("="*60)
            adv = self.evaluate_adversarial(test_loader)
            report["adversarial"] = adv
            if verbose:
                print(f"  Clean Accuracy:  {adv['clean_accuracy']:.4f}")
                for eps in [0.01, 0.05, 0.1]:
                    fgsm_acc = adv.get(f"FGSM_eps{eps}_accuracy", 0)
                    pgd_acc = adv.get(f"PGD_eps{eps}_accuracy", 0)
                    fgsm_drop = adv.get(f"FGSM_eps{eps}_drop", 0)
                    pgd_drop = adv.get(f"PGD_eps{eps}_drop", 0)
                    print(f"  ε={eps}: FGSM={fgsm_acc:.4f} "
                          f"(↓{fgsm_drop:.4f})  "
                          f"PGD={pgd_acc:.4f} (↓{pgd_drop:.4f})")

        # 4. Open-set recognition
        if osr_loader is not None:
            if verbose:
                print("\n" + "="*60)
                print("4. OPEN-SET RECOGNITION")
                print("="*60)
            osr = self.evaluate_osr(osr_loader, num_known_classes)
            report["osr"] = osr
            if verbose:
                print(f"  AUC-ROC:          {osr['osr_auc_roc']:.4f}")
                print(f"  Precision:        {osr['osr_precision']:.4f}")
                print(f"  Recall:           {osr['osr_recall']:.4f}")
                print(f"  F1:               {osr['osr_f1']:.4f}")
                print(f"  Known Unc. Mean:  {osr['known_uncertainty_mean']:.4f}")
                print(f"  Unknown Unc. Mean:{osr['unknown_uncertainty_mean']:.4f}")
                print(f"  Uncertainty Gap:  {osr['uncertainty_gap']:.4f}")

        return report


# ═══════════════════════════════════════════════════════════
# ABLATION STUDY SUPPORT
# ═══════════════════════════════════════════════════════════

class AblationStudy:
    """
    Ablation study comparing CREST-NIDS component contributions.

    Configurations:
      (a) Encoder only (no symbolic components)
      (b) Encoder + Constraint Field (no transformer)
      (c) Encoder + Binding Transformer (no constraint field)
      (d) Full CREST-NIDS
    """

    @staticmethod
    def create_ablation_config(
        base_cfg: CRESTConfig, ablation: str
    ) -> CRESTConfig:
        """
        Create configuration for a specific ablation variant.

        Args:
            base_cfg: Full CREST-NIDS config
            ablation: One of 'encoder_only', 'no_transformer',
                      'no_constraint', 'full'
        """
        import copy
        cfg = copy.deepcopy(base_cfg)

        if ablation == "encoder_only":
            cfg.training.lambda_constraint = 0.0
            cfg.training.mu_binding = 0.0
            cfg.training.nu_cycle = 0.0
        elif ablation == "no_transformer":
            cfg.training.mu_binding = 0.0
            cfg.training.nu_cycle = 0.0
            cfg.transformer.num_layers = 0
        elif ablation == "no_constraint":
            cfg.training.lambda_constraint = 0.0
        elif ablation == "full":
            pass  # Use base config as-is
        else:
            raise ValueError(f"Unknown ablation: {ablation}")

        return cfg

    @staticmethod
    def run_ablation_suite(
        base_cfg: CRESTConfig,
        knowledge_base: KnowledgeBase,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: DataLoader,
        device: torch.device,
        class_names: Optional[List[str]] = None,
    ) -> Dict[str, Dict]:
        """Run all ablation configurations and compare results."""
        ablations = [
            ("encoder_only", "Encoder Only"),
            ("no_transformer", "Encoder + Constraint Field"),
            ("no_constraint", "Encoder + Transformer"),
            ("full", "Full CREST-NIDS"),
        ]

        results = {}

        for abl_key, abl_name in ablations:
            print(f"\n{'#'*60}")
            print(f"Ablation: {abl_name}")
            print(f"{'#'*60}")

            cfg = AblationStudy.create_ablation_config(base_cfg, abl_key)
            model = CREST_NIDS(cfg, knowledge_base)

            trainer = Trainer(
                model, cfg, device,
                save_dir=f"./checkpoints/ablation_{abl_key}"
            )
            trainer.train(train_loader, val_loader)

            evaluator = Evaluator(model, device)
            report = evaluator.full_evaluation(
                test_loader, class_names=class_names,
                adversarial=True, verbose=True
            )
            results[abl_name] = report

        return results
