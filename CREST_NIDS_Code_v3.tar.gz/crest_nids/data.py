"""
CREST-NIDS: Data Preprocessing Pipeline
=========================================

Handles loading and preprocessing for:
  - CIC-IDS-2017
  - NF-BoT-IoT-V2
  - ACI-IoT-2023

Preprocessing follows established protocols from [Tran et al., 2025]
and [Nature Scientific Reports, 2025]:
  1. Feature standardization (z-score normalization)
  2. Categorical encoding (label encoding + one-hot)
  3. Class balancing (stratified sampling)
  4. Open-set split (holdout class for OSR evaluation)
"""

import os
import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict, List
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split

import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler

from config import CRESTConfig, DATASET_CONFIGS


class NIDSDataset(Dataset):
    """PyTorch dataset for network intrusion detection."""

    def __init__(self, features: np.ndarray, labels: np.ndarray):
        self.features = torch.FloatTensor(features)
        self.labels = torch.LongTensor(labels)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]


class DataPreprocessor:
    """
    Unified data preprocessor for all three NIDS benchmarks.

    Produces:
      - train_loader, val_loader, test_loader (standard evaluation)
      - osr_test_loader (open-set recognition: includes held-out class)
      - scaler, label_encoder (for inference on new data)
    """

    def __init__(self, cfg: CRESTConfig):
        self.cfg = cfg
        self.dataset_cfg = DATASET_CONFIGS[cfg.dataset]
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.class_names = self.dataset_cfg["class_names"]
        self.osr_holdout = self.dataset_cfg.get("osr_holdout_class", None)

    # ──────────────────────────────────────────────
    # Dataset-specific loaders
    # ──────────────────────────────────────────────

    def load_cicids2017(self, data_path: str) -> Tuple[pd.DataFrame, str]:
        """
        Load CIC-IDS-2017 dataset.
        Expected format: CSV files with ' Label' column.
        Download from: https://www.unb.ca/cic/datasets/ids-2017.html
        """
        csv_files = [f for f in os.listdir(data_path)
                     if f.endswith('.csv')]
        if not csv_files:
            raise FileNotFoundError(
                f"No CSV files found in {data_path}. "
                "Download CIC-IDS-2017 from: "
                "https://www.unb.ca/cic/datasets/ids-2017.html"
            )

        print(f"  Loading {len(csv_files)} CIC-IDS-2017 file(s)...")
        dfs = []
        for f in sorted(csv_files):
            print(f"    Reading {f}...")
            df = pd.read_csv(os.path.join(data_path, f), low_memory=False)
            dfs.append(df)

        data = pd.concat(dfs, ignore_index=True)
        print(f"    Total rows: {len(data):,}")

        # Standardize column name
        label_col = None
        for col in data.columns:
            if 'label' in col.lower().strip():
                label_col = col
                break

        if label_col is None:
            raise ValueError("Could not find label column in CIC-IDS-2017 data")

        return data, label_col

    def load_botiot(self, data_path: str) -> Tuple[pd.DataFrame, str]:
        """
        Load NF-BoT-IoT-V2 dataset.
        Supports multiple CSV parts (Full5pc_1.csv through Full5pc_4.csv).
        """
        csv_files = sorted([f for f in os.listdir(data_path) if f.endswith('.csv')])
        if not csv_files:
            raise FileNotFoundError(
                f"No CSV files found in {data_path}. "
                "Download NF-BoT-IoT-V2 from the original source."
            )

        print(f"  Loading {len(csv_files)} BoT-IoT file(s)...")
        dfs = []
        for f in csv_files:
            print(f"    Reading {f}...")
            df = pd.read_csv(os.path.join(data_path, f), low_memory=False)
            dfs.append(df)
        data = pd.concat(dfs, ignore_index=True)
        print(f"    Total rows: {len(data):,}")

        # Auto-detect label column
        label_col = None
        for candidate in ["Attack", "attack", "Label", "label", "category", "attack_cat"]:
            if candidate in data.columns:
                label_col = candidate
                break
        if label_col is None:
            raise ValueError(
                f"Could not find label column. Available columns: {list(data.columns)}"
            )

        return data, label_col

    def load_aciiot(self, data_path: str) -> Tuple[pd.DataFrame, str]:
        """
        Load ACI-IoT-2023 dataset.
        Expected format: CSV with 'label' column.
        """
        csv_files = sorted([f for f in os.listdir(data_path) if f.endswith('.csv')])
        if not csv_files:
            raise FileNotFoundError(
                f"No CSV files found in {data_path}. "
                "Download ACI-IoT-2023 dataset."
            )

        print(f"  Loading {len(csv_files)} ACI-IoT file(s)...")
        dfs = []
        for f in csv_files:
            print(f"    Reading {f}...")
            df = pd.read_csv(os.path.join(data_path, f), low_memory=False)
            dfs.append(df)
        data = pd.concat(dfs, ignore_index=True)
        print(f"    Total rows: {len(data):,}")

        # Auto-detect label column
        label_col = None
        for candidate in ["label", "Label", "attack", "Attack", "class", "category"]:
            if candidate in data.columns:
                label_col = candidate
                break
        if label_col is None:
            raise ValueError(
                f"Could not find label column. Available columns: {list(data.columns)}"
            )

        return data, label_col

    # ──────────────────────────────────────────────
    # Core preprocessing
    # ──────────────────────────────────────────────

    def clean_features(self, df: pd.DataFrame, label_col: str) -> Tuple[np.ndarray, np.ndarray]:
        """
        Clean and prepare features following standard NIDS preprocessing:
        1. Drop non-numeric identifiers (IP, timestamp, etc.)
        2. Handle inf/nan values
        3. Encode categorical features
        4. Standardize numerical features
        """
        labels = df[label_col].values

        # Drop label and non-feature columns
        drop_cols = [label_col]
        for col in df.columns:
            col_lower = col.strip().lower()
            if any(kw in col_lower for kw in
                   ['ip', 'timestamp', 'flow id', 'source', 'destination']):
                drop_cols.append(col)

        features_df = df.drop(columns=drop_cols, errors='ignore')

        # Encode categorical columns
        for col in features_df.select_dtypes(include=['object', 'category']).columns:
            le = LabelEncoder()
            features_df[col] = le.fit_transform(features_df[col].astype(str))

        # Convert to float and handle inf/nan
        features = features_df.values.astype(np.float32)
        features = np.nan_to_num(features, nan=0.0, posinf=1e10, neginf=-1e10)

        # Clip extreme outliers
        percentile_99 = np.percentile(np.abs(features), 99, axis=0)
        percentile_99[percentile_99 == 0] = 1.0
        features = np.clip(features, -percentile_99 * 10, percentile_99 * 10)

        return features, labels

    def prepare(
        self, data_path: Optional[str] = None,
        max_samples: int = 0
    ) -> Dict[str, DataLoader]:
        """
        Full preprocessing pipeline.

        Args:
            data_path: path to dataset CSVs
            max_samples: if > 0, stratified subsample to this many rows

        Returns dict with:
            train_loader, val_loader, test_loader,
            osr_test_loader, class_names, input_dim, num_classes
        """
        path = data_path or self.cfg.data_path
        tcfg = self.cfg.training

        # Load dataset
        loaders = {
            "CIC-IDS-2017": self.load_cicids2017,
            "NF-BoT-IoT-V2": self.load_botiot,
            "ACI-IoT-2023": self.load_aciiot,
        }
        df, label_col = loaders[self.cfg.dataset](path)

        # Clean and extract features
        features, raw_labels = self.clean_features(df, label_col)

        # ── Subsample if requested (stratified to keep class balance) ──
        if max_samples > 0 and max_samples < len(raw_labels):
            print(f"\n  Subsampling: {len(raw_labels):,} → {max_samples:,} rows (stratified)")
            ratio = max_samples / len(raw_labels)
            _, features, _, raw_labels = train_test_split(
                features, raw_labels,
                test_size=ratio,
                random_state=tcfg.random_seed,
                stratify=raw_labels
            )
            print(f"  After subsample: {len(raw_labels):,} rows")

        # Encode labels
        self.label_encoder.fit(raw_labels)
        labels = self.label_encoder.transform(raw_labels)

        # Update config with actual dimensions
        actual_input_dim = features.shape[1]
        actual_num_classes = len(self.label_encoder.classes_)
        print(f"Dataset: {self.cfg.dataset}")
        print(f"  Samples: {len(labels):,}")
        print(f"  Features: {actual_input_dim}")
        print(f"  Classes: {actual_num_classes}")
        print(f"  Class distribution:")
        for i, name in enumerate(self.label_encoder.classes_):
            count = (labels == i).sum()
            print(f"    {name}: {count:,} ({100*count/len(labels):.1f}%)")

        # ── Open-Set Recognition split ──
        osr_mask = np.ones(len(labels), dtype=bool)
        osr_test_features = None
        osr_test_labels = None

        if self.osr_holdout and self.osr_holdout in self.label_encoder.classes_:
            holdout_idx = list(self.label_encoder.classes_).index(self.osr_holdout)
            osr_mask = labels != holdout_idx
            osr_test_features = features[~osr_mask]
            osr_test_labels = labels[~osr_mask]
            print(f"\n  OSR holdout class: {self.osr_holdout} "
                  f"({(~osr_mask).sum():,} samples)")

            # Remove holdout from training data
            features = features[osr_mask]
            labels = labels[osr_mask]

        # ── Train / Validation / Test split ──
        X_train, X_test, y_train, y_test = train_test_split(
            features, labels,
            test_size=1.0 - tcfg.train_split,
            random_state=tcfg.random_seed,
            stratify=labels
        )

        X_train, X_val, y_train, y_val = train_test_split(
            X_train, y_train,
            test_size=tcfg.val_split,
            random_state=tcfg.random_seed,
            stratify=y_train
        )

        print(f"\n  Train: {len(y_train):,}")
        print(f"  Val:   {len(y_val):,}")
        print(f"  Test:  {len(y_test):,}")

        # ── Standardize features ──
        X_train = self.scaler.fit_transform(X_train)
        X_val = self.scaler.transform(X_val)
        X_test = self.scaler.transform(X_test)

        # ── Aggressive weighted sampler for extreme class imbalance ──
        # Standard 1/count doesn't work well when ratio is 2.3M:11 (Heartbleed)
        # Use sqrt-inverse: weight = 1/sqrt(count), which oversamples minority
        # classes more aggressively than 1/count
        class_counts = np.bincount(y_train, minlength=len(self.label_encoder.classes_))
        class_weights = 1.0 / (np.sqrt(class_counts) + 1e-8)
        # Cap the weight ratio to prevent extreme over-representation
        max_weight = class_weights[class_counts > 0].min() * 100
        class_weights = np.clip(class_weights, 0, max_weight)
        sample_weights = class_weights[y_train]
        sampler = WeightedRandomSampler(
            weights=sample_weights,
            num_samples=len(y_train),
            replacement=True
        )
        print(f"\n  Class weighting (sqrt-inverse):")
        for i, name in enumerate(self.label_encoder.classes_):
            if class_counts[i] > 0:
                print(f"    {name}: count={class_counts[i]:,}, weight={class_weights[i]:.4f}")

        # ── Create DataLoaders ──
        train_dataset = NIDSDataset(X_train, y_train)
        val_dataset = NIDSDataset(X_val, y_val)
        test_dataset = NIDSDataset(X_test, y_test)

        # Only pin memory when GPU is available
        use_pin = torch.cuda.is_available()

        result = {
            "train_loader": DataLoader(
                train_dataset, batch_size=tcfg.batch_size,
                sampler=sampler, num_workers=tcfg.num_workers,
                pin_memory=use_pin, drop_last=True
            ),
            "val_loader": DataLoader(
                val_dataset, batch_size=tcfg.batch_size,
                shuffle=False, num_workers=tcfg.num_workers, pin_memory=use_pin
            ),
            "test_loader": DataLoader(
                test_dataset, batch_size=tcfg.batch_size,
                shuffle=False, num_workers=tcfg.num_workers, pin_memory=use_pin
            ),
            "class_names": list(self.label_encoder.classes_),
            "input_dim": actual_input_dim,
            "num_classes": actual_num_classes,
            "scaler": self.scaler,
            "label_encoder": self.label_encoder,
        }

        # OSR test loader (combines normal test + held-out class)
        if osr_test_features is not None:
            osr_test_features_scaled = self.scaler.transform(osr_test_features)
            osr_all_features = np.vstack([X_test, osr_test_features_scaled])
            # Mark holdout samples with label = num_classes (unknown)
            osr_all_labels = np.concatenate([
                y_test,
                np.full(len(osr_test_labels), actual_num_classes)
            ])
            osr_dataset = NIDSDataset(osr_all_features, osr_all_labels)
            result["osr_test_loader"] = DataLoader(
                osr_dataset, batch_size=tcfg.batch_size,
                shuffle=False, num_workers=tcfg.num_workers, pin_memory=use_pin
            )

        return result


def create_synthetic_dataset(
    n_samples: int = 10000,
    n_features: int = 78,
    n_classes: int = 15,
    random_seed: int = 42
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Create a synthetic NIDS dataset for testing the pipeline
    when real data is not available.

    Generates clusters with controlled overlap to simulate
    attack-class distributions.
    """
    np.random.seed(random_seed)

    features_list = []
    labels_list = []

    # Class proportions (simulating imbalanced NIDS data)
    proportions = np.random.dirichlet(np.ones(n_classes) * 0.5)
    proportions[0] = 0.5  # Benign is majority
    proportions = proportions / proportions.sum()

    for cls_idx in range(n_classes):
        n_cls = max(10, int(n_samples * proportions[cls_idx]))

        # Class-specific centroid
        centroid = np.random.randn(n_features) * 2
        # Add structured patterns per class group
        if cls_idx == 0:  # Benign
            centroid[:10] = np.random.randn(10) * 0.5
        elif 1 <= cls_idx <= 6:  # DoS family
            centroid[10:30] = np.random.randn(20) * 3
        elif 7 <= cls_idx <= 9:  # Web attacks
            centroid[30:50] = np.random.randn(20) * 2.5

        # Generate samples around centroid
        noise = np.random.randn(n_cls, n_features) * 0.8
        samples = centroid + noise

        features_list.append(samples.astype(np.float32))
        labels_list.append(np.full(n_cls, cls_idx, dtype=np.int64))

    features = np.vstack(features_list)
    labels = np.concatenate(labels_list)

    # Shuffle
    perm = np.random.permutation(len(labels))
    return features[perm], labels[perm]
