"""
CREST-NIDS: Symbolic Rule Definitions (Knowledge Base)
=======================================================

Defines the logical rules (axioms) that the Constraint-Field
Regularizer enforces in embedding space.

Rules follow first-order logic patterns:
  - Implication:  P(x) → Q(x)
  - Conjunction:  P(x) ∧ R(x) → Q(x)
  - Hierarchy:    SubClass(x) → SuperClass(x)
  - Exclusion:    P(x) → ¬Q(x)

Each rule is converted to a geometric constraint (Eq. 1-2 in paper).
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class SymbolicRule:
    """
    A single symbolic rule for the constraint field.

    Attributes:
        name: Human-readable rule identifier
        rule_type: One of 'implication', 'exclusion', 'hierarchy', 'conjunction'
        premise_classes: List of class indices forming the premise
        conclusion_classes: List of class indices forming the conclusion
        description: Natural language explanation (for interpretability output)
    """
    name: str
    rule_type: str
    premise_classes: List[int]
    conclusion_classes: List[int]
    description: str


class KnowledgeBase:
    """
    Knowledge base of symbolic rules for NIDS.

    Rules encode domain knowledge about attack-class relationships:
    - Hierarchical: DoS subtypes are all DoS attacks
    - Exclusion: Benign traffic is not any attack type
    - Similarity: Related attack subtypes should cluster together
    - Composition: Multi-stage attack patterns
    """

    def __init__(self, class_names: List[str]):
        self.class_names = class_names
        self.class_to_idx = {name: i for i, name in enumerate(class_names)}
        self.rules: List[SymbolicRule] = []

    def add_rule(self, rule: SymbolicRule):
        """Add a symbolic rule to the knowledge base."""
        self.rules.append(rule)

    def add_implication(self, name: str, premise: List[str],
                        conclusion: List[str], description: str = ""):
        """P(x) → Q(x): If x is premise-class, then x should be near conclusion-class."""
        p_idx = [self.class_to_idx[c] for c in premise if c in self.class_to_idx]
        c_idx = [self.class_to_idx[c] for c in conclusion if c in self.class_to_idx]
        if p_idx and c_idx:
            self.rules.append(SymbolicRule(
                name=name, rule_type="implication",
                premise_classes=p_idx, conclusion_classes=c_idx,
                description=description
            ))

    def add_exclusion(self, name: str, class_a: List[str],
                      class_b: List[str], description: str = ""):
        """P(x) → ¬Q(x): class_a and class_b should be far apart."""
        a_idx = [self.class_to_idx[c] for c in class_a if c in self.class_to_idx]
        b_idx = [self.class_to_idx[c] for c in class_b if c in self.class_to_idx]
        if a_idx and b_idx:
            self.rules.append(SymbolicRule(
                name=name, rule_type="exclusion",
                premise_classes=a_idx, conclusion_classes=b_idx,
                description=description
            ))

    def add_hierarchy(self, name: str, subclasses: List[str],
                      superclass: str, description: str = ""):
        """SubClass(x) → SuperClass(x): subclasses cluster near superclass centroid."""
        sub_idx = [self.class_to_idx[c] for c in subclasses if c in self.class_to_idx]
        sup_idx = [self.class_to_idx[superclass]] if superclass in self.class_to_idx else []
        if sub_idx and sup_idx:
            self.rules.append(SymbolicRule(
                name=name, rule_type="hierarchy",
                premise_classes=sub_idx, conclusion_classes=sup_idx,
                description=description
            ))

    def get_rules(self) -> List[SymbolicRule]:
        return self.rules

    def summary(self) -> str:
        lines = [f"Knowledge Base: {len(self.rules)} rules over {len(self.class_names)} classes\n"]
        for i, r in enumerate(self.rules):
            p_names = [self.class_names[j] for j in r.premise_classes]
            c_names = [self.class_names[j] for j in r.conclusion_classes]
            lines.append(f"  R{i+1} [{r.rule_type}] {r.name}")
            lines.append(f"      Premise:    {p_names}")
            lines.append(f"      Conclusion: {c_names}")
            lines.append(f"      {r.description}\n")
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════
# Pre-built knowledge bases for each dataset
# ═══════════════════════════════════════════════════════

def build_cicids2017_kb() -> KnowledgeBase:
    """
    Knowledge base for CIC-IDS-2017.
    Encodes hierarchical attack taxonomy and exclusion constraints.
    """
    class_names = [
        "BENIGN", "FTP-Patator", "SSH-Patator", "DoS slowloris",
        "DoS Slowhttptest", "DoS Hulk", "DoS GoldenEye", "Heartbleed",
        "Web Attack - Brute Force", "Web Attack - XSS",
        "Web Attack - Sql Injection", "Infiltration", "Bot",
        "PortScan", "DDoS"
    ]
    kb = KnowledgeBase(class_names)

    # ── Hierarchy rules: attack subtypes should cluster ──

    # R1: DoS variants cluster together
    kb.add_implication(
        name="DoS_family_cohesion",
        premise=["DoS slowloris", "DoS Slowhttptest", "DoS Hulk", "DoS GoldenEye"],
        conclusion=["DDoS"],
        description="All DoS subtypes share denial-of-service characteristics "
                    "and should produce similar embeddings."
    )

    # R2: Brute-force patator attacks cluster
    kb.add_implication(
        name="Patator_family_cohesion",
        premise=["FTP-Patator", "SSH-Patator"],
        conclusion=["FTP-Patator", "SSH-Patator"],
        description="FTP and SSH Patator attacks share brute-force methodology."
    )

    # R3: Web attacks cluster
    kb.add_implication(
        name="WebAttack_family_cohesion",
        premise=["Web Attack - Brute Force", "Web Attack - XSS",
                 "Web Attack - Sql Injection"],
        conclusion=["Web Attack - Brute Force", "Web Attack - XSS",
                     "Web Attack - Sql Injection"],
        description="Web attack variants target the same application layer."
    )

    # ── Exclusion rules: benign is far from all attacks ──

    # R4: Benign vs DoS
    kb.add_exclusion(
        name="Benign_vs_DoS",
        class_a=["BENIGN"],
        class_b=["DoS slowloris", "DoS Slowhttptest", "DoS Hulk",
                 "DoS GoldenEye", "DDoS"],
        description="Benign traffic must be well-separated from DoS attacks."
    )

    # R5: Benign vs Brute Force
    kb.add_exclusion(
        name="Benign_vs_BruteForce",
        class_a=["BENIGN"],
        class_b=["FTP-Patator", "SSH-Patator",
                 "Web Attack - Brute Force"],
        description="Benign traffic must be well-separated from brute-force attacks."
    )

    # R6: Benign vs Reconnaissance
    kb.add_exclusion(
        name="Benign_vs_Recon",
        class_a=["BENIGN"],
        class_b=["PortScan", "Infiltration"],
        description="Benign traffic must be well-separated from reconnaissance."
    )

    # ── Cross-family separation ──

    # R7: DoS vs Web attacks (different attack vectors)
    kb.add_exclusion(
        name="DoS_vs_WebAttack",
        class_a=["DoS Hulk", "DoS GoldenEye", "DDoS"],
        class_b=["Web Attack - XSS", "Web Attack - Sql Injection"],
        description="Volume-based DoS and precision web attacks have "
                    "fundamentally different traffic signatures."
    )

    # R8: Bot traffic is distinct from scan-based attacks
    kb.add_exclusion(
        name="Bot_vs_PortScan",
        class_a=["Bot"],
        class_b=["PortScan"],
        description="Botnet C2 traffic differs structurally from port scanning."
    )

    return kb


def build_botiot_kb() -> KnowledgeBase:
    """Knowledge base for NF-BoT-IoT-V2."""
    class_names = ["Benign", "DDoS", "DoS", "Reconnaissance", "Theft"]
    kb = KnowledgeBase(class_names)

    # R1: DDoS and DoS are related denial-of-service attacks
    kb.add_implication(
        name="DoS_DDoS_cohesion",
        premise=["DDoS", "DoS"],
        conclusion=["DDoS", "DoS"],
        description="DDoS and DoS share denial-of-service characteristics."
    )

    # R2: Benign vs all attacks
    kb.add_exclusion(
        name="Benign_vs_attacks",
        class_a=["Benign"],
        class_b=["DDoS", "DoS", "Reconnaissance", "Theft"],
        description="Benign traffic must be separated from all attack types."
    )

    # R3: Reconnaissance vs Theft (different intent)
    kb.add_exclusion(
        name="Recon_vs_Theft",
        class_a=["Reconnaissance"],
        class_b=["Theft"],
        description="Reconnaissance (scanning) differs from data exfiltration."
    )

    return kb


def build_aciiot_kb() -> KnowledgeBase:
    """Knowledge base for ACI-IoT-2023."""
    class_names = [
        "Benign", "DDoS-ICMP_Flood", "DDoS-UDP_Flood",
        "DDoS-TCP_Flood", "DDoS-PSHACK_Flood", "DDoS-SYN_Flood",
        "DDoS-RSTFINFlood", "DDoS-SynonymousIP_Flood",
        "DoS-UDP_Flood", "DoS-TCP_Flood", "DoS-HTTP_Flood",
        "Mirai-greeth_flood", "Mirai-greip_flood", "Mirai-udpplain",
        "Recon-HostDiscovery", "Recon-OSScan", "Recon-PortScan",
        "VulnerabilityScan", "BrowserHijacking"
    ]
    kb = KnowledgeBase(class_names)

    # R1: DDoS variants cluster
    kb.add_implication(
        name="DDoS_family",
        premise=["DDoS-ICMP_Flood", "DDoS-UDP_Flood", "DDoS-TCP_Flood",
                 "DDoS-PSHACK_Flood", "DDoS-SYN_Flood",
                 "DDoS-RSTFINFlood", "DDoS-SynonymousIP_Flood"],
        conclusion=["DDoS-ICMP_Flood", "DDoS-UDP_Flood", "DDoS-TCP_Flood",
                     "DDoS-PSHACK_Flood", "DDoS-SYN_Flood",
                     "DDoS-RSTFINFlood", "DDoS-SynonymousIP_Flood"],
        description="All DDoS flood variants share volumetric attack characteristics."
    )

    # R2: DoS variants cluster
    kb.add_implication(
        name="DoS_family",
        premise=["DoS-UDP_Flood", "DoS-TCP_Flood", "DoS-HTTP_Flood"],
        conclusion=["DoS-UDP_Flood", "DoS-TCP_Flood", "DoS-HTTP_Flood"],
        description="DoS flood variants cluster together."
    )

    # R3: Mirai variants cluster
    kb.add_implication(
        name="Mirai_family",
        premise=["Mirai-greeth_flood", "Mirai-greip_flood", "Mirai-udpplain"],
        conclusion=["Mirai-greeth_flood", "Mirai-greip_flood", "Mirai-udpplain"],
        description="Mirai botnet variants share IoT malware signatures."
    )

    # R4: Reconnaissance variants cluster
    kb.add_implication(
        name="Recon_family",
        premise=["Recon-HostDiscovery", "Recon-OSScan", "Recon-PortScan"],
        conclusion=["Recon-HostDiscovery", "Recon-OSScan", "Recon-PortScan"],
        description="Reconnaissance activities share scanning behavior."
    )

    # R5: DDoS and DoS are related
    kb.add_implication(
        name="DDoS_DoS_bridge",
        premise=["DDoS-UDP_Flood", "DDoS-TCP_Flood"],
        conclusion=["DoS-UDP_Flood", "DoS-TCP_Flood"],
        description="DDoS and DoS over same protocol share transport signatures."
    )

    # R6: Benign vs all attacks
    kb.add_exclusion(
        name="Benign_separation",
        class_a=["Benign"],
        class_b=["DDoS-ICMP_Flood", "DDoS-UDP_Flood", "DDoS-TCP_Flood",
                 "Mirai-greeth_flood", "Recon-PortScan"],
        description="Benign traffic must be well-separated from attack classes."
    )

    # R7: Volumetric vs precision attacks
    kb.add_exclusion(
        name="Volumetric_vs_Precision",
        class_a=["DDoS-ICMP_Flood", "DDoS-UDP_Flood"],
        class_b=["VulnerabilityScan", "BrowserHijacking"],
        description="Volumetric floods differ from precision exploitation attacks."
    )

    return kb


# ── Factory function ──

def build_knowledge_base(dataset_name: str) -> KnowledgeBase:
    """Build the appropriate knowledge base for a given dataset."""
    builders = {
        "CIC-IDS-2017": build_cicids2017_kb,
        "NF-BoT-IoT-V2": build_botiot_kb,
        "ACI-IoT-2023": build_aciiot_kb,
    }
    if dataset_name not in builders:
        raise ValueError(f"Unknown dataset: {dataset_name}. "
                         f"Available: {list(builders.keys())}")
    return builders[dataset_name]()
