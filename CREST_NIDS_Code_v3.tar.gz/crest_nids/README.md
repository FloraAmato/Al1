# CREST-NIDS — Complete Setup Guide (Windows PowerShell)

## STEP 1: Create project folder

```powershell
mkdir C:\Users\Mattia\Desktop\NIDS
cd C:\Users\Mattia\Desktop\NIDS
```

Extract `CREST_NIDS_Code.tar.gz` here so you have:
```
C:\Users\Mattia\Desktop\NIDS\
├── config.py
├── rules.py
├── model.py
├── data.py
├── train.py
├── main.py
└── README.md
```

## STEP 2: Create virtual environment and install

```powershell
cd C:\Users\Mattia\Desktop\NIDS
python -m venv venv
.\venv\Scripts\Activate.ps1
```

If you get a red error about execution policy:
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
.\venv\Scripts\Activate.ps1
```

You should see `(venv)` at the start of your prompt.

Install packages:
```powershell
pip install torch --index-url https://download.pytorch.org/whl/cpu
pip install numpy pandas scikit-learn tqdm
```

## STEP 3: Put datasets in the right folders

You already have these — just make sure the structure is:

```
C:\Users\Mattia\Desktop\NIDS\data\
├── cicids2017\
│   ├── Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv
│   ├── Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv
│   ├── Friday-WorkingHours-Morning.pcap_ISCX.csv
│   ├── Monday-WorkingHours.pcap_ISCX.csv
│   ├── Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv
│   ├── Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv
│   ├── Tuesday-WorkingHours.pcap_ISCX.csv
│   └── Wednesday-workingHours.pcap_ISCX.csv
├── botiot\
│   ├── UNSW_2018_IoT_Botnet_Full5pc_1.csv
│   ├── UNSW_2018_IoT_Botnet_Full5pc_2.csv
│   ├── UNSW_2018_IoT_Botnet_Full5pc_3.csv
│   └── UNSW_2018_IoT_Botnet_Full5pc_4.csv
└── aciiot\
    └── ACI-IoT-2023.csv
```

## STEP 4: Run

### Quick test (synthetic data, no dataset needed, ~2 min)
```powershell
python main.py --synthetic --epochs 5
```

### CIC-IDS-2017

Fast run (~15 min on CPU):
```powershell
python main.py --dataset CIC-IDS-2017 --data_path .\data\cicids2017\ --max_samples 100000 --epochs 20
```

Full run (~several hours on CPU, best overnight):
```powershell
python main.py --dataset CIC-IDS-2017 --data_path .\data\cicids2017\
```

### NF-BoT-IoT-V2

Fast run (~15 min on CPU):
```powershell
python main.py --dataset NF-BoT-IoT-V2 --data_path .\data\botiot\ --max_samples 100000 --epochs 20
```

Full run:
```powershell
python main.py --dataset NF-BoT-IoT-V2 --data_path .\data\botiot\
```

### ACI-IoT-2023

Fast run (~15 min on CPU):
```powershell
python main.py --dataset ACI-IoT-2023 --data_path .\data\aciiot\ --max_samples 100000 --epochs 20
```

Full run:
```powershell
python main.py --dataset ACI-IoT-2023 --data_path .\data\aciiot\
```

### Ablation study (for the paper)
```powershell
python main.py --dataset CIC-IDS-2017 --data_path .\data\cicids2017\ --max_samples 100000 --ablation --epochs 20
```

## What --max_samples does

It takes a stratified random subsample of the dataset BEFORE training.
Class proportions are preserved.

| Flag              | Rows used   | Time per epoch (CPU) |
|-------------------|-------------|----------------------|
| (none)            | All (2.8M)  | ~15-30 min           |
| --max_samples 500000 | 500K     | ~3-5 min             |
| --max_samples 200000 | 200K     | ~1-2 min             |
| --max_samples 100000 | 100K     | ~30-60 sec           |
| --max_samples 50000  | 50K      | ~15-30 sec           |

For the paper: 100K-200K samples gives you meaningful results fast.
Full dataset gives the best results but needs hours or a GPU.

## Outputs

After training, check `.\outputs\`:

```
.\outputs\
├── checkpoints\
│   └── best_model.pt              # Best model weights
├── training_history.json           # Loss curves per epoch
├── evaluation_report.json          # Full 4-dimension evaluation results
└── crest_nids_final.pt             # Final model + config
```

Read results:
```powershell
Get-Content .\outputs\evaluation_report.json | python -m json.tool
```

## All available flags

```
python main.py --help
```

| Flag                 | Default | What it does                        |
|----------------------|---------|-------------------------------------|
| --dataset            | CIC-IDS-2017 | Which dataset                  |
| --data_path          | ./data/ | Path to CSV files                   |
| --synthetic          | off     | Use fake data for testing           |
| --max_samples        | 0       | Subsample to N rows (0 = all)       |
| --epochs             | 50      | Training epochs                     |
| --batch_size         | 512     | Batch size                          |
| --lr                 | 0.001   | Learning rate                       |
| --patience           | 7       | Early stopping patience             |
| --lambda_c           | 0.5     | Constraint-field loss weight        |
| --mu_b               | 0.05    | Binding loss weight                 |
| --nu_cy              | 0.05    | Cycle-consistency loss weight       |
| --embedding_dim      | 128     | Embedding dimension                 |
| --transformer_layers | 2       | Number of transformer layers        |
| --num_heads          | 4       | Attention heads                     |
| --concept_vocab      | 32      | Concept vocabulary size K           |
| --no_adversarial     | off     | Skip FGSM/PGD evaluation (faster)  |
| --ablation           | off     | Run full ablation study             |
| --save_dir           | ./outputs | Where to save results             |
| --seed               | 42      | Random seed                         |

## Troubleshooting

**"execution policy" error on Activate.ps1:**
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

**"pin_memory" warning:**
Already fixed. If you see it, re-download the code.

**"No CSV files found":**
Check that CSV files are directly inside the folder, not in a subfolder.

**Out of memory on BoT-IoT (37M rows):**
```powershell
python main.py --dataset NF-BoT-IoT-V2 --data_path .\data\botiot\ --max_samples 200000
```

**Very slow training:**
Use --max_samples 100000 for fast experiments, full data for final paper results.

**Want to resume after Ctrl+C:**
The best model is auto-saved. Re-run the same command — it starts fresh
(checkpoint loading on resume is not yet implemented).
