#!/usr/bin/env python3
"""
Compute F1 scores across all conditions: unconditional, baselines, conformal, Mondrian.
"""
import json, sys
from pathlib import Path
from collections import Counter
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from conformal_agentic_rag.dataset import load_dataset, split_dataset

CLASSES = ["Supported", "Refuted", "Not Enough Evidence",
           "Conflicting Evidence/Cherrypicking"]
SHORT = {"Supported": "SUP", "Refuted": "REF",
         "Not Enough Evidence": "NEE",
         "Conflicting Evidence/Cherrypicking": "CONF"}

# AVeriTeC verifier labels -> canonical
VERIFIER_TO_CANON = {
    "SUPPORTED": "Supported", "REFUTED": "Refuted",
    "NOT_ENOUGH_EVIDENCE": "Not Enough Evidence",
    "CONFLICTING": "Conflicting Evidence/Cherrypicking",
}

EMIT_KEYS = ["HIGH-CONFIDENCE", "MODERATE-CONFIDENCE",
             "ESCALATE-VERIFIER-CONFLICT", "ROUTE-TO-SKIP-DECOMPOSER",
             "ROUTE-TO-SKIP-READER", "RESIDUAL"]


def compute_f1(gold_labels, pred_labels, classes):
    """Compute per-class precision, recall, F1 and macro/weighted averages."""
    results = {}
    total = len(gold_labels)
    for cls in classes:
        tp = sum(1 for g, p in zip(gold_labels, pred_labels) if g == cls and p == cls)
        fp = sum(1 for g, p in zip(gold_labels, pred_labels) if g != cls and p == cls)
        fn = sum(1 for g, p in zip(gold_labels, pred_labels) if g == cls and p != cls)
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0
        support = sum(1 for g in gold_labels if g == cls)
        results[cls] = {"precision": prec, "recall": rec, "f1": f1,
                        "support": support, "tp": tp, "fp": fp, "fn": fn}

    # Macro F1
    f1_values = [results[c]["f1"] for c in classes if results[c]["support"] > 0]
    macro_f1 = np.mean(f1_values) if f1_values else 0.0

    # Weighted F1
    weighted_f1 = sum(results[c]["f1"] * results[c]["support"]
                      for c in classes) / total if total > 0 else 0.0

    return results, float(macro_f1), float(weighted_f1)


def main():
    base = Path(__file__).resolve().parent.parent
    out_dir = base / "results" / "f1_analysis"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load data
    ds = load_dataset(base / "data" / "dataset.json")
    cal_items, test_items = split_dataset(ds, n_cal=61, n_test=61, random_state=42)

    k4_dir = base / "results" / "exp_C_K4"
    test_correct = np.load(k4_dir / "test_correct.npy").astype(int)
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules = list(cs_dict)
    cal_scores = np.column_stack([np.array(cs_dict[m]) for m in modules])

    # We need predicted labels. Load from calibration_scores or reconstruct.
    # The test_correct tells us if modal == gold, but we need the actual predictions.
    # Let's load the full diagnostic to get predictions.
    casc = json.loads(
        (base / "results" / "cascading_deferral" / "cascading_summary.json").read_text()
    )

    # Gold labels for test items
    gold_labels = [item.verdict for item in test_items]
    n_test = len(gold_labels)

    # We need predicted labels. Since we don't have them directly saved,
    # reconstruct from test_correct + gold: if correct, pred=gold; if wrong, pred=?
    # Actually we can't fully reconstruct predictions from correctness alone.
    # Let's load the raw verifier outputs if available.
    # Check if we have per-item predictions in the diagnostic data.

    # Alternative: load from the dataset module's saved state
    # For now, use test_correct to compute accuracy-based metrics
    # and reconstruct what we can.

    # Actually, for the emit subset, we know:
    # - which items are emitted (from cascading)
    # - which of those are correct (from test_correct)
    # - gold labels (from test_items)
    # We DON'T know the wrong predictions' labels without the raw outputs.

    # However, we can compute RECALL per class (correctly emitted / total in class)
    # and we can bound F1 by computing precision as (correct in predicted class / all predicted as class).

    # Let's check if there are raw predictions saved anywhere
    import glob
    raw_files = glob.glob(str(base / "results" / "exp_C_K4" / "*.json"))
    print("Available K4 files:", [Path(f).name for f in raw_files])

    # Let me look at the calibration_scores.json structure more carefully
    # to see if predictions are embedded
    cs_full = json.loads((k4_dir / "calibration_scores.json").read_text())

    # Check if there are per-item prediction files
    # Actually, for the F1 computation on the EMIT subset, we know:
    # - Gold label for every item
    # - Whether the prediction was correct
    # - If correct: predicted label = gold label
    # - If wrong: we need the actual prediction

    # Since we can't get the actual wrong predictions without the raw data,
    # let's compute what we CAN compute:
    # 1. Per-class RECALL on emit subset (this we have fully)
    # 2. Accuracy (we have)
    # 3. For a rough F1 estimate, we can compute recall exactly and
    #    note that precision requires knowing the predicted distribution

    # BUT - we can also compute a confusion-matrix-compatible metric:
    # For each class c, recall_c = (correct items with gold=c) / (total items with gold=c)
    # This is what we already report. For F1 we need precision too.

    # Let's compute what we definitively can: per-class recall, macro recall,
    # and accuracy. Then note the limitation.

    # Actually, let me try to reconstruct predictions from the verifier's
    # modal class. The pipeline runs K=10 samples and takes the mode.
    # The test_correct array tells us correct/wrong.
    # For correct items: pred = gold
    # For wrong items: pred != gold, but we don't know which class.

    # The dominant class is Refuted (61%). For wrong items, the most likely
    # prediction is Refuted (if gold != Refuted) or Supported (if gold == Refuted).

    # Better approach: reconstruct from the pipeline's actual behavior.
    # The verifier at 67% accuracy on a 61% Refuted dataset likely predicts
    # Refuted for almost everything. Let's verify by checking the error pattern.

    print("\n=== Gold class distribution (test) ===")
    for cls in CLASSES:
        n = sum(1 for g in gold_labels if g == cls)
        n_correct = sum(1 for i, g in enumerate(gold_labels) if g == cls and test_correct[i])
        print(f"  {SHORT[cls]}: n={n}, correct={n_correct}, recall={n_correct/n:.3f}")

    # For wrong items, check if majority are predicted as Refuted
    wrong_idx = [i for i in range(n_test) if test_correct[i] == 0]
    wrong_gold = [gold_labels[i] for i in wrong_idx]
    print(f"\nWrong items ({len(wrong_idx)}):")
    print(f"  Gold distribution of wrong items: {Counter(wrong_gold)}")

    # Since we can't determine exact predictions for wrong items,
    # let's compute the metrics we CAN compute exactly for each condition:
    # Per-class recall, macro recall, and accuracy.
    # We'll also compute a "recall-based" analysis that's fully rigorous.

    print("\n" + "="*70)
    print("FULL ANALYSIS: ACCURACY + PER-CLASS RECALL + MACRO RECALL")
    print("="*70)

    upstream_idx = [i for i, m in enumerate(modules) if "verifier" not in m.lower()]
    m2_idx = next(i for i, m in enumerate(modules) if "retriever" in m.lower())

    conditions = {}

    # 1. Unconditional
    idx_all = list(range(n_test))
    conditions["Unconditional"] = idx_all

    # 2. Retrieval-only baseline
    conditions["Retrieval-only"] = [i for i in range(n_test)
                                      if test_scores[i, m2_idx] < 1.0]

    # 3. Heuristic P70
    thresholds = {k: float(np.percentile(cal_scores[:, k], 70)) for k in upstream_idx}
    heur_emit = []
    for i in range(n_test):
        if test_scores[i, m2_idx] >= 1.0:
            continue
        n_exceed = sum(1 for k in upstream_idx if test_scores[i, k] > thresholds[k])
        if n_exceed >= 2:
            continue
        heur_emit.append(i)
    conditions["Heuristic P70"] = heur_emit

    # 4. Conformal alpha=0.30
    row30 = next(r for r in casc if abs(r["alpha_high"] - 0.30) < 1e-6)
    conf_emit = []
    for k in EMIT_KEYS:
        conf_emit.extend(row30["categories"].get(k, {"items": []})["items"])
    conf_emit = sorted(set(conf_emit))
    conditions["Conformal 0.30"] = conf_emit

    # 5. Conformal alpha=0.40
    row40 = next(r for r in casc if abs(r["alpha_high"] - 0.40) < 1e-6)
    conf40_emit = []
    for k in EMIT_KEYS:
        conf40_emit.extend(row40["categories"].get(k, {"items": []})["items"])
    conf40_emit = sorted(set(conf40_emit))
    conditions["Conformal 0.40"] = conf40_emit

    # 6. Mondrian-M3 (from conformal 0.30, apply M3 filter)
    M3_IDX = 2
    M4_IDX = 3
    cal_m3 = cal_scores[:, M3_IDX]
    cal_m4 = cal_scores[:, M4_IDX]
    sat_cal = cal_m4 >= 1.0
    import math
    def conf_quantile(scores, alpha):
        s = np.sort(scores)
        n = len(s)
        q = math.ceil((n + 1) * (1 - alpha)) / n
        if q > 1.0:
            return float(s[-1])
        return float(np.quantile(s, q, method="higher"))

    tau_A = conf_quantile(cal_m3[sat_cal], 0.30)
    mondrian_emit = []
    for i in conf_emit:
        stratum = "A" if test_scores[i, M4_IDX] >= 1.0 else "B"
        if stratum == "A" and test_scores[i, M3_IDX] > tau_A:
            continue  # diverted
        mondrian_emit.append(i)
    conditions["Mondrian-M3"] = mondrian_emit

    # Compute metrics for each condition
    all_results = {}
    print(f"\n{'Method':<20} {'n':>3} {'Cov':>5} {'Acc':>6}  ", end="")
    for cls in CLASSES:
        print(f"{SHORT[cls]:>5}", end=" ")
    print(f"{'MacR':>6}")
    print("-" * 75)

    for name, emit_idx in conditions.items():
        n = len(emit_idx)
        cov = n / n_test
        acc = float(test_correct[emit_idx].mean()) if n > 0 else 0.0

        # Per-class recall on this subset
        per_class = {}
        recalls = []
        for cls in CLASSES:
            cls_in_emit = [i for i in emit_idx if gold_labels[i] == cls]
            cls_total = sum(1 for g in gold_labels if g == cls)
            cls_correct = sum(1 for i in cls_in_emit if test_correct[i])
            # Recall = correct in class / total in class (NOT total in emit)
            # This is "class coverage recall": of all items of this class,
            # how many does the framework correctly emit?
            recall = cls_correct / cls_total if cls_total > 0 else 0.0
            # Also compute emit-conditional accuracy per class
            emit_acc = cls_correct / len(cls_in_emit) if cls_in_emit else 0.0
            per_class[cls] = {
                "in_emit": len(cls_in_emit),
                "correct": cls_correct,
                "total_in_test": cls_total,
                "recall": recall,
                "emit_accuracy": emit_acc,
            }
            recalls.append(recall)

        macro_recall = float(np.mean(recalls))

        all_results[name] = {
            "n": n, "coverage": cov, "accuracy": acc,
            "macro_recall": macro_recall, "per_class": per_class,
        }

        print(f"{name:<20} {n:>3} {cov:>5.0%} {acc:>6.3f}  ", end="")
        for cls in CLASSES:
            print(f"{per_class[cls]['recall']:>5.2f}", end=" ")
        print(f"{macro_recall:>6.3f}")

    # Save
    output = {"conditions": {}}
    for name, r in all_results.items():
        output["conditions"][name] = r
    (out_dir / "f1_analysis.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8"
    )

    # Print LaTeX-ready table
    print("\n\n=== LATEX TABLE ===\n")
    print(r"\begin{tabular}{l c c c c c c c c}")
    print(r"\toprule")
    print(r"Method & $n$ & Cov. & Acc & R\textsubscript{SUP} & R\textsubscript{REF} & R\textsubscript{NEE} & R\textsubscript{CONF} & MacroR \\")
    print(r"\midrule")
    for name, r in all_results.items():
        pc = r["per_class"]
        row = f"{name:<20} & {r['n']} & {r['coverage']:.0%} & {r['accuracy']:.3f}"
        for cls in CLASSES:
            row += f" & {pc[cls]['recall']:.2f}"
        row += f" & {r['macro_recall']:.3f} \\\\"
        print(row)
    print(r"\bottomrule")
    print(r"\end{tabular}")

    print(f"\nSaved to {out_dir}")


if __name__ == "__main__":
    main()
