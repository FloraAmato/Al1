#!/usr/bin/env python3
"""
Bootstrap CIs + Risk-Coverage Curve + AURC
Uses the actual saved emit/escalate assignments from the cascading deferral.

Produces:
  - fig_risk_coverage.pdf           Risk-coverage curve with AURC
  - fig_bootstrap_ci_accuracy.pdf   Bootstrap CI bars per alpha
  - uncertainty_quantification.json  Machine-readable results
"""
import json, math, sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from conformal_agentic_rag.dataset import load_dataset, split_dataset

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.6,
    "axes.edgecolor": "#444444", "axes.labelcolor": "#222222",
    "xtick.color": "#444444", "ytick.color": "#444444",
    "grid.linewidth": 0.4, "grid.color": "#dddddd",
    "savefig.dpi": 300, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
})


# ═══════════════════════════════════════════════════════════════════════

def wilson_ci(k, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p_hat = k / n
    denom = 1 + z**2 / n
    centre = (p_hat + z**2 / (2 * n)) / denom
    margin = z * np.sqrt(p_hat * (1 - p_hat) / n + z**2 / (4 * n**2)) / denom
    return (max(0.0, centre - margin), min(1.0, centre + margin))


def bootstrap_accuracy_ci(correct_mask, n_boot=5000, ci=0.95, rng=None):
    if rng is None:
        rng = np.random.default_rng(42)
    n = len(correct_mask)
    if n == 0:
        return 0.0, (0.0, 1.0)
    accs = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        accs[b] = correct_mask[idx].mean()
    lo = np.percentile(accs, (1 - ci) / 2 * 100)
    hi = np.percentile(accs, (1 + ci) / 2 * 100)
    return float(correct_mask.mean()), (float(lo), float(hi))


def conformal_quantile(scores, alpha):
    s = np.sort(scores)
    n = len(s)
    q_level = math.ceil((n + 1) * (1 - alpha)) / n
    if q_level > 1.0:
        return float(s[-1])
    return float(np.quantile(s, q_level, method="higher"))


EMIT_KEYS = [
    "HIGH-CONFIDENCE", "MODERATE-CONFIDENCE",
    "ESCALATE-VERIFIER-CONFLICT",
    "ROUTE-TO-SKIP-DECOMPOSER", "ROUTE-TO-SKIP-READER", "RESIDUAL",
]
ESCALATE_KEYS = [
    "ESCALATE-RETRIEVAL-FAILURE", "ESCALATE-MULTIPLE-FAILURE",
]


def get_emit_escalate_from_cascading(row):
    """Extract emit and escalate item indices from cascading summary row."""
    cats = row["categories"]
    emit_items = []
    for k in EMIT_KEYS:
        emit_items.extend(cats.get(k, {"items": []})["items"])
    esc_items = []
    for k in ESCALATE_KEYS:
        esc_items.extend(cats.get(k, {"items": []})["items"])
    return sorted(set(emit_items)), sorted(set(esc_items))


# ═══════════════════════════════════════════════════════════════════════

def main():
    base = Path(__file__).resolve().parent.parent
    out_dir = base / "results" / "uncertainty_quantification"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load data
    k4_dir = base / "results" / "exp_C_K4"
    test_correct = np.load(k4_dir / "test_correct.npy").astype(int)
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules = list(cs_dict)
    cal_scores = np.column_stack([np.array(cs_dict[m]) for m in modules])
    n_test = len(test_correct)

    # Load actual cascading deferral results
    cascading = json.loads(
        (base / "results" / "cascading_deferral" / "cascading_summary.json").read_text()
    )

    rng = np.random.default_rng(42)

    # ─── 1) Bootstrap CIs at each saved alpha ───────────────────────
    ci_results = []
    for row in cascading:
        alpha_h = row["alpha_high"]
        emit_items, esc_items = get_emit_escalate_from_cascading(row)
        n_emit = len(emit_items)
        n_esc = len(esc_items)

        if n_emit > 0:
            emit_correct = test_correct[emit_items]
            acc_point, (acc_lo, acc_hi) = bootstrap_accuracy_ci(emit_correct, rng=rng)
            k_correct = int(emit_correct.sum())
            wil_lo, wil_hi = wilson_ci(k_correct, n_emit)
        else:
            acc_point, acc_lo, acc_hi = 1.0, 0.0, 1.0
            wil_lo, wil_hi = 0.0, 1.0
            k_correct = 0

        if n_esc > 0:
            esc_correct = test_correct[esc_items]
            esc_acc_point = float(esc_correct.mean())
            _, (esc_lo, esc_hi) = bootstrap_accuracy_ci(esc_correct, rng=rng)
        else:
            esc_acc_point, esc_lo, esc_hi = 0.0, 0.0, 0.0

        r = {
            "alpha_h": float(alpha_h),
            "n_emit": n_emit,
            "n_escalate": n_esc,
            "coverage": n_emit / n_test,
            "emit_accuracy": acc_point,
            "emit_correct": k_correct,
            "emit_bootstrap_95ci": [acc_lo, acc_hi],
            "emit_wilson_95ci": [wil_lo, wil_hi],
            "escalate_would_be_accuracy": esc_acc_point,
            "escalate_bootstrap_95ci": [esc_lo, esc_hi],
        }
        ci_results.append(r)
        print(f"α_h={alpha_h:.2f}: emit={n_emit}, acc={acc_point:.3f} "
              f"[{acc_lo:.3f}, {acc_hi:.3f}] (boot) "
              f"[{wil_lo:.3f}, {wil_hi:.3f}] (Wilson)")

    # ─── 2) Risk-Coverage Curve ──────────────────────────────────────
    # Use a score-based ranking for the continuous curve.
    # We rank items by a composite "confidence" measure:
    # items that appear in EMIT at lower alpha are more confident.
    # For each item, find the lowest alpha at which it is escalated.
    # Items always emitted get confidence 1.0; items always escalated get 0.0.

    # Build per-item confidence ranking from cascading data
    item_max_alpha_emitted = np.full(n_test, -1.0)
    for row in cascading:
        alpha_h = row["alpha_high"]
        emit_items, _ = get_emit_escalate_from_cascading(row)
        for i in emit_items:
            item_max_alpha_emitted[i] = max(item_max_alpha_emitted[i], alpha_h)

    # Also use composite module scores for a smoother ranking
    # Combine M1-M4 into a single "nonconformity" score
    # (average CDF rank across upstream modules)
    upstream_idx = [i for i, m in enumerate(modules) if "verifier" not in m.lower()]
    composite_score = np.zeros(n_test)
    for k in upstream_idx:
        cal_k = cal_scores[:, k]
        for i in range(n_test):
            composite_score[i] += (cal_k <= test_scores[i, k]).sum() / len(cal_k)
    composite_score /= len(upstream_idx)

    # Sort items by composite score (ascending = most confident first)
    sort_order = np.argsort(composite_score)
    coverages = []
    risks = []
    cum_correct = 0
    for j in range(1, n_test + 1):
        cum_correct += test_correct[sort_order[j - 1]]
        cov = j / n_test
        acc = cum_correct / j
        coverages.append(cov)
        risks.append(1.0 - acc)

    coverages = np.array(coverages)
    risks_arr = np.array(risks)

    # AURC
    aurc = float(np.trapezoid(risks_arr, coverages))

    # Oracle (sort by correctness: correct first → 0 risk until coverage = fraction_correct)
    oracle_order = np.argsort(-test_correct)  # correct first
    oracle_risks = []
    cum = 0
    for j in range(1, n_test + 1):
        cum += test_correct[oracle_order[j - 1]]
        oracle_risks.append(1.0 - cum / j)
    oracle_risk = np.array(oracle_risks)
    oracle_aurc = float(np.trapezoid(oracle_risk, coverages))

    # Random baseline
    unconditional_risk = 1.0 - test_correct.mean()

    print(f"\nAURC = {aurc:.4f}")
    print(f"Oracle AURC = {oracle_aurc:.4f}")
    print(f"Random AURC (uniform) = {unconditional_risk:.4f}")
    print(f"E-AURC (excess) = {aurc - oracle_aurc:.4f}")

    # Plot
    fig, ax = plt.subplots(figsize=(5.5, 3.8))
    ax.plot(coverages, risks_arr, "-", color="#1f5582",
            linewidth=1.5, label=f"Framework (AURC={aurc:.3f})")
    ax.plot(coverages, oracle_risk, "--", color="#3d8b3d",
            linewidth=1.0, alpha=0.7, label=f"Oracle (AURC={oracle_aurc:.3f})")
    ax.axhline(unconditional_risk, color="#c44f4f", linestyle=":",
               linewidth=1.0, alpha=0.7,
               label=f"Random (risk={unconditional_risk:.3f})")

    # Mark the saved alpha operating points
    markers = ["D", "o", "s", "^", "v"]
    for idx_r, r in enumerate(ci_results):
        c = r["coverage"]
        rsk = 1.0 - r["emit_accuracy"]
        ax.plot(c, rsk, markers[idx_r % len(markers)], color="#e8a13a",
                markersize=8, zorder=5, markeredgecolor="black",
                markeredgewidth=0.5,
                label=rf"$\alpha_h$={r['alpha_h']:.2f}")

    ax.set_xlabel("Coverage (fraction emitted)")
    ax.set_ylabel("Risk (1 − accuracy on emitted)")
    ax.set_title("Risk–Coverage Curve with AURC")
    ax.legend(loc="upper left", fontsize=6.5, framealpha=0.9)
    ax.set_xlim(0, 1.05)
    ax.set_ylim(-0.02, 0.55)
    ax.grid(True, alpha=0.3)
    fig.savefig(out_dir / "fig_risk_coverage.pdf")
    plt.close(fig)
    print(f"\nSaved {out_dir / 'fig_risk_coverage.pdf'}")

    # ─── 3) Bootstrap CI bar chart ───────────────────────────────────
    fig, ax = plt.subplots(figsize=(5.5, 3.5))
    x_pos = np.arange(len(ci_results))
    accs = [r["emit_accuracy"] for r in ci_results]
    boot_lo = [r["emit_bootstrap_95ci"][0] for r in ci_results]
    boot_hi = [r["emit_bootstrap_95ci"][1] for r in ci_results]
    yerr_lo = [a - l for a, l in zip(accs, boot_lo)]
    yerr_hi = [h - a for a, h in zip(accs, boot_hi)]
    wil_lo_vals = [r["emit_wilson_95ci"][0] for r in ci_results]
    wil_hi_vals = [r["emit_wilson_95ci"][1] for r in ci_results]

    bars = ax.bar(x_pos, accs, width=0.5, color="#1f5582", alpha=0.7, zorder=2)
    ax.errorbar(x_pos, accs, yerr=[yerr_lo, yerr_hi],
                fmt="none", color="black", capsize=4, linewidth=1.2, zorder=3,
                label="Bootstrap 95% CI")

    for i in range(len(ci_results)):
        ax.plot([i + 0.15, i + 0.15], [wil_lo_vals[i], wil_hi_vals[i]],
                color="#c44f4f", linewidth=1.5, zorder=4)
        if i == 0:
            ax.plot(i + 0.15, accs[i], "d", color="#c44f4f", markersize=4,
                    zorder=5, label="Wilson 95% CI")
        ax.plot(i + 0.15, wil_lo_vals[i], "_", color="#c44f4f", markersize=6, zorder=5)
        ax.plot(i + 0.15, wil_hi_vals[i], "_", color="#c44f4f", markersize=6, zorder=5)

    ax.axhline(test_correct.mean(), color="#999999", linestyle="--",
               linewidth=1, label=f"Unconditional acc.={test_correct.mean():.2f}")

    for i, r in enumerate(ci_results):
        ax.text(i, 0.02, f"n={r['n_emit']}\n({r['coverage']:.0%})",
                ha="center", va="bottom", fontsize=6.5, color="#444444")

    ax.set_xticks(x_pos)
    ax.set_xticklabels([f"$\\alpha_h$={r['alpha_h']:.2f}" for r in ci_results])
    ax.set_ylabel("Accuracy on emitted items")
    ax.set_title("Emit Accuracy with 95\\% Confidence Intervals")
    ax.set_ylim(0, 1.08)
    ax.legend(loc="upper right", fontsize=7, framealpha=0.9)
    ax.grid(True, alpha=0.3, axis="y")
    fig.savefig(out_dir / "fig_bootstrap_ci_accuracy.pdf")
    plt.close(fig)
    print(f"Saved {out_dir / 'fig_bootstrap_ci_accuracy.pdf'}")

    # ─── 4) Mondrian bootstrap CIs ──────────────────────────────────
    M3_IDX, M4_IDX = 2, 3
    cal_m4 = cal_scores[:, M4_IDX]
    cal_m3 = cal_scores[:, M3_IDX]
    sat_cal = cal_m4 >= 1.0
    n_cal_A = int(sat_cal.sum())

    n_boot = 5000
    tau_A_boot = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n_cal_A, size=n_cal_A)
        tau_A_boot[b] = conformal_quantile(cal_m3[sat_cal][idx], 0.30)
    tau_A_point = conformal_quantile(cal_m3[sat_cal], 0.30)
    tau_A_ci = (float(np.percentile(tau_A_boot, 2.5)),
                float(np.percentile(tau_A_boot, 97.5)))

    print(f"\nMondrian τ_A = {tau_A_point:.4f} [{tau_A_ci[0]:.4f}, {tau_A_ci[1]:.4f}]")

    # ─── 5) Per-attribution-source CIs ──────────────────────────────
    diag = json.loads(
        (base / "results" / "simplified_diagnostic" / "diagnostic_full.json").read_text()
    )
    ref_alpha = next(a for a in diag if abs(a["alpha_high"] - 0.30) < 1e-6)
    attrib_cis = {}
    for src, info in ref_alpha["by_source"].items():
        if info["n"] > 0:
            items = info.get("items", [])
            if items:
                src_correct = test_correct[items]
                acc, (lo, hi) = bootstrap_accuracy_ci(src_correct, rng=rng)
                attrib_cis[src] = {"n": info["n"], "accuracy": acc,
                                   "bootstrap_95ci": [lo, hi]}
                print(f"  {src}: n={info['n']}, acc={acc:.3f} [{lo:.3f}, {hi:.3f}]")

    # ─── 6) Save ─────────────────────────────────────────────────────
    output = {
        "risk_coverage": {
            "aurc": aurc, "oracle_aurc": oracle_aurc,
            "excess_aurc": aurc - oracle_aurc,
            "random_risk": float(unconditional_risk),
        },
        "bootstrap_cis": ci_results,
        "mondrian_bootstrap": {
            "tau_A": tau_A_point,
            "tau_A_95ci": list(tau_A_ci),
            "n_cal_stratum_A": n_cal_A,
        },
        "attribution_cis_alpha030": attrib_cis,
    }
    (out_dir / "uncertainty_quantification.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8"
    )
    print(f"\nAll results saved to {out_dir}")


if __name__ == "__main__":
    main()
