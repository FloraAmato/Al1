#!/usr/bin/env python3
"""
Simple-baseline comparison: fixed-percentile heuristic vs conformal framework.

Baseline rule (no conformal machinery):
  Escalate if s2 = 1.0,
  OR if >=2 of {s1, s2, s3} exceed their 70th calibration percentile.

This tests whether the conformal framework's emit/escalate decisions
are doing something a trivial threshold rule wouldn't.
"""
import json, sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from conformal_agentic_rag.dataset import load_dataset, split_dataset

EMIT_KEYS = [
    "HIGH-CONFIDENCE", "MODERATE-CONFIDENCE",
    "ESCALATE-VERIFIER-CONFLICT",
    "ROUTE-TO-SKIP-DECOMPOSER", "ROUTE-TO-SKIP-READER", "RESIDUAL",
]
ESCALATE_KEYS = [
    "ESCALATE-RETRIEVAL-FAILURE", "ESCALATE-MULTIPLE-FAILURE",
]


def wilson_ci(k, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    d = 1 + z**2 / n
    c = (p + z**2 / (2 * n)) / d
    m = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / d
    return (max(0.0, c - m), min(1.0, c + m))


def bootstrap_ci(correct, n_boot=5000, rng=None):
    if rng is None:
        rng = np.random.default_rng(42)
    n = len(correct)
    if n == 0:
        return 0.0, (0.0, 1.0)
    accs = np.array([correct[rng.integers(0, n, n)].mean() for _ in range(n_boot)])
    return float(correct.mean()), (float(np.percentile(accs, 2.5)), float(np.percentile(accs, 97.5)))


def main():
    base = Path(__file__).resolve().parent.parent
    out_dir = base / "results" / "baseline_comparison"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load data
    k4_dir = base / "results" / "exp_C_K4"
    test_correct = np.load(k4_dir / "test_correct.npy").astype(int)
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules = list(cs_dict)
    cal_scores = np.column_stack([np.array(cs_dict[m]) for m in modules])
    n_test = len(test_correct)

    # Module indices
    upstream_idx = [i for i, m in enumerate(modules) if "verifier" not in m.lower()]
    verifier_idx = next(i for i, m in enumerate(modules) if "verifier" in m.lower())
    m2_idx = next(i for i, m in enumerate(modules) if "retriever" in m.lower())

    rng = np.random.default_rng(42)

    # Load conformal framework results for comparison
    cascading = json.loads(
        (base / "results" / "cascading_deferral" / "cascading_summary.json").read_text()
    )

    # ─── Simple baseline: fixed-percentile heuristic ────────────────
    # Compute 70th percentile of each upstream module on calibration
    percentile_level = 70
    thresholds_p70 = {}
    for k in upstream_idx:
        thresholds_p70[k] = float(np.percentile(cal_scores[:, k], percentile_level))
    print("Fixed-percentile thresholds (70th pct of calibration):")
    for k in upstream_idx:
        print(f"  {modules[k]}: {thresholds_p70[k]:.4f}")

    # Also test a few other percentile levels
    results_all = []
    for pct in [60, 65, 70, 75, 80, 85]:
        thresholds = {k: float(np.percentile(cal_scores[:, k], pct)) for k in upstream_idx}
        emit_mask = np.ones(n_test, dtype=bool)
        for i in range(n_test):
            # Rule 1: escalate if s2 = 1.0
            if test_scores[i, m2_idx] >= 1.0:
                emit_mask[i] = False
                continue
            # Rule 2: escalate if >=2 upstream modules exceed their percentile
            n_exceed = sum(1 for k in upstream_idx if test_scores[i, k] > thresholds[k])
            if n_exceed >= 2:
                emit_mask[i] = False

        n_emit = int(emit_mask.sum())
        if n_emit > 0:
            acc = float(test_correct[emit_mask].mean())
            k_correct = int(test_correct[emit_mask].sum())
            wlo, whi = wilson_ci(k_correct, n_emit)
        else:
            acc, k_correct, wlo, whi = 0.0, 0, 0.0, 1.0

        _, (blo, bhi) = bootstrap_ci(test_correct[emit_mask], rng=rng) if n_emit > 0 else (0.0, (0.0, 1.0))

        r = {
            "method": f"Heuristic-P{pct}",
            "percentile": pct,
            "n_emit": n_emit,
            "n_escalate": n_test - n_emit,
            "coverage": n_emit / n_test,
            "accuracy": acc,
            "correct": k_correct,
            "wilson_95ci": [wlo, whi],
            "bootstrap_95ci": [blo, bhi],
        }
        results_all.append(r)
        print(f"  P{pct}: emit={n_emit} ({n_emit/n_test:.0%}), acc={acc:.3f} "
              f"[{wlo:.3f}, {whi:.3f}]")

    # ─── Conformal framework results for direct comparison ──────────
    print("\nConformal framework results:")
    conformal_results = []
    for row in cascading:
        alpha_h = row["alpha_high"]
        cats = row["categories"]
        emit_items = []
        for k in EMIT_KEYS:
            emit_items.extend(cats.get(k, {"items": []})["items"])
        emit_items = sorted(set(emit_items))
        n_emit = len(emit_items)
        if n_emit > 0:
            acc = float(test_correct[emit_items].mean())
            k_correct = int(test_correct[emit_items].sum())
            wlo, whi = wilson_ci(k_correct, n_emit)
        else:
            acc, k_correct, wlo, whi = 0.0, 0, 0.0, 1.0
        _, (blo, bhi) = bootstrap_ci(test_correct[emit_items], rng=rng) if n_emit > 0 else (0.0, (0.0, 1.0))

        cr = {
            "method": f"Conformal-alpha{alpha_h:.2f}",
            "alpha_h": alpha_h,
            "n_emit": n_emit,
            "n_escalate": n_test - n_emit,
            "coverage": n_emit / n_test,
            "accuracy": acc,
            "correct": k_correct,
            "wilson_95ci": [wlo, whi],
            "bootstrap_95ci": [blo, bhi],
        }
        conformal_results.append(cr)
        print(f"  α_h={alpha_h:.2f}: emit={n_emit} ({n_emit/n_test:.0%}), "
              f"acc={acc:.3f} [{wlo:.3f}, {whi:.3f}]")

    # ─── Head-to-head: best heuristic vs conformal at matched coverage ─
    print("\n=== HEAD-TO-HEAD COMPARISON ===")
    # Find the heuristic closest to 69% coverage (the conformal operating point)
    target_cov = 42 / 61
    best_heur = min(results_all, key=lambda r: abs(r["coverage"] - target_cov))
    conf_ref = next(r for r in conformal_results if abs(r["alpha_h"] - 0.30) < 1e-6)

    print(f"\nMatched comparison (target coverage ~69%):")
    print(f"  {best_heur['method']}: n={best_heur['n_emit']}, cov={best_heur['coverage']:.0%}, "
          f"acc={best_heur['accuracy']:.3f} {best_heur['wilson_95ci']}")
    print(f"  Conformal α_h=0.30: n={conf_ref['n_emit']}, cov={conf_ref['coverage']:.0%}, "
          f"acc={conf_ref['accuracy']:.3f} {conf_ref['wilson_95ci']}")

    # ─── Also test: escalate only if s2 = 1.0 (simplest possible) ───
    emit_s2_only = test_scores[:, m2_idx] < 1.0
    n_s2 = int(emit_s2_only.sum())
    acc_s2 = float(test_correct[emit_s2_only].mean()) if n_s2 > 0 else 0.0
    k_s2 = int(test_correct[emit_s2_only].sum()) if n_s2 > 0 else 0
    wlo_s2, whi_s2 = wilson_ci(k_s2, n_s2)
    _, (blo_s2, bhi_s2) = bootstrap_ci(test_correct[emit_s2_only], rng=rng)
    print(f"\n  Simplest baseline (escalate iff s2=1.0): n={n_s2}, "
          f"cov={n_s2/n_test:.0%}, acc={acc_s2:.3f} [{wlo_s2:.3f}, {whi_s2:.3f}]")

    simplest = {
        "method": "Retrieval-only",
        "n_emit": n_s2,
        "n_escalate": n_test - n_s2,
        "coverage": n_s2 / n_test,
        "accuracy": acc_s2,
        "correct": k_s2,
        "wilson_95ci": [wlo_s2, whi_s2],
        "bootstrap_95ci": [blo_s2, bhi_s2],
    }

    # ─── Save everything ─────────────────────────────────────────────
    output = {
        "heuristic_results": results_all,
        "conformal_results": conformal_results,
        "simplest_baseline": simplest,
        "best_heuristic_match": best_heur,
        "conformal_reference": conf_ref,
    }
    (out_dir / "baseline_comparison.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8"
    )
    print(f"\nSaved to {out_dir / 'baseline_comparison.json'}")


if __name__ == "__main__":
    main()
