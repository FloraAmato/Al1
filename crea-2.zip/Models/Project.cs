﻿namespace CreaProject.Models
{
    public class Project
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Image { get; set; }
    }
}
