using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CreaProject.Pages;

[AllowAnonymous]
public class LegalTerms : PageModel
{
    public void OnGet()
    {
        
    }
}