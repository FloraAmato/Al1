"""
CREST-NIDS Data Loading — v4.1
NEW: WeightedRandomSampler for class-balanced batches
NEW: seed parameter for reproducible multi-seed runs
"""
import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from config import BATCH_SIZE, NUM_WORKERS, DATASET_CONFIGS, DEVICE


class NIDSDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.LongTensor(y)
    
    def __len__(self):
        return len(self.y)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


class DataPreprocessor:
    def __init__(self, dataset_name, data_path, max_samples=None, seed=42):
        self.dataset_name = dataset_name
        self.data_path = data_path
        self.max_samples = max_samples
        self.seed = seed
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.class_names = None
        self.class_to_idx = None
        self.num_features = None
        self.num_classes = None
        self.osr_holdout_class = None
        self.class_weights = None
    
    def load_and_preprocess(self):
        config = DATASET_CONFIGS[self.dataset_name]
        label_col = config['label_column']
        
        if os.path.isdir(self.data_path):
            csv_files = sorted([f for f in os.listdir(self.data_path) if f.endswith('.csv')])
            print(f"  Loading {len(csv_files)} {self.dataset_name} file(s)...")
            dfs = []
            for f in csv_files:
                print(f"    Reading {f}...")
                df = pd.read_csv(os.path.join(self.data_path, f), low_memory=False)
                dfs.append(df)
            df = pd.concat(dfs, ignore_index=True)
        else:
            print(f"  Loading {self.data_path}...")
            df = pd.read_csv(self.data_path, low_memory=False)
        
        print(f"    Total rows: {len(df):,}")
        
        df.columns = df.columns.str.strip()
        label_col = label_col.strip()
        df[label_col] = df[label_col].astype(str).str.strip()
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if label_col in numeric_cols:
            numeric_cols.remove(label_col)
        
        df[numeric_cols] = df[numeric_cols].replace([np.inf, -np.inf], np.nan)
        df[numeric_cols] = df[numeric_cols].fillna(0)
        
        labels = df[label_col].values
        feature_cols = [c for c in numeric_cols if c != label_col]
        X = df[feature_cols].values.astype(np.float32)
        
        unique_labels, counts = np.unique(labels, return_counts=True)
        print(f"Dataset: {self.dataset_name}")
        print(f"  Samples: {len(labels):,}")
        print(f"  Features: {len(feature_cols)}")
        print(f"  Classes: {len(unique_labels)}")
        print(f"  Class distribution:")
        for lbl, cnt in sorted(zip(unique_labels, counts), key=lambda x: x[0]):
            print(f"    {lbl}: {cnt:,} ({cnt/len(labels)*100:.1f}%)")
        
        print(f"\nActual classes found in data: {sorted(unique_labels.tolist())}")
        
        # OSR holdout
        osr_class = config['osr_holdout_class']
        osr_mask = np.zeros(len(labels), dtype=bool)
        if osr_class and osr_class in unique_labels:
            osr_mask = (labels == osr_class)
            print(f"\n  OSR holdout class: {osr_class} ({osr_mask.sum():,} samples)\n")
            self.osr_holdout_class = osr_class
        elif osr_class:
            print(f"\n  [WARNING] OSR holdout class '{osr_class}' not found in data\n")
        
        train_mask = ~osr_mask
        X_main = X[train_mask]
        y_main = labels[train_mask]
        X_osr = X[osr_mask] if osr_mask.sum() > 0 else None
        
        self.label_encoder.fit(y_main)
        y_encoded = self.label_encoder.transform(y_main)
        self.class_names = list(self.label_encoder.classes_)
        self.class_to_idx = {name: idx for idx, name in enumerate(self.class_names)}
        self.num_classes = len(self.class_names)
        self.num_features = X_main.shape[1]
        
        if self.max_samples and len(X_main) > self.max_samples:
            rng = np.random.RandomState(self.seed)
            indices = rng.choice(len(X_main), self.max_samples, replace=False)
            X_main = X_main[indices]
            y_encoded = y_encoded[indices]
        
        # Split with seed
        X_tv, X_test, y_tv, y_test = train_test_split(
            X_main, y_encoded, test_size=0.2, stratify=y_encoded, random_state=self.seed)
        X_train, X_val, y_train, y_val = train_test_split(
            X_tv, y_tv, test_size=0.1, stratify=y_tv, random_state=self.seed)
        
        print(f"  Train: {len(X_train):,}  Val: {len(X_val):,}  Test: {len(X_test):,}")
        
        X_train = self.scaler.fit_transform(X_train)
        X_val = self.scaler.transform(X_val)
        X_test = self.scaler.transform(X_test)
        if X_osr is not None:
            X_osr = self.scaler.transform(X_osr)
        
        # Class weights
        class_counts = np.bincount(y_train, minlength=self.num_classes)
        total = class_counts.sum()
        weights = np.sqrt(total / (class_counts + 1))
        weights = weights / weights.sum()
        self.class_weights = torch.FloatTensor(weights).to(DEVICE)
        
        # === WeightedRandomSampler — oversamples rare classes ===
        sample_weights = np.zeros(len(y_train))
        for i in range(self.num_classes):
            mask = (y_train == i)
            if mask.sum() > 0:
                sample_weights[mask] = 1.0 / mask.sum()
        
        sampler = WeightedRandomSampler(
            weights=torch.DoubleTensor(sample_weights),
            num_samples=len(y_train),
            replacement=True
        )
        
        train_dataset = NIDSDataset(X_train, y_train)
        val_dataset = NIDSDataset(X_val, y_val)
        test_dataset = NIDSDataset(X_test, y_test)
        osr_dataset = NIDSDataset(X_osr, np.zeros(len(X_osr), dtype=np.int64)) if X_osr is not None else None
        
        # NOTE: sampler replaces shuffle=True
        train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, sampler=sampler,
                                  num_workers=NUM_WORKERS, pin_memory=True, drop_last=True)
        val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False,
                                num_workers=NUM_WORKERS, pin_memory=True)
        test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False,
                                 num_workers=NUM_WORKERS, pin_memory=True)
        osr_loader = DataLoader(osr_dataset, batch_size=BATCH_SIZE, shuffle=False,
                                num_workers=NUM_WORKERS) if osr_dataset is not None else None
        
        return train_loader, val_loader, test_loader, osr_loader


def create_synthetic_dataset(num_samples=10000, num_features=77, num_classes=5, seed=42):
    rng = np.random.RandomState(seed)
    X = rng.randn(num_samples, num_features).astype(np.float32)
    y = rng.randint(0, num_classes, num_samples)
    for c in range(num_classes):
        X[y == c] += rng.randn(num_features) * 2
    
    class_names = [f'Class_{i}' for i in range(num_classes)]
    class_to_idx = {name: i for i, name in enumerate(class_names)}
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=seed)
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.1, random_state=seed)
    
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)
    
    train_loader = DataLoader(NIDSDataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(NIDSDataset(X_val, y_val), batch_size=BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(NIDSDataset(X_test, y_test), batch_size=BATCH_SIZE, shuffle=False)
    
    return train_loader, val_loader, test_loader, None, num_features, num_classes, class_names, class_to_idx
