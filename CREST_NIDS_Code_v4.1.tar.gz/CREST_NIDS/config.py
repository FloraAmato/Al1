"""
CREST-NIDS Configuration — v4.1
"""
import torch

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# === Model architecture ===
EMBEDDING_DIM = 128
PROJECTION_DIM = 64
NUM_CONCEPTS = 32
CONCEPT_TAU = 0.1
NUM_TRANSFORMER_LAYERS = 2
NUM_HEADS = 4
NUM_BINDING_HEADS = 2
BOTTLENECK_DIM = 32
COSINE_SCALE = 16.0
ENCODER_CHANNELS = [32, 64, 128, 256]
ENCODER_DROPOUT = 0.1
CLASSIFIER_DROPOUT = 0.3

# === Loss weights ===
LAMBDA = 5.0
MU = 0.001
NU = 0.05
BINARY_WEIGHT = 0.5
MARGIN_REG_WEIGHT = 0.1

# === Constraint field ===
MARGIN_INIT = 1.0
MARGIN_MIN = 0.1
MARGIN_MAX = 1.5
WARMUP_EPOCHS = 3

# === Focal loss ===
FOCAL_GAMMA = 2.0
FOCAL_ALPHA = 0.25
LABEL_SMOOTHING = 0.1

# === Uncertainty / OSR ===
UNCERTAINTY_ALPHA = 0.7
OSR_THRESHOLD = 0.5

# === Training ===
BATCH_SIZE = 512
MAX_EPOCHS = 50
PATIENCE = 10
LR_INIT = 1e-3
LR_MIN = 1e-5
NUM_WORKERS = 0

# === Multi-seed ===
SEEDS = [42, 123, 456]

# === Adversarial ===
FGSM_EPSILONS = [0.01, 0.05, 0.1]
PGD_EPSILONS = [0.01, 0.05, 0.1]
PGD_STEPS = 10
PGD_ALPHA = 0.005

# === Dataset configs ===
DATASET_CONFIGS = {
    'CIC-IDS-2017': {
        'label_column': ' Label',
        'osr_holdout_class': 'DoS slowloris',
        'multi_file': True,
    },
    'ACI-IoT-2023': {
        'label_column': 'label',
        'osr_holdout_class': 'Slowloris',       # NEW: was None
        'multi_file': False,
    },
    'NF-BoT-IoT-V2': {
        'label_column': 'Attack',
        'osr_holdout_class': 'Theft',
        'multi_file': True,
    },
}
