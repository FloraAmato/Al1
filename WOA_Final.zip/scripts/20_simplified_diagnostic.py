#!/usr/bin/env python
"""
Simplified emit-or-escalate diagnostic with source attribution.

Two top-level decisions per item:

  EMIT     - emit the K=4 verifier's modal verdict
  ESCALATE - decline to predict; route to human review

When ESCALATE, attribute the source of uncertainty to one of four buckets:

  ESCALATE-RETRIEVAL  - retriever (M2) was non-conformant
  ESCALATE-READER     - reader (M3) was non-conformant
  ESCALATE-VERIFIER   - upstream OK, verifier samples disagreed
  ESCALATE-MULTIPLE   - >=2 modules simultaneously non-conformant
                        (per-item signals listed: which modules were in tail
                        and at what calibration-rank)

The decomposer (M1) is intentionally not used as an attribution source,
because empirically its tail signal does not predict K=4 verdict failure
on this benchmark.

Reads only saved data; no GPU. Runtime ~5 seconds.

Outputs (results/simplified_diagnostic/)
----------------------------------------
  headline.{tex,md}                    coverage and accuracy across alpha sweep
  attribution.{tex,md}                 escalation source distribution per alpha
  attribution_validity.{tex,md}        would-have-been accuracy per source
  per_class_per_decision.{tex,md}      per-class breakdown EMIT vs each ESCALATE
  multiple_signals.md                  per-item signals for ESCALATE-MULTIPLE
  error_inventory.md                   wrong-emit items per alpha
  diagnostic_full.json                 machine-readable full output
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("20_simplified_diagnostic")


CLASSES = [
    "Supported", "Refuted",
    "Not Enough Evidence",
    "Conflicting Evidence/Cherrypicking",
]
SHORT_CLASS = {
    "Supported": "SUP",
    "Refuted": "REF",
    "Not Enough Evidence": "NEE",
    "Conflicting Evidence/Cherrypicking": "CONF",
}
ESCALATE_SOURCES = [
    "ESCALATE-RETRIEVAL",
    "ESCALATE-READER",
    "ESCALATE-VERIFIER",
    "ESCALATE-MULTIPLE",
]
SHORT_SRC = {
    "ESCALATE-RETRIEVAL": "RETR",
    "ESCALATE-READER": "READER",
    "ESCALATE-VERIFIER": "VERIF",
    "ESCALATE-MULTIPLE": "MULTI",
}


# ====================================================================== #
# Helpers
# ====================================================================== #

def load_dataset_split(data_dir: Path, n_cal: int, n_test: int, seed: int):
    sys.path.insert(0, "src")
    from conformal_agentic_rag.dataset import load_dataset, split_dataset
    ds = load_dataset(data_dir / "dataset.json")
    return split_dataset(ds, n_cal=n_cal, n_test=n_test, random_state=seed)


def per_module_calibration_ranks(
    test_scores: np.ndarray,
    cal_scores: np.ndarray,
    upstream_idx: list[int],
) -> np.ndarray:
    """For each test item and each upstream module, return its empirical
    CDF rank in the calibration distribution (fraction of cal items
    whose score is <= test item's score). Higher rank = more non-conformant."""
    out = np.zeros((test_scores.shape[0], len(upstream_idx)))
    for j, k in enumerate(upstream_idx):
        cal_k = cal_scores[:, k]
        for i in range(test_scores.shape[0]):
            out[i, j] = (cal_k <= test_scores[i, k]).sum() / len(cal_k)
    return out


def collect_emit_items(old_cats: dict) -> list[int]:
    """All categories from the seven-way scheme that emit a verdict."""
    emit_keys = [
        "HIGH-CONFIDENCE",
        "MODERATE-CONFIDENCE",
        "ESCALATE-VERIFIER-CONFLICT",  # we re-classify these as emit-with-flag-or-escalate
        "ROUTE-TO-SKIP-DECOMPOSER",     # decomposer-tail is not predictive
        "ROUTE-TO-SKIP-READER",         # falls back to K=3, but we will emit K=4 here
        "RESIDUAL",
    ]
    items: list[int] = []
    for k in emit_keys:
        items.extend(old_cats.get(k, {"items": []})["items"])
    return items


def attribute_escalation(
    test_idx: int,
    test_ranks: np.ndarray,
    test_scores: np.ndarray,
    upstream_idx: list[int],
    upstream_module_names: list[str],
    verifier_idx: int,
    rank_thresh: float,
    verifier_thresh: float,
) -> tuple[str, dict]:
    """For an escalated item, attribute to a source and return signals.

    Returns (source_name, signals_dict).
    signals_dict has per-module rank and whether each module was in tail.
    """
    ranks_i = test_ranks[test_idx]
    in_tail = ranks_i >= rank_thresh
    n_in_tail = int(in_tail.sum())

    # Per-module signals (always reported, useful for diagnostics)
    signals = {}
    for j, k in enumerate(upstream_idx):
        signals[upstream_module_names[k]] = {
            "rank": float(ranks_i[j]),
            "in_tail": bool(in_tail[j]),
        }
    signals["M4_verifier"] = {
        "score": float(test_scores[test_idx, verifier_idx]),
        "in_tail": bool(test_scores[test_idx, verifier_idx] >= verifier_thresh),
    }

    if n_in_tail >= 2:
        return "ESCALATE-MULTIPLE", signals
    if n_in_tail == 1:
        # Identify which upstream module
        tail_pos = int(np.argmax(in_tail))
        module_name = upstream_module_names[upstream_idx[tail_pos]].lower()
        if "retriever" in module_name:
            return "ESCALATE-RETRIEVAL", signals
        if "reader" in module_name:
            return "ESCALATE-READER", signals
        # decomposer-only tail -> we treat as borderline emit (per design)
        # but to keep coverage of escalation honest, we route to MULTIPLE-style logic
        # NB: in practice this branch fires when ONLY decomposer is in tail
        # We re-classify decomposer-only items as ESCALATE-MULTIPLE since they
        # were not deemed safe to emit but had no clean attribution.
        return "ESCALATE-MULTIPLE", signals
    # n_in_tail == 0; verifier must be the source
    return "ESCALATE-VERIFIER", signals


# ====================================================================== #
# Per-alpha analysis
# ====================================================================== #

def analyze_alpha(
    r: dict,
    test_items: list,
    test_correct_k4: np.ndarray,
    test_ranks: np.ndarray,
    test_scores: np.ndarray,
    upstream_idx: list[int],
    upstream_module_names: list[str],
    verifier_idx: int,
    rank_thresh: float,
    verifier_thresh: float,
) -> dict:
    """Build the simplified emit-or-escalate analysis for one alpha row."""
    n_test = r["n_test"]

    emit_items = collect_emit_items(r["categories"])
    escalate_items = (
        list(r["categories"].get("ESCALATE-RETRIEVAL-FAILURE", {"items": []})["items"])
        + list(r["categories"].get("ESCALATE-MULTIPLE-FAILURE", {"items": []})["items"])
    )

    # Re-attribute escalations under the simplified scheme
    by_source: dict[str, dict] = {s: {"items": [], "signals": []}
                                   for s in ESCALATE_SOURCES}
    for i in escalate_items:
        src, sig = attribute_escalation(
            i, test_ranks, test_scores, upstream_idx,
            upstream_module_names, verifier_idx,
            rank_thresh, verifier_thresh,
        )
        by_source[src]["items"].append(int(i))
        by_source[src]["signals"].append(sig)

    # Compute per-source headline
    sources_summary = {}
    for src in ESCALATE_SOURCES:
        items = by_source[src]["items"]
        n = len(items)
        if n == 0:
            sources_summary[src] = {
                "n": 0, "frac_of_test": 0.0, "frac_of_escalations": 0.0,
                "would_be_accuracy": float("nan"),
                "per_class": {},
                "items": [],
            }
            continue
        wb_acc = float(test_correct_k4[items].mean())
        per_class = {}
        for cls in CLASSES:
            cls_pos = [p for p, item_i in enumerate(items)
                       if test_items[item_i].verdict == cls]
            if not cls_pos: continue
            n_cls = len(cls_pos)
            n_correct = int(test_correct_k4[
                [items[p] for p in cls_pos]
            ].sum())
            per_class[cls] = {
                "n": n_cls,
                "correct": n_correct,
                "wrong": n_cls - n_correct,
                "accuracy": n_correct / n_cls,
            }
        sources_summary[src] = {
            "n": n,
            "frac_of_test": n / n_test,
            "frac_of_escalations": (n / len(escalate_items)
                                    if escalate_items else 0.0),
            "would_be_accuracy": wb_acc,
            "per_class": per_class,
            "items": items,
            "signals": by_source[src]["signals"],
        }

    # EMIT summary
    emit_correct = int(test_correct_k4[emit_items].sum()) if emit_items else 0
    emit_per_class = {}
    for cls in CLASSES:
        cls_pos = [p for p, item_i in enumerate(emit_items)
                   if test_items[item_i].verdict == cls]
        if not cls_pos: continue
        n_cls = len(cls_pos)
        n_correct = int(test_correct_k4[
            [emit_items[p] for p in cls_pos]
        ].sum())
        emit_per_class[cls] = {
            "n": n_cls,
            "correct": n_correct,
            "wrong": n_cls - n_correct,
            "accuracy": n_correct / n_cls,
        }

    # === Option B: binary EMIT-vs-ESCALATE classification metrics ===
    # Treat the framework's decision as a binary classifier whose target is
    # "should-emit" (= K=4 verdict would have been correct). Compute confusion
    # matrix and F1.
    tp = sum(int(test_correct_k4[i]) for i in emit_items)
    fp = len(emit_items) - tp
    fn = sum(int(test_correct_k4[i]) for i in escalate_items)
    tn = len(escalate_items) - fn
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0
    binary_metrics = {
        "tp": tp, "fp": fp, "tn": tn, "fn": fn,
        "precision": prec, "recall": rec, "f1": f1,
    }

    # === Option C: macro recall across classes for EMIT ===
    # Per-class recall on EMIT subset = per-class accuracy on EMIT subset
    # (since we condition on gold class).
    classes_present = [cls for cls in CLASSES if cls in emit_per_class]
    macro_recall_emit = (
        np.mean([emit_per_class[cls]["accuracy"] for cls in classes_present])
        if classes_present else float("nan")
    )

    # Macro recall per escalation source (would-have-been per-class recall)
    for src in ESCALATE_SOURCES:
        e = sources_summary[src]
        if e["n"] == 0:
            e["macro_recall"] = float("nan")
            continue
        cls_present_src = [cls for cls in CLASSES if cls in e["per_class"]]
        e["macro_recall"] = (
            float(np.mean([e["per_class"][cls]["accuracy"] for cls in cls_present_src]))
            if cls_present_src else float("nan")
        )

    return {
        "alpha_high": r["alpha_high"],
        "alpha_mod": r["alpha_mod"],
        "n_test": n_test,
        "emit": {
            "n": len(emit_items),
            "frac_of_test": len(emit_items) / n_test,
            "accuracy": (emit_correct / len(emit_items)
                         if emit_items else float("nan")),
            "macro_recall": macro_recall_emit,
            "per_class": emit_per_class,
            "items": emit_items,
        },
        "escalate_total": {
            "n": len(escalate_items),
            "frac_of_test": len(escalate_items) / n_test,
        },
        "binary_decision": binary_metrics,
        "by_source": sources_summary,
    }


# ====================================================================== #
# Output: tables
# ====================================================================== #

def write_headline(per_alpha: list[dict], out_dir: Path) -> None:
    md = [
        "# Headline trade-off across α sweep\n",
        "Two top-level decisions per item: EMIT (commit to K=4 verdict) "
        "or ESCALATE (route to human review). Beyond aggregate accuracy "
        "we report two complementary metrics:\n",
        "- **Binary-decision F1** treats the framework's emit-or-escalate "
        "choice as a binary classifier whose target is `should-emit` "
        "(K=4 verdict would have been correct). High F1 means the "
        "framework's emit decision aligns well with what would have "
        "been correct to emit.\n",
        "- **Macro recall on EMIT** averages per-class recall across the "
        "four AVeriTeC verdicts on the EMITted subset. Aggregate accuracy "
        "is dominated by the majority class (Refuted, 61% of test); "
        "macro recall exposes systematic class collapse — when it is "
        "much lower than aggregate accuracy, the framework is failing "
        "minority classes.\n",
        "",
        "| α_h | Cov | Acc EMIT | MacroRec EMIT | Esc% | Acc(esc) | Bin-F1 | Bin-Prec | Bin-Rec |",
        "|-----|-----|----------|---------------|------|----------|--------|----------|---------|",
    ]
    tex = [
        r"\begin{table*}[t]", r"\centering", r"\small",
        r"\caption{Headline emit-or-escalate trade-off across the $\alpha$ "
        r"sweep. `Cov' is the fraction of test items the framework emits "
        r"a verdict on; `Acc EMIT' is the empirical accuracy of those "
        r"verdicts; `MacroRec EMIT' is the macro-averaged per-class recall, "
        r"which exposes minority-class collapse hidden by aggregate accuracy; "
        r"`Acc(esc)' is the would-have-been K=4 accuracy on escalated items; "
        r"`Bin-F1', `Bin-Prec', `Bin-Rec' are the binary EMIT-vs-ESCALATE "
        r"classification metrics with `should-emit' as positive.}",
        r"\label{tab:headline}",
        r"\begin{tabular}{ccccccccc}", r"\toprule",
        r"$\alpha_h$ & Cov. & Acc.emit & MacroRec & Esc.\% & Acc.esc & F1 & Prec & Rec \\",
        r"\midrule",
    ]
    for a in per_alpha:
        all_esc = []
        for s in ESCALATE_SOURCES:
            all_esc.extend(a["by_source"][s]["items"])
        if all_esc:
            n_total = sum(a["by_source"][s]["n"] for s in ESCALATE_SOURCES)
            n_correct = sum(
                int(round(a["by_source"][s]["would_be_accuracy"] * a["by_source"][s]["n"]))
                for s in ESCALATE_SOURCES if a["by_source"][s]["n"] > 0
            )
            wb_esc = n_correct / n_total if n_total > 0 else float("nan")
        else:
            wb_esc = float("nan")
        b = a["binary_decision"]
        md.append(
            f"| {a['alpha_high']:.2f} | "
            f"{a['emit']['frac_of_test']:.0%} | "
            f"{a['emit']['accuracy']:.2f} | "
            f"{a['emit']['macro_recall']:.2f} | "
            f"{a['escalate_total']['frac_of_test']:.0%} | "
            f"{wb_esc:.2f} | "
            f"{b['f1']:.2f} | {b['precision']:.2f} | {b['recall']:.2f} |"
        )
        tex.append(
            f"{a['alpha_high']:.2f} & "
            f"{a['emit']['frac_of_test']:.2f} & "
            f"{a['emit']['accuracy']:.2f} & "
            f"{a['emit']['macro_recall']:.2f} & "
            f"{a['escalate_total']['frac_of_test']:.2f} & "
            f"{wb_esc:.2f} & "
            f"{b['f1']:.2f} & {b['precision']:.2f} & {b['recall']:.2f} \\\\"
        )
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
    (out_dir / "headline.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (out_dir / "headline.tex").write_text("\n".join(tex) + "\n", encoding="utf-8")


def write_attribution(per_alpha: list[dict], out_dir: Path) -> None:
    md = [
        "# Escalation source attribution across α sweep\n",
        "Each escalated item is attributed to one of four sources. "
        "Cells show: count (% of escalations).\n",
        "",
        "| α_h | Total esc | RETR | READER | VERIF | MULTI |",
        "|-----|-----------|------|--------|-------|-------|",
    ]
    tex = [
        r"\begin{table}[t]", r"\centering",
        r"\caption{Escalation source attribution. Each escalated item is "
        r"attributed to one of four sources based on which upstream module "
        r"signalled non-conformance. ESCALATE-VERIFIER fires when no "
        r"upstream module is in its tail but the verifier samples disagree; "
        r"ESCALATE-MULTIPLE fires when two or more upstream modules are "
        r"simultaneously in their tails. Cells: $n$ (\%~of escalations).}",
        r"\label{tab:attribution}",
        r"\begin{tabular}{cccccc}", r"\toprule",
        r"$\alpha_h$ & Total & RETR & READER & VERIF & MULTI \\",
        r"\midrule",
    ]
    for a in per_alpha:
        total = a["escalate_total"]["n"]
        cells_md = [f"{a['alpha_high']:.2f}", str(total)]
        cells_tex = [f"{a['alpha_high']:.2f}", str(total)]
        for s in ESCALATE_SOURCES:
            n = a["by_source"][s]["n"]
            if n == 0:
                cells_md.append("0")
                cells_tex.append("0")
            else:
                pct = 100 * a["by_source"][s]["frac_of_escalations"]
                cells_md.append(f"{n} ({pct:.0f}%)")
                cells_tex.append(f"{n} ({pct:.0f}\\%)")
        md.append("| " + " | ".join(cells_md) + " |")
        tex.append(" & ".join(cells_tex) + r" \\")
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (out_dir / "attribution.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (out_dir / "attribution.tex").write_text("\n".join(tex) + "\n", encoding="utf-8")


def write_attribution_validity(per_alpha: list[dict], out_dir: Path) -> None:
    md = [
        "# Attribution validity: would-have-been K=4 accuracy per source\n",
        "If the framework attributes correctly, items in each escalation "
        "source should be harder than the unconditional pipeline (K=4 = 0.67 "
        "on this test set). Sources well below 0.67 are well-targeted; "
        "sources at or above 0.67 are over-cautious — the diagnostic "
        "flagged items the verifier would have gotten right.\n",
        "",
        "| α_h | RETR (n; acc) | READER (n; acc) | VERIF (n; acc) | MULTI (n; acc) |",
        "|-----|----------------|------------------|------------------|------------------|",
    ]
    tex = [
        r"\begin{table}[t]", r"\centering",
        r"\caption{Attribution validity. For each escalation source, the "
        r"would-have-been K=4 modal-verdict accuracy on items in that "
        r"source, with the source's item count $n$ in parentheses. "
        r"Reference unconditional K=4 accuracy = 0.67. Sources with accuracy "
        r"substantially below 0.67 are correctly identifying hard items; "
        r"sources at or above 0.67 are over-cautious.}",
        r"\label{tab:attribution-validity}",
        r"\begin{tabular}{ccccc}", r"\toprule",
        r"$\alpha_h$ & RETR & READER & VERIF & MULTI \\",
        r"\midrule",
    ]
    for a in per_alpha:
        cells_md = [f"{a['alpha_high']:.2f}"]
        cells_tex = [f"{a['alpha_high']:.2f}"]
        for s in ESCALATE_SOURCES:
            e = a["by_source"][s]
            if e["n"] == 0:
                cells_md.append("—")
                cells_tex.append("---")
            else:
                cells_md.append(f"{e['n']}; {e['would_be_accuracy']:.2f}")
                cells_tex.append(f"{e['n']}: {e['would_be_accuracy']:.2f}")
        md.append("| " + " | ".join(cells_md) + " |")
        tex.append(" & ".join(cells_tex) + r" \\")
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (out_dir / "attribution_validity.md").write_text("\n".join(md) + "\n",
                                                       encoding="utf-8")
    (out_dir / "attribution_validity.tex").write_text("\n".join(tex) + "\n",
                                                        encoding="utf-8")


def write_per_class_per_decision(per_alpha: list[dict], out_dir: Path) -> None:
    md = [
        "# Per-class breakdown for EMIT and each ESCALATE source\n",
        "For each α and each decision (EMIT / ESCALATE-source), per-gold-"
        "class {n, correct, wrong, accuracy}. EMIT row uses actual K=4 "
        "verdict accuracy; ESCALATE rows use would-have-been K=4 accuracy.\n",
    ]
    for a in per_alpha:
        md.append(f"\n## α_high = {a['alpha_high']:.2f}\n")
        md.append("### EMIT")
        e = a["emit"]
        md.append(f"  n = {e['n']} ({e['frac_of_test']:.0%}), "
                  f"accuracy = {e['accuracy']:.3f}\n")
        md.append("| Class | n | correct | wrong | accuracy |")
        md.append("|-------|---|---------|-------|----------|")
        for cls in CLASSES:
            if cls not in e["per_class"]: continue
            p = e["per_class"][cls]
            md.append(
                f"| {cls} | {p['n']} | {p['correct']} | "
                f"{p['wrong']} | {p['accuracy']:.3f} |"
            )
        for src in ESCALATE_SOURCES:
            e = a["by_source"][src]
            if e["n"] == 0: continue
            md.append(f"\n### {src}")
            md.append(f"  n = {e['n']} ({e['frac_of_test']:.0%} of test, "
                      f"{e['frac_of_escalations']:.0%} of escalations), "
                      f"would-be accuracy = {e['would_be_accuracy']:.3f}\n")
            md.append("| Class | n | correct | wrong | accuracy |")
            md.append("|-------|---|---------|-------|----------|")
            for cls in CLASSES:
                if cls not in e["per_class"]: continue
                p = e["per_class"][cls]
                md.append(
                    f"| {cls} | {p['n']} | {p['correct']} | "
                    f"{p['wrong']} | {p['accuracy']:.3f} |"
                )
    (out_dir / "per_class_per_decision.md").write_text(
        "\n".join(md) + "\n", encoding="utf-8"
    )

    # LaTeX at the central alpha
    target = next((a for a in per_alpha if abs(a["alpha_high"] - 0.30) < 1e-6),
                  per_alpha[len(per_alpha) // 2])
    tex = [
        r"\begin{table}[t]", r"\centering", r"\small",
        r"\caption{Per-class breakdown at $\alpha_h=0.30$. EMIT row reports "
        r"actual K=4 verdict accuracy; ESCALATE-source rows report "
        r"would-have-been K=4 accuracy on suppressed items.}",
        r"\label{tab:per-class-per-decision}",
        r"\begin{tabular}{l l c c c c}", r"\toprule",
        r"Decision & Class & $n$ & correct & wrong & acc \\",
        r"\midrule",
    ]
    e = target["emit"]
    first = True
    for cls in CLASSES:
        if cls not in e["per_class"]: continue
        p = e["per_class"][cls]
        label = "EMIT" if first else ""
        tex.append(
            f"{label} & {SHORT_CLASS[cls]} & {p['n']} & {p['correct']} & "
            f"{p['wrong']} & {p['accuracy']:.2f} \\\\"
        )
        first = False
    tex.append(r"\midrule")
    for src in ESCALATE_SOURCES:
        e = target["by_source"][src]
        if e["n"] == 0: continue
        first = True
        for cls in CLASSES:
            if cls not in e["per_class"]: continue
            p = e["per_class"][cls]
            label = SHORT_SRC[src] if first else ""
            tex.append(
                f"{label} & {SHORT_CLASS[cls]} & {p['n']} & {p['correct']} & "
                f"{p['wrong']} & {p['accuracy']:.2f} \\\\"
            )
            first = False
        tex.append(r"\midrule")
    tex = tex[:-1]  # drop trailing midrule
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (out_dir / "per_class_per_decision.tex").write_text(
        "\n".join(tex) + "\n", encoding="utf-8"
    )


def write_multiple_signals(per_alpha: list[dict], test_items: list,
                            out_dir: Path) -> None:
    md = [
        "# Per-item signals for ESCALATE-MULTIPLE\n",
        "For every item attributed to ESCALATE-MULTIPLE, the per-module "
        "signals that triggered the escalation. Each row reports: item "
        "index, gold class, and the calibration-rank (or score) of each "
        "module, with a flag if the module was in its tail.\n",
        "",
        "Format: `[item_idx]` gold_class | M1: rank_or_score (in_tail) | "
        "M2: ... | M3: ... | M4: ...\n",
    ]
    for a in per_alpha:
        e = a["by_source"]["ESCALATE-MULTIPLE"]
        if e["n"] == 0:
            md.append(f"\n## α_h = {a['alpha_high']:.2f}\n_(no items)_\n")
            continue
        md.append(f"\n## α_h = {a['alpha_high']:.2f}  (n={e['n']})\n")
        for i, item_i in enumerate(e["items"]):
            sig = e["signals"][i]
            gold = test_items[item_i].verdict
            parts = [f"`[{item_i:>3}]` {gold}"]
            for mod_name in sorted(sig.keys()):
                s = sig[mod_name]
                if "rank" in s:
                    flag = "★" if s["in_tail"] else ""
                    parts.append(f"{mod_name.split('_')[0]}: r={s['rank']:.2f} {flag}")
                else:  # verifier — uses score
                    flag = "★" if s["in_tail"] else ""
                    parts.append(f"{mod_name.split('_')[0]}: s={s['score']:.2f} {flag}")
            md.append("- " + "  |  ".join(parts))
    (out_dir / "multiple_signals.md").write_text(
        "\n".join(md) + "\n", encoding="utf-8"
    )


def write_error_inventory(per_alpha: list[dict], test_items: list,
                          test_correct_k4: np.ndarray, out_dir: Path) -> None:
    md = [
        "# Error inventory: items the framework EMITted but got wrong\n",
        "For each α, the test items the framework chose to emit a verdict "
        "for, but the verdict was wrong (verifier modal != gold). Format: "
        "`[item_idx]` gold_class\n",
    ]
    for a in per_alpha:
        emit_items = a["emit"]["items"]
        wrong = [i for i in emit_items if test_correct_k4[i] == 0]
        md.append(f"\n## α_h = {a['alpha_high']:.2f}  ({len(wrong)} errors of {len(emit_items)})\n")
        if not wrong:
            md.append("_(no errors)_")
            continue
        # group by gold class
        for cls in CLASSES:
            cls_errs = [i for i in wrong if test_items[i].verdict == cls]
            if not cls_errs: continue
            md.append(f"\n**{cls}** ({len(cls_errs)})")
            for i in cls_errs:
                md.append(f"  - `[{i:>3}]`")
    (out_dir / "error_inventory.md").write_text(
        "\n".join(md) + "\n", encoding="utf-8"
    )


# ====================================================================== #
# Main
# ====================================================================== #

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results", type=Path)
    ap.add_argument("--data-dir", default="data", type=Path)
    ap.add_argument("--k4-dir", default="exp_C_K4")
    ap.add_argument("--cascading-summary", default=None)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--rank-thresh", type=float, default=0.70)
    ap.add_argument("--verifier-thresh", type=float, default=0.60)
    ap.add_argument("--n-cal", type=int, default=61)
    ap.add_argument("--n-test", type=int, default=61)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    out_dir = Path(args.out_dir or (args.results_dir / "simplified_diagnostic"))
    out_dir.mkdir(parents=True, exist_ok=True)

    cascading_path = Path(args.cascading_summary or (
        args.results_dir / "cascading_deferral" / "cascading_summary.json"
    ))
    if not cascading_path.exists():
        logger.error("cascading_summary.json not found at %s. Run "
                     "scripts/14_cascading_deferral.py first.", cascading_path)
        return 1

    cascading = json.loads(cascading_path.read_text())
    cal_items, test_items = load_dataset_split(
        args.data_dir, args.n_cal, args.n_test, args.seed
    )

    # K=4 data
    k4_dir = args.results_dir / args.k4_dir
    test_correct_k4 = np.load(k4_dir / "test_correct.npy").astype(int)
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules_k4 = list(cs_dict)
    cal_scores = np.column_stack([np.array(cs_dict[m]) for m in modules_k4])
    upstream_idx = [i for i, m in enumerate(modules_k4)
                    if "verifier" not in m.lower()]
    verifier_idx = next(i for i, m in enumerate(modules_k4)
                         if "verifier" in m.lower())
    test_ranks = per_module_calibration_ranks(test_scores, cal_scores, upstream_idx)

    logger.info("Test items: %d, K=4 acc=%.3f", len(test_items), test_correct_k4.mean())

    # Run per-alpha analysis
    per_alpha = [
        analyze_alpha(r, test_items, test_correct_k4, test_ranks,
                      test_scores, upstream_idx, modules_k4,
                      verifier_idx, args.rank_thresh, args.verifier_thresh)
        for r in cascading
    ]

    # Write all outputs
    write_headline(per_alpha, out_dir)
    write_attribution(per_alpha, out_dir)
    write_attribution_validity(per_alpha, out_dir)
    write_per_class_per_decision(per_alpha, out_dir)
    write_multiple_signals(per_alpha, test_items, out_dir)
    write_error_inventory(per_alpha, test_items, test_correct_k4, out_dir)

    # Full JSON (slim — no per-item signals to keep file small)
    full = []
    for a in per_alpha:
        slim = {
            "alpha_high": a["alpha_high"],
            "alpha_mod": a["alpha_mod"],
            "n_test": a["n_test"],
            "emit": {k: v for k, v in a["emit"].items() if k != "items"},
            "escalate_total": a["escalate_total"],
            "binary_decision": a["binary_decision"],
            "by_source": {
                s: {k: v for k, v in e.items() if k not in ("items", "signals")}
                for s, e in a["by_source"].items()
            },
        }
        full.append(slim)
    (out_dir / "diagnostic_full.json").write_text(
        json.dumps(full, indent=2), encoding="utf-8"
    )

    # Console summary
    logger.info("=== HEADLINE PER ALPHA ===")
    for a in per_alpha:
        logger.info("  α_h=%.2f  emit=%3.0f%% (acc=%.2f)  esc=%3.0f%%",
                    a["alpha_high"], 100 * a["emit"]["frac_of_test"],
                    a["emit"]["accuracy"],
                    100 * a["escalate_total"]["frac_of_test"])
    target = next((a for a in per_alpha if abs(a["alpha_high"] - 0.30) < 1e-6),
                  per_alpha[len(per_alpha) // 2])
    logger.info("=== ESCALATION ATTRIBUTION @ α_h=%.2f ===", target["alpha_high"])
    for s in ESCALATE_SOURCES:
        e = target["by_source"][s]
        if e["n"] > 0:
            logger.info("  %-22s n=%-3d  would-be acc=%.2f", s, e["n"], e["would_be_accuracy"])

    logger.info("Wrote %s", out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
