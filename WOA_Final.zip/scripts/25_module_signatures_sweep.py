#!/usr/bin/env python
"""
Per-module score distributions across the α sweep, with per-α headline
metrics (accuracy, macro-recall, F1) shown as a row label.

Visualises *what the framework is seeing* at every α level: for each
upstream module M1, M2, M3, and the verifier M4, the score distribution
on EMIT items vs ESCALATE items. Reveals how the "score signature" of
the framework's decision shifts as α changes.

Layout
------
  Rows = α values (5 rows for the AVeriTeC sweep)
  Columns = modules (M1 decomposer, M2 retriever, M3 reader, M4 verifier)
  Each cell = histogram of EMIT (green) vs ESCALATE (red) scores.

The left margin of each row carries the headline metrics for that α:
  α=0.30 | acc=0.79  rec=0.44  F1=0.80

Reads cascading_summary.json + diagnostic_full.json + test_scores.npy.
~5 seconds CPU.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("25_module_signatures_sweep")


COLORS = {
    "emit": "#3d8b3d",
    "escalate": "#c44f4f",
    "neutral": "#666666",
}

EMIT_KEYS = [
    "HIGH-CONFIDENCE",
    "MODERATE-CONFIDENCE",
    "ESCALATE-VERIFIER-CONFLICT",
    "ROUTE-TO-SKIP-DECOMPOSER",
    "ROUTE-TO-SKIP-READER",
    "RESIDUAL",
]
ESCALATE_KEYS = [
    "ESCALATE-RETRIEVAL-FAILURE",
    "ESCALATE-MULTIPLE-FAILURE",
]
SHORT_MODULE = {
    "M1_decomposer": "M1 Decomposer",
    "M2_retriever": "M2 Retriever",
    "M3_reader": "M3 Reader",
    "M4_verifier": "M4 Verifier",
}


def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "font.size": 8,
        "axes.titlesize": 9,
        "axes.labelsize": 8,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "legend.fontsize": 8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.5,
        "axes.edgecolor": "#444444",
        "axes.labelcolor": "#222222",
        "xtick.color": "#444444",
        "ytick.color": "#444444",
        "grid.linewidth": 0.4,
        "grid.color": "#dddddd",
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.06,
    })
    return plt


def emit_escalate_items(r: dict) -> tuple[list[int], list[int]]:
    cats = r["categories"]
    emit_items, esc_items = [], []
    for k in EMIT_KEYS:
        emit_items.extend(cats.get(k, {"items": []})["items"])
    for k in ESCALATE_KEYS:
        esc_items.extend(cats.get(k, {"items": []})["items"])
    return emit_items, esc_items


def make_figure(plt, cascading: list[dict], diagnostic: list[dict],
                test_scores: np.ndarray, modules: list[str],
                out_path: Path):
    n_alphas = len(cascading)
    n_modules = len(modules)

    # Compute global per-module bin edges so all rows share the same x-axis
    # for comparability across alphas
    bin_edges_per_module = []
    for k in range(n_modules):
        s = test_scores[:, k]
        # Use 11 edges → 10 bins, but if score is degenerate (M2/M4 often
        # have spikes at 0 and 1) add a small safety margin
        lo = float(s.min())
        hi = float(s.max())
        if hi - lo < 1e-6:
            hi = lo + 1.0
        bin_edges_per_module.append(np.linspace(lo, hi, 11))

    # Build diagnostic lookup keyed by alpha
    diag_by_alpha = {round(d["alpha_high"], 4): d for d in diagnostic}

    fig, axes = plt.subplots(
        n_alphas, n_modules,
        figsize=(2.2 * n_modules + 1.5, 1.6 * n_alphas + 0.5),
        sharex="col",
    )

    # Compute per-column max y for shared y-scale within each module column
    # (independent across modules because their counts differ)
    col_y_max = [0] * n_modules
    counts_cache = {}  # (alpha_idx, module_idx) → (counts_emit, counts_esc)
    for ai, r in enumerate(cascading):
        emit_idx, esc_idx = emit_escalate_items(r)
        for mi in range(n_modules):
            edges = bin_edges_per_module[mi]
            cE, _ = np.histogram(test_scores[emit_idx, mi], bins=edges)
            cS, _ = np.histogram(test_scores[esc_idx, mi], bins=edges)
            counts_cache[(ai, mi)] = (cE, cS)
            local_max = max(cE.max() if len(cE) else 0,
                            cS.max() if len(cS) else 0)
            col_y_max[mi] = max(col_y_max[mi], int(local_max))

    for ai, r in enumerate(cascading):
        a = r["alpha_high"]
        diag = diag_by_alpha.get(round(a, 4), {})
        # Headline metrics for this alpha
        if diag:
            acc = diag["emit"]["accuracy"]
            rec = diag["emit"]["macro_recall"]
            f1 = diag["binary_decision"]["f1"]
            metrics_label = (rf"$\alpha_h={a:.2f}$" "\n"
                             f"acc={acc:.2f}\n"
                             f"rec={rec:.2f}\n"
                             f"F1={f1:.2f}")
        else:
            metrics_label = rf"$\alpha_h={a:.2f}$"

        for mi, mod_name in enumerate(modules):
            ax = axes[ai, mi] if n_alphas > 1 else axes[mi]
            cE, cS = counts_cache[(ai, mi)]
            edges = bin_edges_per_module[mi]
            centers = 0.5 * (edges[:-1] + edges[1:])
            width = (edges[1] - edges[0]) * 0.45
            ax.bar(centers - width/2, cE, width=width,
                   color=COLORS["emit"], edgecolor="#333333",
                   linewidth=0.4, alpha=0.85, zorder=3)
            ax.bar(centers + width/2, cS, width=width,
                   color=COLORS["escalate"], edgecolor="#333333",
                   linewidth=0.4, alpha=0.85, zorder=3)
            ax.set_ylim(0, col_y_max[mi] * 1.15 + 1)
            ax.tick_params(axis="both", labelsize=7)
            ax.grid(True, axis="y", alpha=0.3, zorder=1)
            # Top row: column titles
            if ai == 0:
                ax.set_title(SHORT_MODULE.get(mod_name, mod_name),
                             fontsize=9, pad=4, fontweight="bold")
            # Bottom row: x-axis label
            if ai == n_alphas - 1:
                ax.set_xlabel("Score", fontsize=8)
            # Leftmost column: per-row metrics annotation
            if mi == 0:
                ax.text(-0.55, 0.5, metrics_label,
                        transform=ax.transAxes,
                        ha="right", va="center", fontsize=8,
                        fontweight="normal",
                        bbox=dict(boxstyle="round,pad=0.4",
                                  facecolor="#f5f5f5",
                                  edgecolor="#cccccc", linewidth=0.5))
                ax.set_ylabel("Count", fontsize=8)

    # Single legend at top
    legend_handles = [
        plt.Rectangle((0, 0), 1, 1, color=COLORS["emit"], alpha=0.85,
                      label="EMIT"),
        plt.Rectangle((0, 0), 1, 1, color=COLORS["escalate"], alpha=0.85,
                      label="ESCALATE"),
    ]
    fig.legend(handles=legend_handles, loc="upper center",
               bbox_to_anchor=(0.5, 1.005), ncol=2,
               frameon=True, fontsize=9,
               fancybox=False, edgecolor="#cccccc")

    fig.suptitle(
        "Per-module score distributions across the α sweep "
        "(EMIT vs ESCALATE)",
        fontsize=11, y=1.04
    )

    fig.subplots_adjust(left=0.13, top=0.93, hspace=0.4, wspace=0.25)
    fig.savefig(out_path)
    plt.close(fig)
    logger.info("Wrote %s", out_path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results", type=Path)
    ap.add_argument("--k4-dir", default="exp_C_K4")
    ap.add_argument("--cascading-summary", default=None)
    ap.add_argument("--diagnostic-json", default=None)
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    out_dir = Path(args.out_dir or (args.results_dir / "paper_figures"))
    out_dir.mkdir(parents=True, exist_ok=True)

    cas_path = Path(args.cascading_summary or (
        args.results_dir / "cascading_deferral" / "cascading_summary.json"
    ))
    diag_path = Path(args.diagnostic_json or (
        args.results_dir / "simplified_diagnostic" / "diagnostic_full.json"
    ))
    if not cas_path.exists():
        logger.error("cascading_summary.json not found: %s", cas_path)
        return 1
    if not diag_path.exists():
        logger.error("diagnostic_full.json not found: %s", diag_path)
        return 1

    plt = setup_matplotlib()
    cascading = json.loads(cas_path.read_text())
    diagnostic = json.loads(diag_path.read_text())

    k4_dir = args.results_dir / args.k4_dir
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules = list(cs_dict)

    out_pdf = out_dir / "fig_module_signatures_sweep.pdf"
    make_figure(plt, cascading, diagnostic, test_scores, modules, out_pdf)
    return 0


if __name__ == "__main__":
    sys.exit(main())
