#!/usr/bin/env python
"""
Score-stratum Mondrian conformal diagnostic.

Tests whether stratifying calibration items by the verifier's saturation
state — and then calibrating separate within-stratum thresholds on the
reader (M3) score — recovers minority-class items the marginal-tail
diagnostics miss.

Method
------
1. Stratify items by M4 (verifier) score:
     Stratum A: M4 ≥ 1.0      (saturated; verifier samples agree fully)
     Stratum B: M4 < 1.0      (unsaturated; verifier disagreement present)
2. Within each stratum, calibrate a conformal threshold on M3 (reader)
   score with bootstrap CIs (1000 resamples). The (1−α) quantile of M3
   in stratum S defines the within-stratum tail threshold.
3. Apply per-stratum thresholds to test items, defining a new attribution
   source ESCALATE-MONDRIAN-M3 for items whose M3 score falls in the
   stratum tail and that are not already escalated by marginal scores.
4. Report the per-class effect: does the new diagnostic catch the
   minority-class items the marginal diagnostic misses?

Why this might work
-------------------
On AVeriTeC, the verifier saturation (53/61 cal items have M4=1.0)
prevents marginal M4 calibration from differentiating items within the
saturated stratum. But within Stratum A, the reader (M3) score *does*
show class-conditional structure — calibration reveals that NEE items
have systematically lower M3 scores than Supported/Refuted/Conflicting
(NEE median 0.043 vs majority medians 0.097–0.099). Mondrian
calibration on M3 *within Stratum A* exploits this signal.

Outputs (results/mondrian_m3/)
------------------------------
  mondrian_summary.{tex,md,json}        Per-stratum thresholds + bootstrap CI
  mondrian_per_class_breakdown.{tex,md} Effect on per-class breakdown
  fig_mondrian_strata.pdf               M3 distribution per stratum × class
  fig_mondrian_reliability.pdf          Reliability ordering with new category
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("27_mondrian_m3_diagnostic")


CLASSES = ["Supported", "Refuted",
           "Not Enough Evidence", "Conflicting Evidence/Cherrypicking"]
SHORT_CLASS = {
    "Supported": "SUP", "Refuted": "REF",
    "Not Enough Evidence": "NEE",
    "Conflicting Evidence/Cherrypicking": "CONF",
}
EMIT_KEYS = [
    "HIGH-CONFIDENCE", "MODERATE-CONFIDENCE",
    "ESCALATE-VERIFIER-CONFLICT",
    "ROUTE-TO-SKIP-DECOMPOSER",
    "ROUTE-TO-SKIP-READER", "RESIDUAL",
]
ESCALATE_KEYS = [
    "ESCALATE-RETRIEVAL-FAILURE", "ESCALATE-MULTIPLE-FAILURE",
]

COLORS = {
    "primary": "#1f5582", "secondary": "#c44f4f",
    "tertiary": "#3d8b3d", "highlight": "#e8a13a",
    "accent": "#7d4ba0", "neutral": "#7a7a7a",
}
CLASS_COLORS = {
    "Supported": "#3d8b3d",
    "Refuted": "#1f5582",
    "Not Enough Evidence": "#e8a13a",
    "Conflicting Evidence/Cherrypicking": "#c44f4f",
}

M3_IDX = 2  # Reader column in test_scores
M4_IDX = 3  # Verifier column

STRATUM_SAT = "A_saturated"
STRATUM_UNSAT = "B_unsaturated"


def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": 0.6,
        "axes.edgecolor": "#444444", "axes.labelcolor": "#222222",
        "xtick.color": "#444444", "ytick.color": "#444444",
        "grid.linewidth": 0.4, "grid.color": "#dddddd",
        "savefig.dpi": 300, "savefig.bbox": "tight",
        "savefig.pad_inches": 0.05,
    })
    return plt


def stratum_of(m4_value: float) -> str:
    return STRATUM_SAT if m4_value >= 1.0 else STRATUM_UNSAT


# ====================================================================== #
# Bootstrap-calibrated within-stratum threshold
# ====================================================================== #

def bootstrap_within_stratum_threshold(
    m3_in_stratum: np.ndarray,
    alpha: float,
    n_boot: int = 1000,
    seed: int = 42,
) -> dict:
    """Within a stratum, compute (1−α) quantile of M3 scores with bootstrap CI.
    Items with M3 above this threshold are flagged as in the within-stratum
    tail (high reader uncertainty given the stratum context)."""
    n = len(m3_in_stratum)
    if n < 2:
        # Not enough data; return NaNs
        return {
            "alpha": alpha, "n": n, "tau_point": float("nan"),
            "tau_ci90_low": float("nan"), "tau_ci90_high": float("nan"),
            "tau_ci50_low": float("nan"), "tau_ci50_high": float("nan"),
        }
    point = float(np.quantile(m3_in_stratum, 1 - alpha))
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        idx = rng.choice(n, size=n, replace=True)
        boots.append(np.quantile(m3_in_stratum[idx], 1 - alpha))
    boots = np.array(boots)
    return {
        "alpha": alpha, "n": n,
        "tau_point": point,
        "tau_ci90_low": float(np.quantile(boots, 0.05)),
        "tau_ci90_high": float(np.quantile(boots, 0.95)),
        "tau_ci50_low": float(np.quantile(boots, 0.25)),
        "tau_ci50_high": float(np.quantile(boots, 0.75)),
        "n_boot": n_boot,
    }


# ====================================================================== #
# Per-alpha analysis
# ====================================================================== #

def collect_emit_escalate(r: dict) -> tuple[list[int], list[int]]:
    cats = r["categories"]
    emit, esc = [], []
    for k in EMIT_KEYS: emit.extend(cats.get(k, {"items": []})["items"])
    for k in ESCALATE_KEYS: esc.extend(cats.get(k, {"items": []})["items"])
    return emit, esc


def analyze_alpha(
    r: dict,
    cal_items: list, test_items: list,
    test_correct_k4: np.ndarray,
    cal_scores: np.ndarray, test_scores: np.ndarray,
    n_boot: int,
) -> dict:
    a = r["alpha_high"]
    n_test = r["n_test"]

    # Cal strata
    m4_cal = cal_scores[:, M4_IDX]
    m4_test = test_scores[:, M4_IDX]
    cal_strata = np.array([stratum_of(v) for v in m4_cal])
    test_strata = np.array([stratum_of(v) for v in m4_test])

    # Within-stratum thresholds on M3
    thresholds = {}
    for s in [STRATUM_SAT, STRATUM_UNSAT]:
        in_s = np.where(cal_strata == s)[0]
        m3_in_s = cal_scores[in_s, M3_IDX]
        thresholds[s] = bootstrap_within_stratum_threshold(
            m3_in_s, a, n_boot=n_boot
        )

    # Apply per-stratum thresholds to test items
    # An item is in the "Mondrian-M3-tail" if M3 > stratum's threshold
    in_mondrian_tail = np.zeros(n_test, dtype=bool)
    for i in range(n_test):
        s = test_strata[i]
        tau = thresholds[s]["tau_point"]
        if not np.isnan(tau) and test_scores[i, M3_IDX] > tau:
            in_mondrian_tail[i] = True

    emit_items, esc_items = collect_emit_escalate(r)

    # Mondrian flags applied: items in EMIT that ALSO fall in mondrian tail
    # are diverted to ESCALATE-MONDRIAN-M3
    mondrian_from_emit = [i for i in emit_items if in_mondrian_tail[i]]
    emit_after = [i for i in emit_items if not in_mondrian_tail[i]]

    # Per-class summaries
    def per_class(items):
        out = {}
        for cls in CLASSES:
            cls_items = [i for i in items if test_items[i].verdict == cls]
            if not cls_items: continue
            n = len(cls_items)
            correct = int(test_correct_k4[cls_items].sum())
            out[cls] = {"n": n, "correct": correct, "wrong": n - correct,
                        "accuracy": correct / n}
        return out

    # Per-stratum item counts
    def stratum_breakdown(items):
        return {
            s: int(sum(1 for i in items if test_strata[i] == s))
            for s in [STRATUM_SAT, STRATUM_UNSAT]
        }

    return {
        "alpha_high": a,
        "n_test": n_test,
        "thresholds": thresholds,
        "stratum_sizes_cal": {
            STRATUM_SAT: int((cal_strata == STRATUM_SAT).sum()),
            STRATUM_UNSAT: int((cal_strata == STRATUM_UNSAT).sum()),
        },
        "stratum_sizes_test": {
            STRATUM_SAT: int((test_strata == STRATUM_SAT).sum()),
            STRATUM_UNSAT: int((test_strata == STRATUM_UNSAT).sum()),
        },
        "emit_baseline": {
            "n": len(emit_items),
            "accuracy": (float(test_correct_k4[emit_items].mean())
                         if emit_items else float("nan")),
            "per_class": per_class(emit_items),
            "stratum_mix": stratum_breakdown(emit_items),
        },
        "emit_after_mondrian": {
            "n": len(emit_after),
            "accuracy": (float(test_correct_k4[emit_after].mean())
                         if emit_after else float("nan")),
            "per_class": per_class(emit_after),
            "stratum_mix": stratum_breakdown(emit_after),
        },
        "mondrian_from_emit": {
            "n": len(mondrian_from_emit),
            "would_be_accuracy": (float(test_correct_k4[mondrian_from_emit].mean())
                                  if mondrian_from_emit else float("nan")),
            "per_class": per_class(mondrian_from_emit),
            "stratum_mix": stratum_breakdown(mondrian_from_emit),
            "items": mondrian_from_emit,
        },
        "n_marginal_escalate": len(esc_items),
    }


# ====================================================================== #
# Tables
# ====================================================================== #

def write_summary(per_alpha: list[dict], out_dir: Path) -> None:
    md = [
        "# Score-stratum Mondrian conformal — summary\n",
        "Stratify calibration by verifier saturation: Stratum A "
        "(M4 ≥ 1.0, the saturated case) and Stratum B (M4 < 1.0, "
        "the unsaturated case). Within each stratum, calibrate a "
        "conformal threshold on M3 (reader) score at level α with "
        "bootstrap 90% CI (1000 resamples). The new ESCALATE-MONDRIAN-M3 "
        "category catches EMIT items whose M3 score exceeds the "
        "within-stratum threshold.\n",
        "",
        f"Stratum sizes: A={per_alpha[0]['stratum_sizes_cal'][STRATUM_SAT]} cal, "
        f"B={per_alpha[0]['stratum_sizes_cal'][STRATUM_UNSAT]} cal.\n",
        "| α | τ_A point | τ_A 90% CI | τ_B point | τ_B 90% CI | EMIT base (n; acc) | EMIT after (n; acc) | Mondrian-flag (n; would-be) |",
        "|---|-----------|------------|-----------|------------|--------------------|---------------------|------------------------------|",
    ]
    tex = [
        r"\begin{table*}[t]", r"\centering", r"\small",
        r"\caption{Score-stratum Mondrian conformal diagnostic. "
        r"$\tau_A$ and $\tau_B$ are the bootstrap-calibrated thresholds "
        r"on M3 (reader) within Stratum A (verifier saturated) and "
        r"Stratum B (verifier unsaturated) respectively. EMIT after = "
        r"baseline minus items diverted to the new ESCALATE-MONDRIAN-M3 "
        r"category.}",
        r"\label{tab:mondrian-summary}",
        r"\begin{tabular}{ccccccc}", r"\toprule",
        r"$\alpha$ & $\tau_A$ (CI) & $\tau_B$ (CI) & EMIT base & EMIT after & Mondrian-flag \\",
        r"\midrule",
    ]
    for a in per_alpha:
        tA = a["thresholds"][STRATUM_SAT]
        tB = a["thresholds"][STRATUM_UNSAT]
        e0, e1, m = a["emit_baseline"], a["emit_after_mondrian"], a["mondrian_from_emit"]
        md.append(
            f"| {a['alpha_high']:.2f} | "
            f"{tA['tau_point']:.3f} | [{tA['tau_ci90_low']:.3f}, {tA['tau_ci90_high']:.3f}] | "
            f"{tB['tau_point']:.3f} | [{tB['tau_ci90_low']:.3f}, {tB['tau_ci90_high']:.3f}] | "
            f"{e0['n']}; {e0['accuracy']:.3f} | "
            f"{e1['n']}; {e1['accuracy']:.3f} | "
            f"{m['n']}; {m['would_be_accuracy']:.3f} |"
        )
        tex.append(
            f"{a['alpha_high']:.2f} & "
            f"{tA['tau_point']:.3f} [{tA['tau_ci90_low']:.3f}, {tA['tau_ci90_high']:.3f}] & "
            f"{tB['tau_point']:.3f} [{tB['tau_ci90_low']:.3f}, {tB['tau_ci90_high']:.3f}] & "
            f"{e0['n']}; {e0['accuracy']:.2f} & "
            f"{e1['n']}; {e1['accuracy']:.2f} & "
            f"{m['n']}; {m['would_be_accuracy']:.2f} \\\\"
        )
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
    (out_dir / "mondrian_summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (out_dir / "mondrian_summary.tex").write_text("\n".join(tex) + "\n", encoding="utf-8")


def write_per_class(per_alpha: list[dict], out_dir: Path) -> None:
    md = [
        "# Per-class effect of Mondrian-M3 filter\n",
        "For each α, per-class breakdown showing whether the within-"
        "stratum M3 filter catches the minority-class EMIT errors. "
        "Each row reports: items in EMIT baseline, items still in EMIT "
        "after Mondrian filter, items diverted to ESCALATE-MONDRIAN-M3.\n",
    ]
    for a in per_alpha:
        md.append(f"\n## α = {a['alpha_high']:.2f}\n")
        e0 = a["emit_baseline"]["per_class"]
        e1 = a["emit_after_mondrian"]["per_class"]
        m = a["mondrian_from_emit"]["per_class"]
        md.append("| Class | EMIT base (correct/n) | EMIT after (correct/n) | Mondrian-flag (correct/n) |")
        md.append("|-------|------------------------|-------------------------|----------------------------|")
        for cls in CLASSES:
            r0 = e0.get(cls)
            r1 = e1.get(cls)
            rm = m.get(cls)
            if not (r0 or r1 or rm): continue
            c0 = f"{r0['correct']}/{r0['n']}" if r0 else "—"
            c1 = f"{r1['correct']}/{r1['n']}" if r1 else "—"
            cm = f"{rm['correct']}/{rm['n']}" if rm else "—"
            md.append(f"| {cls} | {c0} | {c1} | {cm} |")
    (out_dir / "mondrian_per_class_breakdown.md").write_text(
        "\n".join(md) + "\n", encoding="utf-8"
    )

    # LaTeX at central α
    target = next((a for a in per_alpha if abs(a["alpha_high"] - 0.30) < 1e-6),
                  per_alpha[len(per_alpha)//2])
    tex = [
        r"\begin{table}[t]", r"\centering", r"\small",
        r"\caption{Per-class effect of Mondrian-M3 filter at $\alpha=0.30$.}",
        r"\label{tab:mondrian-per-class}",
        r"\begin{tabular}{l c c c}", r"\toprule",
        r"Class & EMIT base & EMIT after & Mondrian-flag \\",
        r"\midrule",
    ]
    e0 = target["emit_baseline"]["per_class"]
    e1 = target["emit_after_mondrian"]["per_class"]
    m = target["mondrian_from_emit"]["per_class"]
    for cls in CLASSES:
        r0 = e0.get(cls); r1 = e1.get(cls); rm = m.get(cls)
        if not (r0 or r1 or rm): continue
        c0 = f"{r0['correct']}/{r0['n']}" if r0 else "---"
        c1 = f"{r1['correct']}/{r1['n']}" if r1 else "---"
        cm = f"{rm['correct']}/{rm['n']}" if rm else "---"
        tex.append(f"{SHORT_CLASS[cls]} & {c0} & {c1} & {cm} \\\\")
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (out_dir / "mondrian_per_class_breakdown.tex").write_text(
        "\n".join(tex) + "\n", encoding="utf-8"
    )


# ====================================================================== #
# Figure A — M3 distribution within stratum A by gold class, with τ band
# ====================================================================== #

def fig_a_strata(plt, cal_items: list, cal_scores: np.ndarray,
                  target_alpha: float, target: dict, out_path: Path):
    m4_cal = cal_scores[:, M4_IDX]
    cal_strata = np.array([stratum_of(v) for v in m4_cal])

    fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.2),
                               gridspec_kw={"width_ratios": [4, 1]},
                               sharey=False)
    ax_main, ax_b = axes

    # === Main panel: M3 by gold class within Stratum A ===
    in_A = np.where(cal_strata == STRATUM_SAT)[0]
    m3_A = cal_scores[in_A, M3_IDX]
    items_A = [cal_items[i] for i in in_A]

    # KDE per class within A
    from scipy.stats import gaussian_kde
    x_max = m3_A.max() * 1.1
    x_grid = np.linspace(0, x_max, 200)

    for cls in CLASSES:
        idx = [i for i, item in enumerate(items_A) if item.verdict == cls]
        if len(idx) < 2:
            # Rug only
            scores = m3_A[idx] if idx else np.array([])
            if len(scores) > 0:
                ax_main.plot(scores, np.full_like(scores, -0.4),
                              "|", color=CLASS_COLORS[cls], markersize=12,
                              markeredgewidth=1.6, alpha=0.85,
                              label=f"{SHORT_CLASS[cls]} (n={len(idx)})")
            continue
        scores = m3_A[idx]
        try:
            kde = gaussian_kde(scores, bw_method=0.4)
            density = kde(x_grid)
            ax_main.fill_between(x_grid, density, alpha=0.30,
                                  color=CLASS_COLORS[cls], zorder=2,
                                  label=f"{SHORT_CLASS[cls]} (n={len(idx)})")
            ax_main.plot(x_grid, density, color=CLASS_COLORS[cls],
                         linewidth=1.4, zorder=3)
        except Exception:
            pass
        # Rug
        ax_main.plot(scores, np.full_like(scores, -0.4),
                      "|", color=CLASS_COLORS[cls], markersize=10,
                      markeredgewidth=1.3, alpha=0.7)

    # Threshold band on stratum A
    tA = target["thresholds"][STRATUM_SAT]
    ax_main.axvspan(tA["tau_ci90_low"], tA["tau_ci90_high"],
                     alpha=0.18, color=COLORS["neutral"], zorder=1,
                     label=rf"$\tau_A$ 90% CI")
    ax_main.axvline(tA["tau_point"], color=COLORS["neutral"],
                     linestyle="--", linewidth=1.2, zorder=4)
    ax_main.text(tA["tau_point"], ax_main.get_ylim()[1] * 0.92,
                  rf"$\tau_A={tA['tau_point']:.3f}$",
                  ha="left", va="top", fontsize=8,
                  color=COLORS["neutral"])

    ax_main.set_xlabel("M3 (reader) nonconformity score")
    ax_main.set_ylabel("Density")
    ax_main.set_xlim(0, x_max)
    ax_main.grid(True, axis="y", alpha=0.4, zorder=0)
    ax_main.legend(loc="upper right", frameon=True, fontsize=7,
                    fancybox=False, edgecolor="#cccccc")
    n_A_cal = target["stratum_sizes_cal"][STRATUM_SAT]
    ax_main.set_title(rf"Stratum A (M4=1.0, n={n_A_cal} cal): "
                       rf"M3 by gold class with $\tau_A$",
                       pad=8)

    # === Side panel: Stratum B summary ===
    in_B = np.where(cal_strata == STRATUM_UNSAT)[0]
    m3_B = cal_scores[in_B, M3_IDX]
    items_B = [cal_items[i] for i in in_B]
    n_B = len(in_B)

    tB = target["thresholds"][STRATUM_UNSAT]
    # Plot points colored by class
    for cls in CLASSES:
        idx = [i for i, item in enumerate(items_B) if item.verdict == cls]
        if not idx: continue
        scores = m3_B[idx]
        ax_b.scatter([0.5] * len(scores), scores,
                      color=CLASS_COLORS[cls],
                      s=40, alpha=0.8, edgecolor="#333", linewidth=0.5,
                      zorder=3)
    if not np.isnan(tB["tau_point"]):
        ax_b.axhspan(tB["tau_ci90_low"], tB["tau_ci90_high"],
                       alpha=0.18, color=COLORS["neutral"], zorder=1)
        ax_b.axhline(tB["tau_point"], color=COLORS["neutral"],
                       linestyle="--", linewidth=1.2, zorder=2)

    ax_b.set_xlim(0, 1)
    ax_b.set_xticks([])
    ax_b.set_ylim(0, x_max)
    ax_b.set_ylabel("M3 score", fontsize=8)
    ax_b.set_title(f"Stratum B\n(M4<1.0, n={n_B})", fontsize=9, pad=8)
    ax_b.grid(True, axis="y", alpha=0.4, zorder=0)

    fig.suptitle(rf"Score-stratum Mondrian: M3 distribution by stratum and class "
                 rf"($\alpha={target_alpha:.2f}$)",
                 fontsize=10, y=1.02)

    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    logger.info("Wrote %s", out_path)


# ====================================================================== #
# Figure B — Reliability ordering with Mondrian category
# ====================================================================== #

def fig_b_reliability(plt, target: dict, out_path: Path):
    n_test = target["n_test"]
    rows = []
    e_after = target["emit_after_mondrian"]
    rows.append(("EMIT", e_after["n"],
                 e_after["accuracy"], COLORS["tertiary"]))
    m = target["mondrian_from_emit"]
    if m["n"] > 0:
        rows.append(("ESC-MONDRIAN", m["n"],
                     m["would_be_accuracy"], COLORS["accent"]))
    rows.append(("ESC-MARGINAL", target["n_marginal_escalate"],
                 None, COLORS["secondary"]))

    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    n_bars = len(rows)
    centers = np.linspace(0.15, 0.85, n_bars)
    width = 0.18

    for (label, n, acc, color), c in zip(rows, centers):
        if acc is None:
            ax.bar(c, 0, width=width, color=color, alpha=0.3,
                   edgecolor="#333", linewidth=0.7, zorder=3)
            ax.text(c, 0.04, "(see\nmarginal\ndiagnostic)",
                    ha="center", va="bottom", fontsize=7,
                    color="#666", style="italic")
        else:
            ax.bar(c, acc, width=width, color=color,
                   edgecolor="#333", linewidth=0.7, zorder=3)
            ax.text(c, acc + 0.025, f"n={n}\nacc={acc:.2f}",
                    ha="center", va="bottom", fontsize=8.5,
                    fontweight="bold")
        share = 100 * n / n_test
        ax.text(c, -0.06, label, ha="center", va="top",
                fontsize=8.5, fontweight="bold",
                transform=ax.get_xaxis_transform())
        ax.text(c, -0.16, f"({share:.0f}% of test)",
                ha="center", va="top", fontsize=7,
                color="#555", style="italic",
                transform=ax.get_xaxis_transform())

    ax.axhline(y=0.672, color=COLORS["neutral"], linestyle="--",
               linewidth=0.8, alpha=0.7, zorder=2)
    ax.text(0.98, 0.692, "K=4 unconditional (0.67)",
            ha="right", va="bottom", fontsize=7.5, color=COLORS["neutral"])

    ax.set_xlim(0, 1.0)
    ax.set_xticks([])
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Accuracy on test (would-be for ESCALATE)")
    ax.grid(True, axis="y", alpha=0.4, zorder=1)
    ax.set_title(rf"Reliability ordering with Mondrian-M3 category "
                 rf"($\alpha_h={target['alpha_high']:.2f}$)", pad=10)

    fig.subplots_adjust(bottom=0.24)
    fig.savefig(out_path)
    plt.close(fig)
    logger.info("Wrote %s", out_path)


# ====================================================================== #
# Helpers + main
# ====================================================================== #

def load_dataset_split(data_dir: Path, n_cal: int, n_test: int, seed: int):
    sys.path.insert(0, "src")
    from conformal_agentic_rag.dataset import load_dataset, split_dataset
    ds = load_dataset(data_dir / "dataset.json")
    return split_dataset(ds, n_cal=n_cal, n_test=n_test, random_state=seed)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results", type=Path)
    ap.add_argument("--data-dir", default="data", type=Path)
    ap.add_argument("--k4-dir", default="exp_C_K4")
    ap.add_argument("--cascading-summary", default=None)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--target-alpha", type=float, default=0.30)
    ap.add_argument("--n-boot", type=int, default=1000)
    ap.add_argument("--n-cal", type=int, default=61)
    ap.add_argument("--n-test", type=int, default=61)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    out_dir = Path(args.out_dir or (args.results_dir / "mondrian_m3"))
    out_dir.mkdir(parents=True, exist_ok=True)

    cas_path = Path(args.cascading_summary or (
        args.results_dir / "cascading_deferral" / "cascading_summary.json"
    ))
    if not cas_path.exists():
        logger.error("cascading_summary.json not found at %s", cas_path)
        return 1

    plt = setup_matplotlib()
    cascading = json.loads(cas_path.read_text())
    cal_items, test_items = load_dataset_split(
        args.data_dir, args.n_cal, args.n_test, args.seed
    )

    k4_dir = args.results_dir / args.k4_dir
    test_correct_k4 = np.load(k4_dir / "test_correct.npy").astype(int)
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules = list(cs_dict)
    cal_scores = np.column_stack([np.array(cs_dict[m]) for m in modules])

    per_alpha = [
        analyze_alpha(r, cal_items, test_items, test_correct_k4,
                      cal_scores, test_scores, args.n_boot)
        for r in cascading
    ]

    write_summary(per_alpha, out_dir)
    write_per_class(per_alpha, out_dir)

    json_out = []
    for a in per_alpha:
        slim = {k: v for k, v in a.items() if k != "mondrian_from_emit"}
        slim["mondrian_from_emit"] = {
            k: v for k, v in a["mondrian_from_emit"].items() if k != "items"
        }
        slim["mondrian_from_emit"]["item_indices"] = a["mondrian_from_emit"]["items"]
        json_out.append(slim)
    (out_dir / "mondrian_summary.json").write_text(
        json.dumps(json_out, indent=2), encoding="utf-8"
    )

    # Figures at target alpha
    target = min(per_alpha, key=lambda a: abs(a["alpha_high"] - args.target_alpha))
    fig_a_strata(plt, cal_items, cal_scores, target["alpha_high"], target,
                  out_dir / "fig_mondrian_strata.pdf")
    fig_b_reliability(plt, target,
                       out_dir / "fig_mondrian_reliability.pdf")

    # Console summary
    logger.info("=== MONDRIAN-M3 DIAGNOSTIC ===")
    for a in per_alpha:
        tA = a["thresholds"][STRATUM_SAT]
        e0 = a["emit_baseline"]; e1 = a["emit_after_mondrian"]
        m = a["mondrian_from_emit"]
        logger.info(
            "  α=%.2f  τ_A=%.3f [%.3f,%.3f]  EMIT %d (%.2f) → after %d (%.2f)  Mondrian-flag %d (would-be %.2f)",
            a["alpha_high"], tA["tau_point"], tA["tau_ci90_low"], tA["tau_ci90_high"],
            e0["n"], e0["accuracy"], e1["n"], e1["accuracy"],
            m["n"], m["would_be_accuracy"]
        )
    logger.info("=== MONDRIAN-FLAG PER-CLASS @ α=%.2f ===", target["alpha_high"])
    m_per_class = target["mondrian_from_emit"]["per_class"]
    for cls in CLASSES:
        if cls in m_per_class:
            p = m_per_class[cls]
            logger.info("  %-50s n=%d correct=%d/%d",
                        cls, p["n"], p["correct"], p["n"])
    logger.info("Wrote outputs to %s", out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
