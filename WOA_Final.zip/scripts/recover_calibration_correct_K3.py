#!/usr/bin/env python
"""
Recover calibration_correct.npy for K=3 (exp_B) by re-running ONLY the
verifier on the 61 calibration items, with the K=3 pipeline configuration
(M1 + M2 + M4, no reader).

Wall-clock cost: ~1.5 hours on RTX 4070 Laptop.

Usage:
    python scripts/recover_calibration_correct_K3.py --config configs/default.yaml
"""
from __future__ import annotations
import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import yaml
from tqdm import tqdm

from conformal_agentic_rag.corpus import load_corpus
from conformal_agentic_rag.dataset import load_dataset, split_dataset
from conformal_agentic_rag.modules import (
    Verifier, PipelineState, ModuleOutput,
    averitec_label_to_verifier, VERIFIER_LABELS,
)
from conformal_agentic_rag.ollama_client import OllamaClient

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("recover_calibration_correct_K3")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    args = ap.parse_args()

    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    corpus = load_corpus(Path(config["corpus"]["output_path"]))
    dataset = load_dataset(Path(config["dataset"]["output_path"]))
    cal_items, _ = split_dataset(
        dataset,
        n_cal=config["split"]["n_calibration"],
        n_test=config["split"]["n_test"],
        random_state=config["split"]["random_state"],
    )

    out_dir = Path(config["results"]["output_dir"]) / "exp_B_K3"
    if not out_dir.exists():
        logger.error("Output dir %s does not exist.", out_dir)
        return 1

    client = OllamaClient(host=config["ollama"]["host"])
    lookup = {d.doc_id: d.text for d in corpus}
    verifier = Verifier(
        client=client,
        model=config["models"]["verifier"],
        corpus_lookup=lookup,
        n_samples=config["verifier"]["n_samples"],
        score_fn=config["verifier"].get("score_fn", "aps"),
    )

    correct = []
    pbar = tqdm(cal_items, desc="Recovering exp_B_K3")
    for item in pbar:
        # K=3 pipeline: decomposer + retriever + verifier (no reader).
        # The verifier expects: a list[str] in history (retriever doc_ids),
        # optionally a str (reader summary). We provide only the doc_ids.
        retriever_doc_ids = list(item.doc_ids[:10])
        history = [
            ModuleOutput(value=retriever_doc_ids, score=None, aux={}),
        ]
        # No reader output — the verifier will use evidence directly

        state = PipelineState(query=item.query, gold={
            "sub_questions": item.sub_questions,
            "doc_ids": item.doc_ids,
            "answer": item.answer,
            "verdict": item.verdict,
        })
        state.history = history

        out = verifier.run(state)
        gold_v = (item.verdict if item.verdict in VERIFIER_LABELS
                  else averitec_label_to_verifier(item.verdict))
        correct.append(int(out.value == gold_v))

    correct_arr = np.array(correct, dtype=int)
    np.save(out_dir / "calibration_correct.npy", correct_arr)
    logger.info("Wrote %s", out_dir / "calibration_correct.npy")
    logger.info("K=3 calibration accuracy: %.3f (%d/%d)",
                correct_arr.mean(), correct_arr.sum(), len(correct_arr))
    return 0


if __name__ == "__main__":
    sys.exit(main())
