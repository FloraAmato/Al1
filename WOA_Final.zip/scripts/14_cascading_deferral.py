#!/usr/bin/env python
"""
Diagnostic-driven adaptive inference for agentic LLM pipelines.

Implements a cascading-deferral framework that uses per-module conformal
diagnostics to route each test input to one of seven operational
categories. The system emits a verdict from the K=4 pipeline when
confidence is high, falls back to a shorter pipeline (K=3, omitting the
reader) when the diagnostic identifies the reader as the failure source,
and escalates to human review only when no fallback is available.

The seven operational categories
--------------------------------

HIGH-CONFIDENCE
    K=4 pipeline confidence above the strict-calibration threshold.
    Emit the verifier's modal verdict. Conformal guarantee:
    conditional risk <= alpha_high (finite-sample-corrected).

MODERATE-CONFIDENCE
    K=4 pipeline confidence between strict and permissive thresholds.
    Emit verdict with a "review recommended" caveat. Conformal
    guarantee: conditional risk <= alpha_mod.

ROUTE-TO-SKIP-READER
    M3 (reader) is the diagnostic trigger. Fall back to the K=3
    pipeline that omits the reader. Emit the K=3 verdict, calibrated
    against K=3 outcomes.

ROUTE-TO-SKIP-DECOMPOSER
    M1 (decomposer) is the diagnostic trigger. Would fall back to a
    K=3 pipeline omitting the decomposer (M2+M3+M4). NOTE: this
    fallback is not implemented in the current data because exp_B_K3
    is the M1+M2+M4 configuration. Items in this category are
    currently treated as ESCALATE pending the additional calibration.

ESCALATE-RETRIEVAL-FAILURE
    M2 (retriever) is the diagnostic trigger. The retriever is
    structurally indispensable; no clean fallback exists. Escalate
    to a stronger retriever or human review.

ESCALATE-MULTIPLE-FAILURE
    Two or more upstream modules in their tails simultaneously.
    The input is anomalous on multiple dimensions; no single fallback
    recovers it. Escalate.

ESCALATE-VERIFIER-CONFLICT
    Upstream modules behave normally, but the verifier itself produces
    high disagreement among samples. The verifier is uncertain despite
    clean upstream input. Escalate to a stronger verifier.

Outputs
-------
results/cascading_deferral/
    cascading_summary.{tex,md,csv,json}     headline table per alpha sweep
    cascade_diagram.pdf                      stacked-bar visualization
    routing_attribution.pdf                  per-trigger breakdown
    fallback_efficacy.{tex,md}              K=4 vs K=3 outcomes on routed items
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("14_cascading_deferral")


# ====================================================================== #
# Helpers
# ====================================================================== #

def load_run(d: Path, require_cal_correct: bool = True) -> dict:
    """Load per-experiment artefacts."""
    cs_dict = json.loads((d / "calibration_scores.json").read_text())
    modules = list(cs_dict)
    cal_scores = np.column_stack(
        [np.asarray(cs_dict[m], dtype=float) for m in modules]
    )
    test_scores = np.load(d / "test_scores.npy")
    test_correct = np.load(d / "test_correct.npy").astype(int)
    cal_correct_path = d / "calibration_correct.npy"
    if cal_correct_path.exists():
        cal_correct = np.load(cal_correct_path).astype(int)
        cal_correct_is_proxy = False
    elif require_cal_correct:
        # Proxy fallback with prominent warning
        v_idx = next(i for i, m in enumerate(modules)
                     if "verifier" in m.lower())
        cal_correct = (cal_scores[:, v_idx] < 1.0).astype(int)
        cal_correct_is_proxy = True
        logger.warning(
            "calibration_correct.npy NOT FOUND in %s. Using proxy "
            "(verifier score < 1.0). This proxy is APPROXIMATE; run the "
            "recovery script to produce publishable numbers.", d
        )
    else:
        cal_correct = None
        cal_correct_is_proxy = False
    return {
        "modules": modules,
        "cal_scores": cal_scores,
        "test_scores": test_scores,
        "cal_correct": cal_correct,
        "test_correct": test_correct,
        "cal_correct_is_proxy": cal_correct_is_proxy,
    }


def calibrate_threshold_for_risk(
    signal: np.ndarray,
    correct: np.ndarray,
    alpha: float,
) -> float | None:
    """Largest threshold tau such that accepting items with signal >= tau
    yields finite-sample-corrected conditional risk <= alpha."""
    n = len(signal)
    order = np.argsort(-signal)
    best = None
    for i in range(1, n + 1):
        accepted = order[:i]
        emp_err = 1.0 - correct[accepted].mean()
        upper = (i * emp_err + 1.0) / (i + 1.0)
        if upper <= alpha:
            best = float(signal[accepted[-1]])
    return best


def per_module_calibration_ranks(
    test_scores: np.ndarray,
    cal_scores: np.ndarray,
    upstream_idx: list[int],
) -> np.ndarray:
    """For each test item and each upstream module k, return the empirical
    CDF rank of the test score in the calibration distribution."""
    out = np.zeros((test_scores.shape[0], len(upstream_idx)))
    for j, k in enumerate(upstream_idx):
        cal_k = cal_scores[:, k]
        for i in range(test_scores.shape[0]):
            out[i, j] = (cal_k <= test_scores[i, k]).sum() / len(cal_k)
    return out


# ====================================================================== #
# Routing logic
# ====================================================================== #

def route_inputs(
    k4_data: dict,
    k3_data: dict,
    alpha_high: float,
    alpha_mod: float,
    rank_thresh: float = 0.70,
    verifier_thresh: float = 0.60,
) -> dict:
    """Apply the cascading-deferral routing to test items.

    Returns a dict containing per-category masks, the routing decisions,
    and statistics useful for the publishable tables and figures.
    """
    modules = k4_data["modules"]
    K = len(modules)
    upstream_idx = list(range(K - 1))
    verifier_idx = K - 1

    cal_scores = k4_data["cal_scores"]
    test_scores = k4_data["test_scores"]
    cal_correct = k4_data["cal_correct"]
    test_correct = k4_data["test_correct"]
    n_test = test_scores.shape[0]

    # Pipeline-level confidence at K=4
    cal_C = -cal_scores.mean(axis=1)
    test_C = -test_scores.mean(axis=1)

    # Two-tier confidence calibration
    tau_high = calibrate_threshold_for_risk(cal_C, cal_correct, alpha_high)
    tau_mod = calibrate_threshold_for_risk(cal_C, cal_correct, alpha_mod)

    high = (test_C >= tau_high) if tau_high is not None else np.zeros(n_test, dtype=bool)
    moderate = (
        ((test_C >= tau_mod) & ~high)
        if tau_mod is not None
        else np.zeros(n_test, dtype=bool)
    )

    # Per-upstream-module calibration ranks
    test_ranks = per_module_calibration_ranks(test_scores, cal_scores, upstream_idx)
    n_in_tail = (test_ranks >= rank_thresh).sum(axis=1)

    # Identify trigger modules for items not in HIGH/MODERATE
    remaining = ~(high | moderate)
    route_skip_reader = np.zeros(n_test, dtype=bool)
    route_skip_decomp = np.zeros(n_test, dtype=bool)
    escalate_retrieval = np.zeros(n_test, dtype=bool)
    escalate_multifail = np.zeros(n_test, dtype=bool)
    escalate_verifier = np.zeros(n_test, dtype=bool)
    residual = np.zeros(n_test, dtype=bool)

    # Module-name lookup for trigger identification
    decomp_idx = next((j for j, k in enumerate(upstream_idx)
                       if "decomposer" in modules[k].lower()), None)
    retriever_idx = next((j for j, k in enumerate(upstream_idx)
                          if "retriever" in modules[k].lower()), None)
    reader_idx = next((j for j, k in enumerate(upstream_idx)
                       if "reader" in modules[k].lower()), None)

    for i in np.where(remaining)[0]:
        n_t = n_in_tail[i]
        if n_t >= 2:
            escalate_multifail[i] = True
        elif n_t == 1:
            tail_pos = int(np.argmax(test_ranks[i] >= rank_thresh))
            if tail_pos == reader_idx:
                route_skip_reader[i] = True
            elif tail_pos == decomp_idx:
                route_skip_decomp[i] = True
            elif tail_pos == retriever_idx:
                escalate_retrieval[i] = True
        else:  # n_t == 0
            if test_scores[i, verifier_idx] >= verifier_thresh:
                escalate_verifier[i] = True
            else:
                residual[i] = True

    # Sanity check
    masks = [high, moderate, route_skip_reader, route_skip_decomp,
             escalate_retrieval, escalate_multifail, escalate_verifier, residual]
    total = sum(m.astype(int) for m in masks)
    assert (total == 1).all(), f"Categories overlap or miss items: counts {[m.sum() for m in masks]}"

    # Compute outcomes per category
    def acc_or_nan(mask, correct_array):
        return float(correct_array[mask].mean()) if mask.sum() > 0 else float("nan")

    # K=3 outcomes for the routed-to-skip-reader items
    k3_test_correct = k3_data["test_correct"]
    k4_acc_on_skip_reader = acc_or_nan(route_skip_reader, test_correct)
    k3_acc_on_skip_reader = acc_or_nan(route_skip_reader, k3_test_correct)

    # The actual final accuracy: K=4 verdict if HIGH/MOD/residual,
    # K=3 verdict if route_skip_reader (skip_decomp routed to escalate
    # in the current data because we lack the M2+M3+M4 calibration).
    # Items in any escalate or skip_decomp category contribute "no verdict"
    # so we report two metrics: coverage (frac with verdict) and accuracy
    # among emitted verdicts.
    answered = high | moderate | route_skip_reader | residual
    answered_correct = np.zeros(n_test, dtype=int)
    answered_correct[high | moderate | residual] = test_correct[high | moderate | residual]
    answered_correct[route_skip_reader] = k3_test_correct[route_skip_reader]

    coverage = float(answered.mean())
    if answered.sum() > 0:
        acc_among_answered = float(answered_correct[answered].mean())
    else:
        acc_among_answered = float("nan")

    return {
        "alpha_high": alpha_high,
        "alpha_mod": alpha_mod,
        "rank_thresh": rank_thresh,
        "verifier_thresh": verifier_thresh,
        "tau_high": tau_high,
        "tau_mod": tau_mod,
        "n_test": n_test,
        "categories": {
            "HIGH-CONFIDENCE": {
                "n": int(high.sum()),
                "frac": float(high.mean()),
                "accuracy": acc_or_nan(high, test_correct),
                "items": [int(i) for i in np.where(high)[0]],
            },
            "MODERATE-CONFIDENCE": {
                "n": int(moderate.sum()),
                "frac": float(moderate.mean()),
                "accuracy": acc_or_nan(moderate, test_correct),
                "items": [int(i) for i in np.where(moderate)[0]],
            },
            "ROUTE-TO-SKIP-READER": {
                "n": int(route_skip_reader.sum()),
                "frac": float(route_skip_reader.mean()),
                "k4_accuracy": k4_acc_on_skip_reader,
                "k3_accuracy_after_route": k3_acc_on_skip_reader,
                "improvement": (k3_acc_on_skip_reader - k4_acc_on_skip_reader)
                               if route_skip_reader.sum() > 0 else float("nan"),
                "items": [int(i) for i in np.where(route_skip_reader)[0]],
            },
            "ROUTE-TO-SKIP-DECOMPOSER": {
                "n": int(route_skip_decomp.sum()),
                "frac": float(route_skip_decomp.mean()),
                "k4_accuracy": acc_or_nan(route_skip_decomp, test_correct),
                "note": "Routed to escalation in current run (M2+M3+M4 calibration not available)",
                "items": [int(i) for i in np.where(route_skip_decomp)[0]],
            },
            "ESCALATE-RETRIEVAL-FAILURE": {
                "n": int(escalate_retrieval.sum()),
                "frac": float(escalate_retrieval.mean()),
                "k4_would_be_accuracy": acc_or_nan(escalate_retrieval, test_correct),
                "items": [int(i) for i in np.where(escalate_retrieval)[0]],
            },
            "ESCALATE-MULTIPLE-FAILURE": {
                "n": int(escalate_multifail.sum()),
                "frac": float(escalate_multifail.mean()),
                "k4_would_be_accuracy": acc_or_nan(escalate_multifail, test_correct),
                "items": [int(i) for i in np.where(escalate_multifail)[0]],
            },
            "ESCALATE-VERIFIER-CONFLICT": {
                "n": int(escalate_verifier.sum()),
                "frac": float(escalate_verifier.mean()),
                "k4_would_be_accuracy": acc_or_nan(escalate_verifier, test_correct),
                "items": [int(i) for i in np.where(escalate_verifier)[0]],
            },
            "RESIDUAL": {
                "n": int(residual.sum()),
                "frac": float(residual.mean()),
                "accuracy": acc_or_nan(residual, test_correct),
                "items": [int(i) for i in np.where(residual)[0]],
            },
        },
        "headline": {
            "coverage": coverage,
            "accuracy_among_answered": acc_among_answered,
            "n_answered": int(answered.sum()),
            "n_escalated": int(n_test - answered.sum() - route_skip_decomp.sum()),
            "n_route_skip_decomp_pending": int(route_skip_decomp.sum()),
        },
    }


# ====================================================================== #
# Output
# ====================================================================== #

def write_summary(results: list[dict], out_dir: Path) -> None:
    """Headline table over alpha sweep, both Markdown and LaTeX."""
    md_lines = [
        "# Cascading-deferral routing summary (K=4 AVeriTeC with K=3 fallback)\n",
        "Each test item is assigned to exactly one operational category. "
        "HIGH/MODERATE-CONFIDENCE items receive a verdict from the K=4 "
        "pipeline. ROUTE-TO-SKIP-READER items receive a verdict from the "
        "K=3 fallback pipeline. ESCALATE categories are passed to human "
        "review. The headline coverage is the fraction of test items "
        "receiving any verdict; accuracy among answered is the empirical "
        "fraction of those verdicts that match gold.\n",
        "| α_high | α_mod | Coverage | Acc. answered | HIGH | MOD | "
        "ROUTE-READER (Δ acc) | ROUTE-DECOMP | ESC-RETR | ESC-MULTI | ESC-VER |",
        "|--------|-------|----------|---------------|------|-----|"
        "----------------------|--------------|----------|-----------|---------|",
    ]
    tex_rows = []
    for r in results:
        cats = r["categories"]
        h = r["headline"]
        rsr = cats["ROUTE-TO-SKIP-READER"]
        improv = rsr.get("improvement", float("nan"))
        improv_s = f"{improv:+.2f}" if not np.isnan(improv) else "—"
        rsr_s = f"{rsr['n']} ({improv_s})" if rsr["n"] > 0 else "0"
        md_lines.append(
            f"| {r['alpha_high']:.2f} | {r['alpha_mod']:.2f} | "
            f"{h['coverage']:.0%} | "
            f"{h['accuracy_among_answered']:.2f} | "
            f"{cats['HIGH-CONFIDENCE']['n']} | "
            f"{cats['MODERATE-CONFIDENCE']['n']} | "
            f"{rsr_s} | "
            f"{cats['ROUTE-TO-SKIP-DECOMPOSER']['n']} | "
            f"{cats['ESCALATE-RETRIEVAL-FAILURE']['n']} | "
            f"{cats['ESCALATE-MULTIPLE-FAILURE']['n']} | "
            f"{cats['ESCALATE-VERIFIER-CONFLICT']['n']} |"
        )
        tex_rows.append((r, cats, h))

    (out_dir / "cascading_summary.md").write_text(
        "\n".join(md_lines) + "\n", encoding="utf-8"
    )

    # LaTeX
    tex = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\small",
        r"\caption{Cascading-deferral routing on the K=4 AVeriTeC pipeline "
        r"with K=3 (M1+M2+M4) fallback. Each test item is assigned to "
        r"exactly one of seven operational categories. HIGH/MODERATE items "
        r"receive a verdict from K=4; ROUTE-TO-SKIP-READER items receive "
        r"a verdict from the K=3 fallback; ESCALATE categories are passed "
        r"to human review. Coverage is the fraction of items receiving any "
        r"verdict; accuracy is the empirical fraction of emitted verdicts "
        r"matching gold. The improvement column $\Delta$ for ROUTE-READER "
        r"shows the K=3 minus K=4 accuracy on routed items.}",
        r"\label{tab:cascading-summary}",
        r"\begin{tabular}{cc|cc|cccc|ccc}",
        r"\toprule",
        r"$\alpha_h$ & $\alpha_m$ & Cov. & Acc. & HIGH & MOD & "
        r"R-RDR ($\Delta$) & R-DEC & E-RETR & E-MULTI & E-VER \\",
        r"\midrule",
    ]
    for r, cats, h in tex_rows:
        rsr = cats["ROUTE-TO-SKIP-READER"]
        improv = rsr.get("improvement", float("nan"))
        improv_s = f"{improv:+.2f}" if not np.isnan(improv) else "---"
        rsr_s = f"{rsr['n']} ({improv_s})" if rsr["n"] > 0 else "0"
        tex.append(
            f"{r['alpha_high']:.2f} & {r['alpha_mod']:.2f} & "
            f"{h['coverage']:.2f} & {h['accuracy_among_answered']:.2f} & "
            f"{cats['HIGH-CONFIDENCE']['n']} & "
            f"{cats['MODERATE-CONFIDENCE']['n']} & "
            f"{rsr_s} & {cats['ROUTE-TO-SKIP-DECOMPOSER']['n']} & "
            f"{cats['ESCALATE-RETRIEVAL-FAILURE']['n']} & "
            f"{cats['ESCALATE-MULTIPLE-FAILURE']['n']} & "
            f"{cats['ESCALATE-VERIFIER-CONFLICT']['n']} \\\\"
        )
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
    (out_dir / "cascading_summary.tex").write_text(
        "\n".join(tex) + "\n", encoding="utf-8"
    )

    # CSV (machine-readable)
    csv_lines = ["alpha_high,alpha_mod,category,n,fraction,metric_name,metric_value"]
    for r in results:
        for name, c in r["categories"].items():
            for k, v in c.items():
                if k in ("n", "frac", "items"): continue
                if isinstance(v, (int, float)):
                    csv_lines.append(
                        f"{r['alpha_high']},{r['alpha_mod']},{name},"
                        f"{c['n']},{c['frac']:.4f},{k},{v:.4f}"
                    )
    (out_dir / "cascading_summary.csv").write_text(
        "\n".join(csv_lines) + "\n", encoding="utf-8"
    )

    # Full JSON
    (out_dir / "cascading_summary.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )


def write_fallback_efficacy(results: list[dict], out_dir: Path) -> None:
    """Focused table showing K=4 vs K=3 outcomes on routed items."""
    md = [
        "# Fallback efficacy: K=4 vs K=3 outcomes on ROUTE-TO-SKIP-READER items\n",
        "Items where the K=4 diagnostic identified the reader (M3) as the "
        "source of uncertainty. The K=4 pipeline would have emitted a "
        "verdict from the full pipeline; the cascading framework instead "
        "routes these items to the K=3 (no-reader) pipeline. The "
        "comparison below shows the K=4 verdict accuracy that would have "
        "been emitted versus the K=3 verdict accuracy actually emitted.\n",
        "| α_high | α_mod | n routed | K=4 acc on routed | K=3 acc on routed | Δ (K=3 - K=4) |",
        "|--------|-------|----------|-------------------|-------------------|---------------|",
    ]
    for r in results:
        rsr = r["categories"]["ROUTE-TO-SKIP-READER"]
        if rsr["n"] == 0:
            md.append(
                f"| {r['alpha_high']:.2f} | {r['alpha_mod']:.2f} | 0 | — | — | — |"
            )
            continue
        k4 = rsr["k4_accuracy"]
        k3 = rsr["k3_accuracy_after_route"]
        delta = rsr["improvement"]
        md.append(
            f"| {r['alpha_high']:.2f} | {r['alpha_mod']:.2f} | {rsr['n']} | "
            f"{k4:.3f} | {k3:.3f} | {delta:+.3f} |"
        )
    (out_dir / "fallback_efficacy.md").write_text(
        "\n".join(md) + "\n", encoding="utf-8"
    )

    tex = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Fallback efficacy on ROUTE-TO-SKIP-READER items. The "
        r"diagnostic identifies the reader as the failure source; the "
        r"K=3 fallback (no reader) is invoked. We compare the K=4 verdict "
        r"that would have been emitted against the K=3 verdict actually "
        r"emitted.}",
        r"\label{tab:fallback-efficacy}",
        r"\begin{tabular}{ccccccc}",
        r"\toprule",
        r"$\alpha_h$ & $\alpha_m$ & $n$ routed & $K{=}4$ acc & $K{=}3$ acc & $\Delta$ \\",
        r"\midrule",
    ]
    for r in results:
        rsr = r["categories"]["ROUTE-TO-SKIP-READER"]
        if rsr["n"] == 0:
            tex.append(
                f"{r['alpha_high']:.2f} & {r['alpha_mod']:.2f} & 0 & --- & --- & --- \\\\"
            )
            continue
        tex.append(
            f"{r['alpha_high']:.2f} & {r['alpha_mod']:.2f} & {rsr['n']} & "
            f"{rsr['k4_accuracy']:.2f} & {rsr['k3_accuracy_after_route']:.2f} & "
            f"{rsr['improvement']:+.2f} \\\\"
        )
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (out_dir / "fallback_efficacy.tex").write_text(
        "\n".join(tex) + "\n", encoding="utf-8"
    )


def make_plots(results: list[dict], out_dir: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not available; skipping plots")
        return

    # Stacked-bar by alpha_high
    alphas = [r["alpha_high"] for r in results]
    cat_names = ["HIGH-CONFIDENCE", "MODERATE-CONFIDENCE",
                 "ROUTE-TO-SKIP-READER", "ROUTE-TO-SKIP-DECOMPOSER",
                 "ESCALATE-RETRIEVAL-FAILURE", "ESCALATE-MULTIPLE-FAILURE",
                 "ESCALATE-VERIFIER-CONFLICT", "RESIDUAL"]
    colors = ["#2ca02c", "#98df8a", "#1f77b4", "#aec7e8",
              "#ff7f0e", "#9467bd", "#d62728", "#7f7f7f"]
    short_labels = ["HIGH", "MODERATE", "ROUTE-READER", "ROUTE-DECOMP",
                    "ESC-RETR", "ESC-MULTI", "ESC-VER", "RES"]

    counts = np.array([
        [r["categories"][n]["n"] for n in cat_names]
        for r in results
    ])

    fig, ax = plt.subplots(figsize=(8, 4.5))
    x = np.arange(len(alphas))
    width = 0.6
    bottom = np.zeros(len(alphas))
    for j, name in enumerate(cat_names):
        if counts[:, j].sum() == 0:
            continue
        ax.bar(x, counts[:, j], width, bottom=bottom,
               color=colors[j], label=short_labels[j])
        bottom += counts[:, j]
    ax.set_xticks(x)
    ax.set_xticklabels([f"{a:.2f}" for a in alphas])
    ax.set_xlabel(r"Strict target risk $\alpha_h$ "
                  r"(MODERATE at $\alpha_m=\alpha_h+0.10$)")
    ax.set_ylabel("Test items (n=61)")
    ax.set_title("Cascading-deferral category mix, K=4 AVeriTeC")
    ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0),
              frameon=True, fontsize=9)
    ax.grid(True, axis="y", alpha=0.3)
    fig.tight_layout()
    out = out_dir / "cascade_diagram.pdf"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Wrote %s", out)

    # Routing attribution: what fraction of escalations come from each cause?
    esc_categories = ["ESCALATE-RETRIEVAL-FAILURE", "ESCALATE-MULTIPLE-FAILURE",
                      "ESCALATE-VERIFIER-CONFLICT", "ROUTE-TO-SKIP-DECOMPOSER"]
    esc_short = ["RETRIEVAL", "MULTIPLE", "VERIFIER", "DECOMPOSER"]
    esc_colors = ["#ff7f0e", "#9467bd", "#d62728", "#aec7e8"]
    esc_counts = np.array([
        [r["categories"][n]["n"] for n in esc_categories]
        for r in results
    ])
    fig2, ax2 = plt.subplots(figsize=(7, 4))
    width = 0.18
    x = np.arange(len(alphas))
    for j, name in enumerate(esc_short):
        ax2.bar(x + (j - 1.5) * width, esc_counts[:, j], width,
                label=name, color=esc_colors[j])
    ax2.set_xticks(x)
    ax2.set_xticklabels([f"{a:.2f}" for a in alphas])
    ax2.set_xlabel(r"$\alpha_h$")
    ax2.set_ylabel("Items routed to escalation")
    ax2.set_title("Escalation/routing source attribution")
    ax2.legend(frameon=True)
    ax2.grid(True, axis="y", alpha=0.3)
    fig2.tight_layout()
    out2 = out_dir / "routing_attribution.pdf"
    fig2.savefig(out2, dpi=150, bbox_inches="tight")
    plt.close(fig2)
    logger.info("Wrote %s", out2)


# ====================================================================== #
# Main
# ====================================================================== #

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results", type=Path)
    ap.add_argument("--k4-dir", default="exp_C_K4")
    ap.add_argument("--k3-dir", default="exp_B_K3",
                    help="K=3 fallback directory (M1+M2+M4 configuration).")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--alphas-high", default="0.20,0.25,0.30,0.35,0.40",
                    help="Strict-tier risk levels.")
    ap.add_argument("--alpha-mod-offset", type=float, default=0.10,
                    help="Moderate alpha = alpha_high + offset.")
    ap.add_argument("--rank-thresh", type=float, default=0.70)
    ap.add_argument("--verifier-thresh", type=float, default=0.60)
    args = ap.parse_args()

    out_dir = args.out_dir or (args.results_dir / "cascading_deferral")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    k4_data = load_run(args.results_dir / args.k4_dir, require_cal_correct=True)
    k3_data = load_run(args.results_dir / args.k3_dir, require_cal_correct=True)

    if k4_data["cal_correct_is_proxy"]:
        logger.warning("K=4 calibration_correct.npy is a proxy — results not "
                       "publishable. Run scripts/recover_calibration_correct.py "
                       "for K=4 first.")
    if k3_data["cal_correct_is_proxy"]:
        logger.warning("K=3 calibration_correct.npy is a proxy — fallback "
                       "calibration is approximate. Run "
                       "scripts/recover_calibration_correct_K3.py for "
                       "publishable K=3 numbers.")

    logger.info("K=4 modules: %s", k4_data["modules"])
    logger.info("K=3 fallback modules: %s", k3_data["modules"])
    logger.info("Test items: %d", k4_data["test_scores"].shape[0])

    alphas_high = [float(a) for a in args.alphas_high.split(",")]
    results = []
    for ah in alphas_high:
        am = ah + args.alpha_mod_offset
        r = route_inputs(
            k4_data, k3_data, ah, am,
            rank_thresh=args.rank_thresh,
            verifier_thresh=args.verifier_thresh,
        )
        results.append(r)
        cats = r["categories"]
        logger.info(
            "α_h=%.2f α_m=%.2f  HIGH=%d MOD=%d  R-RDR=%d (Δ=%s)  "
            "R-DEC=%d  E-RETR=%d  E-MULTI=%d  E-VER=%d  cov=%.0f%%",
            ah, am,
            cats["HIGH-CONFIDENCE"]["n"], cats["MODERATE-CONFIDENCE"]["n"],
            cats["ROUTE-TO-SKIP-READER"]["n"],
            f"{cats['ROUTE-TO-SKIP-READER'].get('improvement', float('nan')):+.2f}"
            if cats["ROUTE-TO-SKIP-READER"]["n"] > 0 else "—",
            cats["ROUTE-TO-SKIP-DECOMPOSER"]["n"],
            cats["ESCALATE-RETRIEVAL-FAILURE"]["n"],
            cats["ESCALATE-MULTIPLE-FAILURE"]["n"],
            cats["ESCALATE-VERIFIER-CONFLICT"]["n"],
            100 * r["headline"]["coverage"],
        )

    write_summary(results, out_dir)
    write_fallback_efficacy(results, out_dir)
    make_plots(results, out_dir)
    logger.info("Wrote outputs to %s", out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
