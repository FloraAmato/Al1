#!/usr/bin/env python
"""
Simplified emit-or-escalate category mix across the α sweep.

Companion to the seven-category mix figure produced by
14_cascading_deferral.py. This script collapses the seven cascading
categories into the two top-level decisions and produces a clean
stacked-bar visualisation showing how the framework's decision shifts
as the strict target risk α changes.

Categories collapsed:
  EMIT      = HIGH-CONFIDENCE + MODERATE-CONFIDENCE + RESIDUAL
            + ESCALATE-VERIFIER-CONFLICT (re-classified as emit-with-flag)
            + ROUTE-TO-SKIP-DECOMPOSER (decomposer tail not predictive)
            + ROUTE-TO-SKIP-READER (K=3 fallback verdict, but here
              counted as emit because a verdict is produced)
  ESCALATE  = ESCALATE-RETRIEVAL-FAILURE + ESCALATE-MULTIPLE-FAILURE

Reads only saved data; ~5 seconds CPU.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("24_emit_escalate_mix")


COLORS = {
    "emit": "#3d8b3d",       # Forest green
    "escalate": "#c44f4f",   # Brick red
    "neutral": "#7a7a7a",
}

EMIT_KEYS = [
    "HIGH-CONFIDENCE",
    "MODERATE-CONFIDENCE",
    "ESCALATE-VERIFIER-CONFLICT",
    "ROUTE-TO-SKIP-DECOMPOSER",
    "ROUTE-TO-SKIP-READER",
    "RESIDUAL",
]
ESCALATE_KEYS = [
    "ESCALATE-RETRIEVAL-FAILURE",
    "ESCALATE-MULTIPLE-FAILURE",
]


def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.6,
        "axes.edgecolor": "#444444",
        "axes.labelcolor": "#222222",
        "xtick.color": "#444444",
        "ytick.color": "#444444",
        "grid.linewidth": 0.4,
        "grid.color": "#dddddd",
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.05,
    })
    return plt


def collapse(r: dict) -> tuple[int, int]:
    """Return (n_emit, n_escalate) for one alpha record."""
    cats = r["categories"]
    n_emit = sum(len(cats.get(k, {"items": []})["items"]) for k in EMIT_KEYS)
    n_esc = sum(len(cats.get(k, {"items": []})["items"]) for k in ESCALATE_KEYS)
    return n_emit, n_esc


def make_figure(plt, cascading: list[dict], out_path: Path, n_test: int):
    alphas = [r["alpha_high"] for r in cascading]
    emits, escs = zip(*[collapse(r) for r in cascading])

    fig, ax = plt.subplots(figsize=(5.5, 3.5))
    x = np.arange(len(alphas))
    width = 0.55

    bars_emit = ax.bar(x, emits, width,
                       color=COLORS["emit"],
                       edgecolor="#222222", linewidth=0.7,
                       label="EMIT (verdict produced)", zorder=3)
    bars_esc = ax.bar(x, escs, width, bottom=emits,
                      color=COLORS["escalate"],
                      edgecolor="#222222", linewidth=0.7,
                      label="ESCALATE (route to review)", zorder=3)

    # Annotate counts inside each segment
    for bar, n in zip(bars_emit, emits):
        if n >= 3:
            ax.text(bar.get_x() + bar.get_width()/2,
                    n / 2,
                    f"{n}\n({100*n/n_test:.0f}%)",
                    ha="center", va="center",
                    color="white", fontsize=9, fontweight="bold")
    for bar, n_e, n_em in zip(bars_esc, escs, emits):
        if n_e >= 8:
            ax.text(bar.get_x() + bar.get_width()/2,
                    n_em + n_e / 2,
                    f"{n_e}\n({100*n_e/n_test:.0f}%)",
                    ha="center", va="center",
                    color="white", fontsize=9, fontweight="bold")
        elif n_e > 0:
            # Small segment: annotate above the stack with darker color
            ax.text(bar.get_x() + bar.get_width()/2,
                    n_em + n_e + 1.0,
                    f"{n_e} ({100*n_e/n_test:.0f}%)",
                    ha="center", va="bottom",
                    fontsize=9, color="#7a2222", fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels([f"{a:.2f}" for a in alphas])
    ax.set_xlabel(r"Strict target risk $\alpha_h$  "
                  r"(MODERATE at $\alpha_m = \alpha_h + 0.10$)",
                  fontsize=9)
    ax.set_ylabel(f"Test items (n={n_test})")
    ax.set_ylim(0, n_test * 1.13)
    ax.grid(True, axis="y", alpha=0.4, zorder=1)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.16),
              ncol=2, frameon=True, fontsize=9,
              fancybox=False, edgecolor="#cccccc")
    ax.set_title(r"Emit-or-escalate decision mix across $\alpha$ sweep,  K=4 AVeriTeC",
                 pad=8)

    fig.subplots_adjust(bottom=0.22)
    fig.savefig(out_path)
    plt.close(fig)
    logger.info("Wrote %s", out_path)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results", type=Path)
    ap.add_argument("--cascading-summary", default=None)
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    out_dir = Path(args.out_dir or (args.results_dir / "paper_figures"))
    out_dir.mkdir(parents=True, exist_ok=True)

    cas_path = Path(args.cascading_summary or (
        args.results_dir / "cascading_deferral" / "cascading_summary.json"
    ))
    if not cas_path.exists():
        logger.error("cascading_summary.json not found at %s. Run "
                     "scripts/14_cascading_deferral.py first.", cas_path)
        return 1

    plt = setup_matplotlib()
    cascading = json.loads(cas_path.read_text())
    n_test = cascading[0]["n_test"]

    out_pdf = out_dir / "fig_emit_escalate_mix.pdf"
    make_figure(plt, cascading, out_pdf, n_test)

    # Also dump a small JSON summary
    summary = []
    for r in cascading:
        n_emit, n_esc = collapse(r)
        summary.append({
            "alpha_high": r["alpha_high"],
            "alpha_mod": r["alpha_mod"],
            "n_emit": n_emit,
            "n_escalate": n_esc,
            "frac_emit": n_emit / n_test,
            "frac_escalate": n_esc / n_test,
        })
    out_json = out_dir / "fig_emit_escalate_mix.json"
    out_json.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    logger.info("Wrote %s", out_json)

    # Console summary
    logger.info("=== EMIT-OR-ESCALATE MIX ===")
    for s in summary:
        logger.info("  α_h=%.2f  EMIT=%d (%.0f%%)  ESCALATE=%d (%.0f%%)",
                    s["alpha_high"], s["n_emit"], 100*s["frac_emit"],
                    s["n_escalate"], 100*s["frac_escalate"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
