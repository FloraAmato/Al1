#!/usr/bin/env python
"""
Advanced paper-ready plots for the simplified emit-or-escalate framework.

Six publication figures, designed to:
  1. Define selective abstention canonically (risk-coverage trade-off).
  2. Surface F1 and macro-recall (not just aggregate accuracy).
  3. Diagnose the *type* of degeneration each escalation source captures
     (per-module score signatures).
  4. Avoid label collisions through careful sizing, rotation, and
     horizontal layout where useful.

Figures
-------
  fig1_risk_coverage_curve.pdf
      Canonical selective-prediction view. Conditional risk vs coverage
      across the alpha sweep, with reference points for the
      unconditional pipeline. Adds binary-decision F1 as a secondary
      curve overlaid.

  fig2_headline_metrics.pdf
      Per-alpha bar chart with three grouped bars per alpha:
      accuracy among emitted, macro-recall (per-class average), and
      binary-decision F1. Reveals the gap between accuracy and macro
      recall — the minority-class collapse that aggregate accuracy
      hides.

  fig3_per_class_recall_heatmap.pdf
      Per-class recall heatmap. Rows = decisions (EMIT, RETR, MULTI),
      columns = AVeriTeC classes. Cell color = recall, cell text =
      "k/n". Replaces grouped bars with a clean two-dimensional
      visualisation. Macro recall annotated to the right of each row.

  fig4_score_signatures.pdf
      Degeneration diagnostic. For each upstream module, the score
      distribution on EMIT items vs ESCALATE items. Reveals what the
      diagnostic is "seeing" when it attributes failure to a module —
      the score signature that distinguishes hard items from easy ones.

  fig5_reliability_ordering.pdf
      Per-decision accuracy with bar widths proportional to the share
      of test items absorbed by each decision. Shows reliability
      ordering and coverage attribution simultaneously.

  fig6_escalation_class_composition.pdf
      Stacked bars: gold-class composition of each escalation source.
      Reveals which gold classes drive each failure mode.

All figures use vector text in PDFs (selectable, resizable),
sans-serif typography sized for CEUR single-column layout, and
careful spacing to avoid label collisions.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("23_paper_plots_v3")


CLASSES = ["Supported", "Refuted",
           "Not Enough Evidence", "Conflicting Evidence/Cherrypicking"]
SHORT_CLASS = {
    "Supported": "SUP", "Refuted": "REF",
    "Not Enough Evidence": "NEE",
    "Conflicting Evidence/Cherrypicking": "CONF",
}
ESCALATE_SOURCES = [
    "ESCALATE-RETRIEVAL", "ESCALATE-READER",
    "ESCALATE-VERIFIER", "ESCALATE-MULTIPLE",
]
SHORT_SRC = {
    "ESCALATE-RETRIEVAL": "RETR",
    "ESCALATE-READER": "READER",
    "ESCALATE-VERIFIER": "VERIF",
    "ESCALATE-MULTIPLE": "MULTI",
}

COLORS = {
    "primary": "#1f5582",
    "secondary": "#c44f4f",
    "tertiary": "#3d8b3d",
    "highlight": "#e8a13a",
    "accent": "#7d4ba0",
    "neutral": "#7a7a7a",
}
CLASS_COLORS = {
    "Supported": "#3d8b3d",
    "Refuted": "#1f5582",
    "Not Enough Evidence": "#e8a13a",
    "Conflicting Evidence/Cherrypicking": "#c44f4f",
}


def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.6,
        "axes.edgecolor": "#444444",
        "axes.labelcolor": "#222222",
        "xtick.color": "#444444",
        "ytick.color": "#444444",
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "grid.linewidth": 0.4,
        "grid.color": "#dddddd",
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.06,
    })
    return plt


def load_dataset_split(data_dir: Path, n_cal: int, n_test: int, seed: int):
    sys.path.insert(0, "src")
    from conformal_agentic_rag.dataset import load_dataset, split_dataset
    ds = load_dataset(data_dir / "dataset.json")
    return split_dataset(ds, n_cal=n_cal, n_test=n_test, random_state=seed)


# ====================================================================== #
# Fig 1 — Risk-coverage curve (canonical selective prediction view)
# ====================================================================== #

def fig1_risk_coverage_curve(plt, per_alpha: list[dict], out_dir: Path):
    coverages = [a["emit"]["frac_of_test"] for a in per_alpha]
    risks = [1.0 - a["emit"]["accuracy"] for a in per_alpha]
    f1s = [a["binary_decision"]["f1"] for a in per_alpha]
    alphas = [a["alpha_high"] for a in per_alpha]

    # Sort by coverage so the curve traces left-to-right
    order = np.argsort(coverages)
    coverages = [coverages[i] for i in order]
    risks = [risks[i] for i in order]
    f1s = [f1s[i] for i in order]
    alphas = [alphas[i] for i in order]

    fig, ax = plt.subplots(figsize=(4.4, 3.0))

    # Deduplicate co-located points (alphas with identical coverage and risk
    # collapse onto one marker, with annotation listing all alphas)
    point_to_alphas: dict[tuple, list[float]] = {}
    for cov, risk, alpha in zip(coverages, risks, alphas):
        key = (round(cov, 4), round(risk, 4))
        point_to_alphas.setdefault(key, []).append(alpha)
    unique_covs = [k[0] for k in point_to_alphas]
    unique_risks = [k[1] for k in point_to_alphas]

    ax.plot(unique_covs, unique_risks, "o-",
            color=COLORS["primary"], linewidth=1.8,
            markersize=6, zorder=3, label="Conditional risk")
    # Annotate each unique point with all collapsed alphas
    for (cov, risk), als in point_to_alphas.items():
        if len(als) == 1:
            label = rf"$\alpha_h={als[0]:.2f}$"
        else:
            # range collapse: e.g. "α=0.20–0.30"
            label = rf"$\alpha_h={min(als):.2f}$–${max(als):.2f}$"
        ax.annotate(label, xy=(cov, risk), xytext=(8, 8),
                    textcoords="offset points",
                    fontsize=7, color=COLORS["primary"])

    # Reference: unconditional pipeline (cov=1.0, risk=1-0.672=0.328)
    ax.plot([1.0], [0.328], "X",
            color=COLORS["secondary"], markersize=10,
            zorder=4, label="Unconditional K=4 (cov=1, risk=0.33)")

    ax.set_xlabel("Coverage (fraction of test emitted)")
    ax.set_ylabel("Conditional risk on emitted (1 − accuracy)")
    ax.set_xlim(0, 1.05)
    ax.set_ylim(0, 0.5)
    ax.grid(True, alpha=0.4, zorder=1)
    ax.legend(loc="upper left", frameon=True, fontsize=7,
              fancybox=False, edgecolor="#cccccc")
    ax.set_title("Risk-coverage trade-off (selective prediction)", pad=8)

    fig.tight_layout()
    out = out_dir / "fig1_risk_coverage_curve.pdf"
    fig.savefig(out)
    plt.close(fig)
    logger.info("Wrote %s", out)


# ====================================================================== #
# Fig 2 — Headline metrics: accuracy, macro-recall, F1 across alpha
# ====================================================================== #

def fig2_headline_metrics(plt, per_alpha: list[dict], out_dir: Path):
    alphas = [a["alpha_high"] for a in per_alpha]
    accs = [a["emit"]["accuracy"] for a in per_alpha]
    macro_recs = [a["emit"]["macro_recall"] for a in per_alpha]
    f1s = [a["binary_decision"]["f1"] for a in per_alpha]

    fig, ax = plt.subplots(figsize=(5.2, 3.0))
    x = np.arange(len(alphas))
    width = 0.27

    bars1 = ax.bar(x - width, accs, width,
                   color=COLORS["primary"], edgecolor="#333333",
                   linewidth=0.5, label="Accuracy on EMIT", zorder=3)
    bars2 = ax.bar(x, macro_recs, width,
                   color=COLORS["highlight"], edgecolor="#333333",
                   linewidth=0.5, label="Macro recall on EMIT", zorder=3)
    bars3 = ax.bar(x + width, f1s, width,
                   color=COLORS["accent"], edgecolor="#333333",
                   linewidth=0.5, label="Binary decision F1", zorder=3)

    # Annotate values
    for bars in [bars1, bars2, bars3]:
        for bar in bars:
            v = bar.get_height()
            if v > 0.02:
                ax.text(bar.get_x() + bar.get_width()/2, v + 0.01,
                        f"{v:.2f}", ha="center", va="bottom", fontsize=6.5)

    ax.axhline(y=0.672, color=COLORS["neutral"], linestyle="--",
               linewidth=0.8, alpha=0.7, zorder=2)

    ax.set_xticks(x)
    ax.set_xticklabels([f"{a:.2f}" for a in alphas])
    ax.set_xlabel(r"Strict target risk $\alpha_h$")
    ax.set_ylabel("Metric value")
    ax.set_ylim(0, 1.08)
    ax.set_xlim(-0.55, len(alphas) - 0.45)
    ax.grid(True, axis="y", alpha=0.4, zorder=1)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.18),
              ncol=3, frameon=True, fontsize=7.5,
              fancybox=False, edgecolor="#cccccc")
    ax.set_title("Headline metrics: accuracy vs macro-recall vs F1\n"
                 r"(dashed line: K=4 unconditional accuracy = 0.67)",
                 pad=8, fontsize=10)

    fig.subplots_adjust(bottom=0.24)
    out = out_dir / "fig2_headline_metrics.pdf"
    fig.savefig(out)
    plt.close(fig)
    logger.info("Wrote %s", out)


# ====================================================================== #
# Fig 3 — Per-class recall heatmap with macro-recall annotation
# ====================================================================== #

def fig3_per_class_recall_heatmap(plt, per_alpha: list[dict],
                                    target_alpha: float, out_dir: Path):
    target = min(per_alpha, key=lambda a: abs(a["alpha_high"] - target_alpha))

    decisions = [("EMIT", target["emit"])]
    for s in ESCALATE_SOURCES:
        es = target["by_source"][s]
        if es["n"] > 0:
            decisions.append((SHORT_SRC[s], es))

    n_rows = len(decisions)
    n_cols = len(CLASSES)

    rec_matrix = np.full((n_rows, n_cols), np.nan)
    text_grid = [["" for _ in range(n_cols)] for _ in range(n_rows)]
    macro_recalls = []
    for r, (label, d) in enumerate(decisions):
        cls_recalls = []
        for c, cls in enumerate(CLASSES):
            if cls in d["per_class"]:
                p = d["per_class"][cls]
                rec_matrix[r, c] = p["accuracy"]  # recall == accuracy on subset conditioned on gold class
                text_grid[r][c] = f"{p['correct']}/{p['n']}"
                cls_recalls.append(p["accuracy"])
            else:
                text_grid[r][c] = ""
        macro_recalls.append(np.mean(cls_recalls) if cls_recalls else float("nan"))

    fig, ax = plt.subplots(figsize=(6.0, 2.8))
    import matplotlib as mpl
    cmap = mpl.cm.get_cmap("RdYlGn").copy()
    cmap.set_bad("#eeeeee")
    masked = np.ma.masked_invalid(rec_matrix)
    im = ax.imshow(masked, cmap=cmap, vmin=0.0, vmax=1.0, aspect="auto")

    ax.set_xticks(np.arange(n_cols))
    ax.set_xticklabels([SHORT_CLASS[c] for c in CLASSES], fontsize=9)
    ax.set_yticks(np.arange(n_rows))
    ax.set_yticklabels([label for label, _ in decisions], fontsize=9, fontweight="bold")
    ax.tick_params(axis="both", which="both", length=0)

    for r in range(n_rows):
        for c in range(n_cols):
            v = rec_matrix[r, c]
            txt = text_grid[r][c]
            if not txt: continue
            color = "white" if (not np.isnan(v) and (v < 0.35 or v > 0.85)) else "#222222"
            ax.text(c, r, txt, ha="center", va="center",
                    color=color, fontsize=8.5, fontweight="bold")

    # Macro recall column, drawn well to the right of the heatmap with clear gap
    for r, mr in enumerate(macro_recalls):
        ax.text(n_cols - 0.4 + 0.95, r, f"macro\nrecall\n{mr:.2f}",
                ha="left", va="center", fontsize=8,
                color="#333333", fontweight="bold")

    # Subtle minor gridlines
    ax.set_xticks(np.arange(n_cols + 1) - 0.5, minor=True)
    ax.set_yticks(np.arange(n_rows + 1) - 0.5, minor=True)
    ax.grid(which="minor", color="white", linewidth=1.2)
    ax.tick_params(which="minor", length=0)

    # Extend xlim to make room for macro column
    ax.set_xlim(-0.5, n_cols - 0.5 + 1.4)

    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.10, shrink=0.85)
    cbar.set_label("Per-class recall", fontsize=8)
    cbar.ax.tick_params(labelsize=7)
    cbar.outline.set_linewidth(0.4)

    ax.set_title(rf"Per-class recall by decision "
                 rf"($\alpha_h={target['alpha_high']:.2f}$)",
                 pad=8)

    fig.tight_layout()
    out = out_dir / "fig3_per_class_recall_heatmap.pdf"
    fig.savefig(out)
    plt.close(fig)
    logger.info("Wrote %s", out)


# ====================================================================== #
# Fig 4 — Score signatures: degeneration diagnostic per upstream module
# ====================================================================== #

def fig4_score_signatures(plt, per_alpha: list[dict],
                            target_alpha: float,
                            test_scores: np.ndarray,
                            modules: list[str],
                            out_dir: Path):
    """For each upstream module, plot the score distribution on EMIT items
    versus ESCALATE items. Reveals what 'failure' looks like in each module's
    score space."""
    target = min(per_alpha, key=lambda a: abs(a["alpha_high"] - target_alpha))

    # We need the item lists. Reconstruct from cascading_summary if needed.
    # For simplicity in this script we will require the diagnostic to expose
    # them — fall back to cascading_summary path if not present.
    # Here we use what's already in target (after diagnostic stores items).
    emit_items = target["emit"].get("items")
    if emit_items is None:
        # Reconstruct from items field per source — diagnostic_full.json drops them
        # so we need cascading_summary
        cas_path = Path("results/cascading_deferral/cascading_summary.json")
        if cas_path.exists():
            cas = json.loads(cas_path.read_text())
            r = next(c for c in cas if abs(c["alpha_high"] - target["alpha_high"]) < 1e-6)
            emit_items = []
            for k in ["HIGH-CONFIDENCE","MODERATE-CONFIDENCE","ESCALATE-VERIFIER-CONFLICT",
                      "ROUTE-TO-SKIP-DECOMPOSER","ROUTE-TO-SKIP-READER","RESIDUAL"]:
                emit_items.extend(r["categories"].get(k, {"items": []})["items"])
            esc_items = []
            for k in ["ESCALATE-RETRIEVAL-FAILURE","ESCALATE-MULTIPLE-FAILURE"]:
                esc_items.extend(r["categories"].get(k, {"items": []})["items"])
        else:
            logger.warning("Cannot find item lists for fig4; skipping")
            return
    else:
        # Items present; gather from each source
        esc_items = []
        for s in ESCALATE_SOURCES:
            esc_items.extend(target["by_source"][s].get("items", []))

    upstream_modules = [(i, m) for i, m in enumerate(modules)
                         if "verifier" not in m.lower()]
    n_modules = len(upstream_modules)

    fig, axes = plt.subplots(1, n_modules, figsize=(5.5, 2.2),
                              sharey=True)
    if n_modules == 1:
        axes = [axes]

    for ax, (idx, mod_name) in zip(axes, upstream_modules):
        scores_emit = test_scores[emit_items, idx]
        scores_esc = test_scores[esc_items, idx]
        # Use shared bins
        all_scores = np.concatenate([scores_emit, scores_esc])
        bins = np.linspace(all_scores.min(), all_scores.max(), 10)
        ax.hist(scores_emit, bins=bins, color=COLORS["tertiary"],
                alpha=0.65, label="EMIT", edgecolor="#333", linewidth=0.4)
        ax.hist(scores_esc, bins=bins, color=COLORS["secondary"],
                alpha=0.65, label="ESCALATE", edgecolor="#333", linewidth=0.4)
        # Short module name for x-axis title
        short_name = mod_name.split("_")[1].capitalize() if "_" in mod_name else mod_name
        ax.set_title(short_name, fontsize=9)
        ax.set_xlabel("Score", fontsize=8)
        ax.tick_params(axis="both", labelsize=7)
        ax.grid(True, axis="y", alpha=0.3)

    axes[0].set_ylabel("Count", fontsize=8)
    axes[-1].legend(loc="upper right", frameon=True, fontsize=7,
                    fancybox=False, edgecolor="#cccccc")
    fig.suptitle("Score signatures by module (degeneration diagnostic)",
                 fontsize=10, y=1.00)

    fig.tight_layout()
    out = out_dir / "fig4_score_signatures.pdf"
    fig.savefig(out)
    plt.close(fig)
    logger.info("Wrote %s", out)


# ====================================================================== #
# Fig 5 — Reliability ordering with width-proportional bars
# ====================================================================== #

def fig5_reliability_ordering(plt, per_alpha: list[dict],
                                target_alpha: float, out_dir: Path):
    target = min(per_alpha, key=lambda a: abs(a["alpha_high"] - target_alpha))
    n_test = target["n_test"]

    rows = []
    e = target["emit"]
    rows.append(("EMIT", e["n"], e["accuracy"], COLORS["tertiary"]))
    for s in ESCALATE_SOURCES:
        es = target["by_source"][s]
        if es["n"] == 0: continue
        rows.append((SHORT_SRC[s], es["n"], es["would_be_accuracy"],
                     COLORS["secondary"]))

    fig, ax = plt.subplots(figsize=(5.0, 3.2))
    total_n = sum(r[1] for r in rows)

    n_bars = len(rows)
    gap = 0.04
    available = 1.0 - 2 * 0.06 - (n_bars - 1) * gap
    raw_widths = [r[1] / total_n for r in rows]
    min_w = 0.10
    widths_unscaled = [max(w, min_w) for w in raw_widths]
    scale = available / sum(widths_unscaled)
    widths = [w * scale for w in widths_unscaled]

    centers = []
    cursor = 0.06
    for i, w in enumerate(widths):
        centers.append(cursor + w / 2)
        cursor += w + (gap if i < n_bars - 1 else 0)

    for (label, n, acc, color), c, w in zip(rows, centers, widths):
        ax.bar(c, acc, width=w, color=color,
               edgecolor="#333333", linewidth=0.7, zorder=3)
        share_pct = 100 * n / n_test
        ax.text(c, acc + 0.025,
                f"n={n}", ha="center", va="bottom",
                fontsize=8.5, fontweight="bold")
        ax.text(c, -0.05, label, ha="center", va="top",
                fontsize=9, fontweight="bold",
                transform=ax.get_xaxis_transform())
        ax.text(c, -0.13, f"{share_pct:.0f}% of test",
                ha="center", va="top", fontsize=7.5,
                color="#555555", style="italic",
                transform=ax.get_xaxis_transform())

    ax.axhline(y=0.672, color=COLORS["neutral"], linestyle="--",
               linewidth=0.8, alpha=0.7, zorder=2)
    ax.text(0.98, 0.692, "K=4 unconditional (0.67)",
            ha="right", va="bottom", fontsize=7.5,
            color=COLORS["neutral"])

    ax.set_xlim(0, 1.0)
    ax.set_xticks([])
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Accuracy on test")
    ax.grid(True, axis="y", alpha=0.4, zorder=1)
    ax.set_title(rf"Reliability ordering and coverage share "
                 rf"($\alpha_h={target['alpha_high']:.2f}$)",
                 pad=10)

    fig.subplots_adjust(bottom=0.20)
    out = out_dir / "fig5_reliability_ordering.pdf"
    fig.savefig(out)
    plt.close(fig)
    logger.info("Wrote %s", out)


# ====================================================================== #
# Fig 6 — Escalation source × class composition
# ====================================================================== #

def fig6_escalation_class_composition(plt, per_alpha: list[dict],
                                        target_alpha: float, out_dir: Path):
    target = min(per_alpha, key=lambda a: abs(a["alpha_high"] - target_alpha))

    sources = []
    counts_per_source = []
    for s in ESCALATE_SOURCES:
        es = target["by_source"][s]
        if es["n"] == 0: continue
        sources.append(SHORT_SRC[s])
        counts = []
        for cls in CLASSES:
            counts.append(es["per_class"].get(cls, {"n": 0})["n"])
        counts_per_source.append(counts)

    if not sources:
        logger.warning("No escalation sources at this alpha; skipping fig6")
        return

    counts_arr = np.array(counts_per_source)

    fig, ax = plt.subplots(figsize=(4.0, 2.7))
    x = np.arange(len(sources))
    width = 0.65
    bottom = np.zeros(len(sources))
    for c, cls in enumerate(CLASSES):
        vals = counts_arr[:, c]
        bars = ax.bar(x, vals, width, bottom=bottom,
                      color=CLASS_COLORS[cls],
                      edgecolor="#333333", linewidth=0.4,
                      label=SHORT_CLASS[cls], zorder=3)
        for bar, v, b in zip(bars, vals, bottom):
            if v > 0:
                ax.text(bar.get_x() + bar.get_width() / 2,
                        b + v / 2,
                        str(int(v)), ha="center", va="center",
                        fontsize=7, color="white", fontweight="bold")
        bottom = bottom + vals

    for xi, total in zip(x, counts_arr.sum(axis=1)):
        ax.text(xi, total + 0.4,
                f"n={int(total)}",
                ha="center", va="bottom", fontsize=8, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(sources, fontsize=9, fontweight="bold")
    ax.set_ylabel("Escalated items")
    y_max = max(2, int(counts_arr.sum(axis=1).max() * 1.45))
    ax.set_ylim(0, y_max)
    ax.grid(True, axis="y", alpha=0.4, zorder=1)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.18),
              ncol=4, frameon=True, fontsize=7.5,
              fancybox=False, edgecolor="#cccccc")
    ax.set_title(rf"Escalation source $\times$ class composition "
                 rf"($\alpha_h={target['alpha_high']:.2f}$)",
                 pad=8)

    fig.subplots_adjust(bottom=0.25)
    out = out_dir / "fig6_escalation_class_composition.pdf"
    fig.savefig(out)
    plt.close(fig)
    logger.info("Wrote %s", out)


# ====================================================================== #
# Main
# ====================================================================== #

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results", type=Path)
    ap.add_argument("--data-dir", default="data", type=Path)
    ap.add_argument("--k4-dir", default="exp_C_K4")
    ap.add_argument("--diagnostic-json", default=None)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--target-alpha", type=float, default=0.30)
    args = ap.parse_args()

    out_dir = Path(args.out_dir or (args.results_dir / "paper_figures"))
    out_dir.mkdir(parents=True, exist_ok=True)

    diag_path = Path(args.diagnostic_json or (
        args.results_dir / "simplified_diagnostic" / "diagnostic_full.json"
    ))
    if not diag_path.exists():
        logger.error("diagnostic_full.json not found at %s. Run "
                     "scripts/20_simplified_diagnostic.py first.", diag_path)
        return 1

    plt = setup_matplotlib()
    per_alpha = json.loads(diag_path.read_text())

    # Load test scores and modules for figure 4
    k4_dir = args.results_dir / args.k4_dir
    test_scores = np.load(k4_dir / "test_scores.npy")
    cs_dict = json.loads((k4_dir / "calibration_scores.json").read_text())
    modules = list(cs_dict)

    fig1_risk_coverage_curve(plt, per_alpha, out_dir)
    fig2_headline_metrics(plt, per_alpha, out_dir)
    fig3_per_class_recall_heatmap(plt, per_alpha, args.target_alpha, out_dir)
    fig4_score_signatures(plt, per_alpha, args.target_alpha,
                           test_scores, modules, out_dir)
    fig5_reliability_ordering(plt, per_alpha, args.target_alpha, out_dir)
    fig6_escalation_class_composition(plt, per_alpha, args.target_alpha, out_dir)

    logger.info("All six figures written to %s", out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
