# Per-item signals for ESCALATE-MULTIPLE

For every item attributed to ESCALATE-MULTIPLE, the per-module signals that triggered the escalation. Each row reports: item index, gold class, and the calibration-rank (or score) of each module, with a flag if the module was in its tail.


Format: `[item_idx]` gold_class | M1: rank_or_score (in_tail) | M2: ... | M3: ... | M4: ...


## α_h = 0.20  (n=13)

- `[  3]` Refuted  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.98 ★  |  M4: s=1.00 ★
- `[ 10]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.28   |  M4: s=1.00 ★
- `[ 21]` Not Enough Evidence  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 22]` Refuted  |  M1: r=0.77 ★  |  M2: r=0.34   |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 26]` Refuted  |  M1: r=0.46   |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 29]` Refuted  |  M1: r=0.75 ★  |  M2: r=0.56   |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 30]` Not Enough Evidence  |  M1: r=1.00 ★  |  M2: r=1.00 ★  |  M3: r=0.00   |  M4: s=1.00 ★
- `[ 32]` Refuted  |  M1: r=0.85 ★  |  M2: r=1.00 ★  |  M3: r=0.16   |  M4: s=1.00 ★
- `[ 37]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.15   |  M4: s=1.00 ★
- `[ 40]` Not Enough Evidence  |  M1: r=0.97 ★  |  M2: r=1.00 ★  |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 51]` Supported  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.57   |  M4: s=1.00 ★
- `[ 52]` Conflicting Evidence/Cherrypicking  |  M1: r=0.70 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 57]` Refuted  |  M1: r=0.82 ★  |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★

## α_h = 0.25  (n=13)

- `[  3]` Refuted  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.98 ★  |  M4: s=1.00 ★
- `[ 10]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.28   |  M4: s=1.00 ★
- `[ 21]` Not Enough Evidence  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 22]` Refuted  |  M1: r=0.77 ★  |  M2: r=0.34   |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 26]` Refuted  |  M1: r=0.46   |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 29]` Refuted  |  M1: r=0.75 ★  |  M2: r=0.56   |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 30]` Not Enough Evidence  |  M1: r=1.00 ★  |  M2: r=1.00 ★  |  M3: r=0.00   |  M4: s=1.00 ★
- `[ 32]` Refuted  |  M1: r=0.85 ★  |  M2: r=1.00 ★  |  M3: r=0.16   |  M4: s=1.00 ★
- `[ 37]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.15   |  M4: s=1.00 ★
- `[ 40]` Not Enough Evidence  |  M1: r=0.97 ★  |  M2: r=1.00 ★  |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 51]` Supported  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.57   |  M4: s=1.00 ★
- `[ 52]` Conflicting Evidence/Cherrypicking  |  M1: r=0.70 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 57]` Refuted  |  M1: r=0.82 ★  |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★

## α_h = 0.30  (n=13)

- `[  3]` Refuted  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.98 ★  |  M4: s=1.00 ★
- `[ 10]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.28   |  M4: s=1.00 ★
- `[ 21]` Not Enough Evidence  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 22]` Refuted  |  M1: r=0.77 ★  |  M2: r=0.34   |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 26]` Refuted  |  M1: r=0.46   |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 29]` Refuted  |  M1: r=0.75 ★  |  M2: r=0.56   |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 30]` Not Enough Evidence  |  M1: r=1.00 ★  |  M2: r=1.00 ★  |  M3: r=0.00   |  M4: s=1.00 ★
- `[ 32]` Refuted  |  M1: r=0.85 ★  |  M2: r=1.00 ★  |  M3: r=0.16   |  M4: s=1.00 ★
- `[ 37]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.15   |  M4: s=1.00 ★
- `[ 40]` Not Enough Evidence  |  M1: r=0.97 ★  |  M2: r=1.00 ★  |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 51]` Supported  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.57   |  M4: s=1.00 ★
- `[ 52]` Conflicting Evidence/Cherrypicking  |  M1: r=0.70 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 57]` Refuted  |  M1: r=0.82 ★  |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★

## α_h = 0.35  (n=12)

- `[  3]` Refuted  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.98 ★  |  M4: s=1.00 ★
- `[ 10]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.28   |  M4: s=1.00 ★
- `[ 21]` Not Enough Evidence  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 26]` Refuted  |  M1: r=0.46   |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★
- `[ 29]` Refuted  |  M1: r=0.75 ★  |  M2: r=0.56   |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 30]` Not Enough Evidence  |  M1: r=1.00 ★  |  M2: r=1.00 ★  |  M3: r=0.00   |  M4: s=1.00 ★
- `[ 32]` Refuted  |  M1: r=0.85 ★  |  M2: r=1.00 ★  |  M3: r=0.16   |  M4: s=1.00 ★
- `[ 37]` Refuted  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.15   |  M4: s=1.00 ★
- `[ 40]` Not Enough Evidence  |  M1: r=0.97 ★  |  M2: r=1.00 ★  |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 51]` Supported  |  M1: r=0.75 ★  |  M2: r=1.00 ★  |  M3: r=0.57   |  M4: s=1.00 ★
- `[ 52]` Conflicting Evidence/Cherrypicking  |  M1: r=0.70 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 57]` Refuted  |  M1: r=0.82 ★  |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★

## α_h = 0.40  (n=5)

- `[  3]` Refuted  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.98 ★  |  M4: s=1.00 ★
- `[ 21]` Not Enough Evidence  |  M1: r=0.87 ★  |  M2: r=1.00 ★  |  M3: r=0.38   |  M4: s=1.00 ★
- `[ 30]` Not Enough Evidence  |  M1: r=1.00 ★  |  M2: r=1.00 ★  |  M3: r=0.00   |  M4: s=1.00 ★
- `[ 40]` Not Enough Evidence  |  M1: r=0.97 ★  |  M2: r=1.00 ★  |  M3: r=0.85 ★  |  M4: s=1.00 ★
- `[ 57]` Refuted  |  M1: r=0.82 ★  |  M2: r=1.00 ★  |  M3: r=0.93 ★  |  M4: s=1.00 ★
