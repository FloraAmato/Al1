# Attribution validity: would-have-been K=4 accuracy per source

If the framework attributes correctly, items in each escalation source should be harder than the unconditional pipeline (K=4 = 0.67 on this test set). Sources well below 0.67 are well-targeted; sources at or above 0.67 are over-cautious — the diagnostic flagged items the verifier would have gotten right.


| α_h | RETR (n; acc) | READER (n; acc) | VERIF (n; acc) | MULTI (n; acc) |
|-----|----------------|------------------|------------------|------------------|
| 0.20 | 6; 0.33 | — | — | 13; 0.46 |
| 0.25 | 6; 0.33 | — | — | 13; 0.46 |
| 0.30 | 6; 0.33 | — | — | 13; 0.46 |
| 0.35 | 5; 0.40 | — | — | 12; 0.50 |
| 0.40 | — | — | — | 5; 0.40 |
