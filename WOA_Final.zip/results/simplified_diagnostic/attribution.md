# Escalation source attribution across α sweep

Each escalated item is attributed to one of four sources. Cells show: count (% of escalations).


| α_h | Total esc | RETR | READER | VERIF | MULTI |
|-----|-----------|------|--------|-------|-------|
| 0.20 | 19 | 6 (32%) | 0 | 0 | 13 (68%) |
| 0.25 | 19 | 6 (32%) | 0 | 0 | 13 (68%) |
| 0.30 | 19 | 6 (32%) | 0 | 0 | 13 (68%) |
| 0.35 | 17 | 5 (29%) | 0 | 0 | 12 (71%) |
| 0.40 | 5 | 0 | 0 | 0 | 5 (100%) |
