# Per-class breakdown for EMIT and each ESCALATE source

For each α and each decision (EMIT / ESCALATE-source), per-gold-class {n, correct, wrong, accuracy}. EMIT row uses actual K=4 verdict accuracy; ESCALATE rows use would-have-been K=4 accuracy.


## α_high = 0.20

### EMIT
  n = 42 (69%), accuracy = 0.786

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 13 | 12 | 1 | 0.923 |
| Refuted | 25 | 21 | 4 | 0.840 |
| Not Enough Evidence | 1 | 0 | 1 | 0.000 |
| Conflicting Evidence/Cherrypicking | 3 | 0 | 3 | 0.000 |

### ESCALATE-RETRIEVAL
  n = 6 (10% of test, 32% of escalations), would-be accuracy = 0.333

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 1 | 0 | 1.000 |
| Refuted | 4 | 1 | 3 | 0.250 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

### ESCALATE-MULTIPLE
  n = 13 (21% of test, 68% of escalations), would-be accuracy = 0.462

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 0 | 1 | 0.000 |
| Refuted | 8 | 4 | 4 | 0.500 |
| Not Enough Evidence | 3 | 2 | 1 | 0.667 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

## α_high = 0.25

### EMIT
  n = 42 (69%), accuracy = 0.786

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 13 | 12 | 1 | 0.923 |
| Refuted | 25 | 21 | 4 | 0.840 |
| Not Enough Evidence | 1 | 0 | 1 | 0.000 |
| Conflicting Evidence/Cherrypicking | 3 | 0 | 3 | 0.000 |

### ESCALATE-RETRIEVAL
  n = 6 (10% of test, 32% of escalations), would-be accuracy = 0.333

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 1 | 0 | 1.000 |
| Refuted | 4 | 1 | 3 | 0.250 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

### ESCALATE-MULTIPLE
  n = 13 (21% of test, 68% of escalations), would-be accuracy = 0.462

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 0 | 1 | 0.000 |
| Refuted | 8 | 4 | 4 | 0.500 |
| Not Enough Evidence | 3 | 2 | 1 | 0.667 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

## α_high = 0.30

### EMIT
  n = 42 (69%), accuracy = 0.786

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 13 | 12 | 1 | 0.923 |
| Refuted | 25 | 21 | 4 | 0.840 |
| Not Enough Evidence | 1 | 0 | 1 | 0.000 |
| Conflicting Evidence/Cherrypicking | 3 | 0 | 3 | 0.000 |

### ESCALATE-RETRIEVAL
  n = 6 (10% of test, 32% of escalations), would-be accuracy = 0.333

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 1 | 0 | 1.000 |
| Refuted | 4 | 1 | 3 | 0.250 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

### ESCALATE-MULTIPLE
  n = 13 (21% of test, 68% of escalations), would-be accuracy = 0.462

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 0 | 1 | 0.000 |
| Refuted | 8 | 4 | 4 | 0.500 |
| Not Enough Evidence | 3 | 2 | 1 | 0.667 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

## α_high = 0.35

### EMIT
  n = 44 (72%), accuracy = 0.750

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 13 | 12 | 1 | 0.923 |
| Refuted | 27 | 21 | 6 | 0.778 |
| Not Enough Evidence | 1 | 0 | 1 | 0.000 |
| Conflicting Evidence/Cherrypicking | 3 | 0 | 3 | 0.000 |

### ESCALATE-RETRIEVAL
  n = 5 (8% of test, 29% of escalations), would-be accuracy = 0.400

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 1 | 0 | 1.000 |
| Refuted | 3 | 1 | 2 | 0.333 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

### ESCALATE-MULTIPLE
  n = 12 (20% of test, 71% of escalations), would-be accuracy = 0.500

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 1 | 0 | 1 | 0.000 |
| Refuted | 7 | 4 | 3 | 0.571 |
| Not Enough Evidence | 3 | 2 | 1 | 0.667 |
| Conflicting Evidence/Cherrypicking | 1 | 0 | 1 | 0.000 |

## α_high = 0.40

### EMIT
  n = 56 (92%), accuracy = 0.696

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Supported | 15 | 13 | 2 | 0.867 |
| Refuted | 35 | 26 | 9 | 0.743 |
| Not Enough Evidence | 1 | 0 | 1 | 0.000 |
| Conflicting Evidence/Cherrypicking | 5 | 0 | 5 | 0.000 |

### ESCALATE-MULTIPLE
  n = 5 (8% of test, 100% of escalations), would-be accuracy = 0.400

| Class | n | correct | wrong | accuracy |
|-------|---|---------|-------|----------|
| Refuted | 2 | 0 | 2 | 0.000 |
| Not Enough Evidence | 3 | 2 | 1 | 0.667 |
