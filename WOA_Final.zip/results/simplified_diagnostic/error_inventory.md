# Error inventory: items the framework EMITted but got wrong

For each α, the test items the framework chose to emit a verdict for, but the verdict was wrong (verifier modal != gold). Format: `[item_idx]` gold_class


## α_h = 0.20  (9 errors of 42)


**Supported** (1)
  - `[ 55]`

**Refuted** (4)
  - `[ 43]`
  - `[ 47]`
  - `[ 59]`
  - `[  6]`

**Not Enough Evidence** (1)
  - `[  7]`

**Conflicting Evidence/Cherrypicking** (3)
  - `[  1]`
  - `[ 15]`
  - `[ 31]`

## α_h = 0.25  (9 errors of 42)


**Supported** (1)
  - `[ 55]`

**Refuted** (4)
  - `[ 43]`
  - `[ 47]`
  - `[ 59]`
  - `[  6]`

**Not Enough Evidence** (1)
  - `[  7]`

**Conflicting Evidence/Cherrypicking** (3)
  - `[  1]`
  - `[ 15]`
  - `[ 31]`

## α_h = 0.30  (9 errors of 42)


**Supported** (1)
  - `[ 55]`

**Refuted** (4)
  - `[ 43]`
  - `[ 47]`
  - `[ 59]`
  - `[  6]`

**Not Enough Evidence** (1)
  - `[  7]`

**Conflicting Evidence/Cherrypicking** (3)
  - `[  1]`
  - `[ 31]`
  - `[ 15]`

## α_h = 0.35  (11 errors of 44)


**Supported** (1)
  - `[ 55]`

**Refuted** (6)
  - `[ 43]`
  - `[  9]`
  - `[ 22]`
  - `[ 47]`
  - `[ 59]`
  - `[  6]`

**Not Enough Evidence** (1)
  - `[  7]`

**Conflicting Evidence/Cherrypicking** (3)
  - `[  1]`
  - `[ 31]`
  - `[ 15]`

## α_h = 0.40  (17 errors of 56)


**Supported** (2)
  - `[ 51]`
  - `[ 55]`

**Refuted** (9)
  - `[ 43]`
  - `[ 47]`
  - `[  6]`
  - `[  9]`
  - `[ 22]`
  - `[ 24]`
  - `[ 29]`
  - `[ 33]`
  - `[ 59]`

**Not Enough Evidence** (1)
  - `[  7]`

**Conflicting Evidence/Cherrypicking** (5)
  - `[  1]`
  - `[ 31]`
  - `[ 15]`
  - `[ 52]`
  - `[ 56]`
