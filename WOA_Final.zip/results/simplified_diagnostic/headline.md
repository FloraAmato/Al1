# Headline trade-off across α sweep

Two top-level decisions per item: EMIT (commit to K=4 verdict) or ESCALATE (route to human review). Beyond aggregate accuracy we report two complementary metrics:

- **Binary-decision F1** treats the framework's emit-or-escalate choice as a binary classifier whose target is `should-emit` (K=4 verdict would have been correct). High F1 means the framework's emit decision aligns well with what would have been correct to emit.

- **Macro recall on EMIT** averages per-class recall across the four AVeriTeC verdicts on the EMITted subset. Aggregate accuracy is dominated by the majority class (Refuted, 61% of test); macro recall exposes systematic class collapse — when it is much lower than aggregate accuracy, the framework is failing minority classes.


| α_h | Cov | Acc EMIT | MacroRec EMIT | Esc% | Acc(esc) | Bin-F1 | Bin-Prec | Bin-Rec |
|-----|-----|----------|---------------|------|----------|--------|----------|---------|
| 0.20 | 69% | 0.79 | 0.44 | 31% | 0.42 | 0.80 | 0.79 | 0.80 |
| 0.25 | 69% | 0.79 | 0.44 | 31% | 0.42 | 0.80 | 0.79 | 0.80 |
| 0.30 | 69% | 0.79 | 0.44 | 31% | 0.42 | 0.80 | 0.79 | 0.80 |
| 0.35 | 72% | 0.75 | 0.43 | 28% | 0.47 | 0.78 | 0.75 | 0.80 |
| 0.40 | 92% | 0.70 | 0.40 | 8% | 0.40 | 0.80 | 0.70 | 0.95 |
