# Per-class effect of Mondrian-M3 filter

For each α, per-class breakdown showing whether the within-stratum M3 filter catches the minority-class EMIT errors. Each row reports: items in EMIT baseline, items still in EMIT after Mondrian filter, items diverted to ESCALATE-MONDRIAN-M3.


## α = 0.20

| Class | EMIT base (correct/n) | EMIT after (correct/n) | Mondrian-flag (correct/n) |
|-------|------------------------|-------------------------|----------------------------|
| Supported | 12/13 | 10/11 | 2/2 |
| Refuted | 21/25 | 18/22 | 3/3 |
| Not Enough Evidence | 0/1 | 0/1 | — |
| Conflicting Evidence/Cherrypicking | 0/3 | 0/1 | 0/2 |

## α = 0.25

| Class | EMIT base (correct/n) | EMIT after (correct/n) | Mondrian-flag (correct/n) |
|-------|------------------------|-------------------------|----------------------------|
| Supported | 12/13 | 10/11 | 2/2 |
| Refuted | 21/25 | 18/22 | 3/3 |
| Not Enough Evidence | 0/1 | 0/1 | — |
| Conflicting Evidence/Cherrypicking | 0/3 | 0/1 | 0/2 |

## α = 0.30

| Class | EMIT base (correct/n) | EMIT after (correct/n) | Mondrian-flag (correct/n) |
|-------|------------------------|-------------------------|----------------------------|
| Supported | 12/13 | 10/11 | 2/2 |
| Refuted | 21/25 | 18/22 | 3/3 |
| Not Enough Evidence | 0/1 | 0/1 | — |
| Conflicting Evidence/Cherrypicking | 0/3 | 0/1 | 0/2 |

## α = 0.35

| Class | EMIT base (correct/n) | EMIT after (correct/n) | Mondrian-flag (correct/n) |
|-------|------------------------|-------------------------|----------------------------|
| Supported | 12/13 | 10/11 | 2/2 |
| Refuted | 21/27 | 18/23 | 3/4 |
| Not Enough Evidence | 0/1 | 0/1 | — |
| Conflicting Evidence/Cherrypicking | 0/3 | 0/1 | 0/2 |

## α = 0.40

| Class | EMIT base (correct/n) | EMIT after (correct/n) | Mondrian-flag (correct/n) |
|-------|------------------------|-------------------------|----------------------------|
| Supported | 13/15 | 10/12 | 3/3 |
| Refuted | 26/35 | 21/28 | 5/7 |
| Not Enough Evidence | 0/1 | 0/1 | — |
| Conflicting Evidence/Cherrypicking | 0/5 | 0/3 | 0/2 |
