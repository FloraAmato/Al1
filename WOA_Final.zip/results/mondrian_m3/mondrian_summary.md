# Score-stratum Mondrian conformal — summary

Stratify calibration by verifier saturation: Stratum A (M4 ≥ 1.0, the saturated case) and Stratum B (M4 < 1.0, the unsaturated case). Within each stratum, calibrate a conformal threshold on M3 (reader) score at level α with bootstrap 90% CI (1000 resamples). The new ESCALATE-MONDRIAN-M3 category catches EMIT items whose M3 score exceeds the within-stratum threshold.


Stratum sizes: A=53 cal, B=8 cal.

| α | τ_A point | τ_A 90% CI | τ_B point | τ_B 90% CI | EMIT base (n; acc) | EMIT after (n; acc) | Mondrian-flag (n; would-be) |
|---|-----------|------------|-----------|------------|--------------------|---------------------|------------------------------|
| 0.20 | 0.122 | [0.108, 0.140] | 0.110 | [0.102, 0.220] | 42; 0.786 | 35; 0.800 | 7; 0.714 |
| 0.25 | 0.115 | [0.105, 0.132] | 0.110 | [0.098, 0.220] | 42; 0.786 | 35; 0.800 | 7; 0.714 |
| 0.30 | 0.109 | [0.100, 0.122] | 0.109 | [0.095, 0.209] | 42; 0.786 | 35; 0.800 | 7; 0.714 |
| 0.35 | 0.105 | [0.096, 0.115] | 0.108 | [0.094, 0.169] | 44; 0.750 | 36; 0.778 | 8; 0.625 |
| 0.40 | 0.102 | [0.094, 0.110] | 0.107 | [0.093, 0.129] | 56; 0.696 | 44; 0.705 | 12; 0.667 |
