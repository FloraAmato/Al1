# Cascading-deferral routing summary (K=4 AVeriTeC with K=3 fallback)

Each test item is assigned to exactly one operational category. HIGH/MODERATE-CONFIDENCE items receive a verdict from the K=4 pipeline. ROUTE-TO-SKIP-READER items receive a verdict from the K=3 fallback pipeline. ESCALATE categories are passed to human review. The headline coverage is the fraction of test items receiving any verdict; accuracy among answered is the empirical fraction of those verdicts that match gold.

| α_high | α_mod | Coverage | Acc. answered | HIGH | MOD | ROUTE-READER (Δ acc) | ROUTE-DECOMP | ESC-RETR | ESC-MULTI | ESC-VER |
|--------|-------|----------|---------------|------|-----|----------------------|--------------|----------|-----------|---------|
| 0.20 | 0.30 | 20% | 0.67 | 0 | 6 | 6 (+0.00) | 8 | 6 | 13 | 22 |
| 0.25 | 0.35 | 28% | 0.76 | 0 | 11 | 6 (+0.00) | 8 | 6 | 13 | 17 |
| 0.30 | 0.40 | 36% | 0.77 | 6 | 12 | 4 (+0.00) | 7 | 6 | 13 | 13 |
| 0.35 | 0.45 | 48% | 0.72 | 11 | 14 | 4 (+0.00) | 4 | 5 | 12 | 11 |
| 0.40 | 0.50 | 92% | 0.70 | 18 | 38 | 0 | 0 | 0 | 5 | 0 |
