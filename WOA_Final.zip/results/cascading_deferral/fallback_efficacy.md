# Fallback efficacy: K=4 vs K=3 outcomes on ROUTE-TO-SKIP-READER items

Items where the K=4 diagnostic identified the reader (M3) as the source of uncertainty. The K=4 pipeline would have emitted a verdict from the full pipeline; the cascading framework instead routes these items to the K=3 (no-reader) pipeline. The comparison below shows the K=4 verdict accuracy that would have been emitted versus the K=3 verdict accuracy actually emitted.

| α_high | α_mod | n routed | K=4 acc on routed | K=3 acc on routed | Δ (K=3 - K=4) |
|--------|-------|----------|-------------------|-------------------|---------------|
| 0.20 | 0.30 | 6 | 0.667 | 0.667 | +0.000 |
| 0.25 | 0.35 | 6 | 0.667 | 0.667 | +0.000 |
| 0.30 | 0.40 | 4 | 0.750 | 0.750 | +0.000 |
| 0.35 | 0.45 | 4 | 0.750 | 0.750 | +0.000 |
| 0.40 | 0.50 | 0 | — | — | — |
