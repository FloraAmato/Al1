# Cascading-deferral framework — simplified emit-or-escalate package

Self-contained reproducibility package for the simplified two-decision
framework: EMIT a verdict, or ESCALATE to human review with attribution
of the source of uncertainty.

## What this framework does

For each input the framework decides one of two things:

  EMIT       → emit the K=4 verifier's modal verdict
  ESCALATE   → decline to predict; route to human review
                with one of four attribution sources:
                  ESCALATE-RETRIEVAL  → retriever non-conformant
                  ESCALATE-READER     → reader non-conformant
                  ESCALATE-VERIFIER   → upstream OK, verifier disagreed
                  ESCALATE-MULTIPLE   → ≥2 modules in tail; per-item
                                         signals reported

(The decomposer is intentionally not used as an attribution source on
this benchmark — its tail signal does not predict K=4 verdict failure.)

## Contents

```
src/conformal_agentic_rag/         minimal Python package
configs/                            pipeline config
data/                               corpus + 500-item dataset
results/
  exp_C_K4/                         K=4 pipeline data (complete)
  exp_B_K3/                         K=3 fallback data
                                    (calibration_correct.npy missing → Step 1)
scripts/
  recover_calibration_correct_K3.py one-time GPU recovery (~1.5h)
  14_cascading_deferral.py          per-item categorisation (CPU)
  20_simplified_diagnostic.py       emit-or-escalate diagnostic (CPU)
  23_paper_plots_v3.py            six paper-ready figures (CPU)
  24_emit_escalate_mix.py         emit-vs-escalate stacked bars across α (CPU)
  25_module_signatures_sweep.py   per-module score distributions across α
                                   with per-α metrics overlay (CPU)
pyproject.toml + requirements.txt   package metadata
README.md                           this file
```

## One-time setup

```powershell
cd <path-to-this-package>
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install -e .

# Ollama models (needed only for Step 1)
ollama pull llama3.2:3b
ollama pull nomic-embed-text
ollama pull llama3.1:8b-instruct-q4_K_M
ollama pull qwen2.5:14b
```

## Workflow

Four steps. Step 1 is a one-time GPU recovery; the rest are CPU-only and
run in seconds.

### Step 1: K=3 calibration recovery (~1.5 hours GPU, one-time)

```powershell
python scripts/recover_calibration_correct_K3.py --config configs/default.yaml
```

Skip if you already have `results/exp_B_K3/calibration_correct.npy`.

### Step 2: per-item categorisation (~5 seconds CPU)

```powershell
python scripts/14_cascading_deferral.py --results-dir results
```

Produces `results/cascading_deferral/cascading_summary.json` which
contains the per-item category assignments per α.

### Step 3: simplified emit-or-escalate diagnostic (~5 seconds CPU)

```powershell
python scripts/20_simplified_diagnostic.py --results-dir results --data-dir data
```

Produces `results/simplified_diagnostic/`:

  headline.{tex,md}                 coverage and accuracy across α sweep
  attribution.{tex,md}              escalation source distribution per α
  attribution_validity.{tex,md}     per-source would-have-been accuracy
  per_class_per_decision.{tex,md}   per-class breakdown for every decision
  multiple_signals.md               per-item signals for ESCALATE-MULTIPLE
  error_inventory.md                wrong-emit items per α, by gold class
  diagnostic_full.json              machine-readable full output

### Step 4: paper-ready figures (~5 seconds CPU)

```powershell
python scripts/23_paper_plots_v3.py --results-dir results
python scripts/24_emit_escalate_mix.py --results-dir results
python scripts/25_module_signatures_sweep.py --results-dir results
```

Produces `results/paper_figures/`:

  fig1_risk_coverage_curve.pdf          Selective-prediction canonical view:
                                         conditional risk vs coverage
  fig2_headline_metrics.pdf             Per-α grouped bars: accuracy,
                                         macro-recall, binary-decision F1
  fig3_per_class_recall_heatmap.pdf     Per-class recall heatmap
                                         (decision × class) with macro
                                         recall annotated per row
  fig4_score_signatures.pdf             Degeneration diagnostic:
                                         per-module score distributions
                                         on EMIT vs ESCALATE items
  fig5_reliability_ordering.pdf         Per-decision accuracy with
                                         width-proportional bars
  fig6_escalation_class_composition.pdf Gold-class composition of each
                                         escalation source
  fig_emit_escalate_mix.pdf             Stacked emit/escalate decision
                                         mix across α (script 24)
  fig_module_signatures_sweep.pdf       Per-module score distributions
                                         (M1, M2, M3, M4) for each α,
                                         with per-α metrics overlay
                                         (script 25)

All figures sized for CEUR single-column layout (3.5–6 inches wide,
7 inches for the multi-bar figure), with vector text and consistent
styling.

## All four steps with logging

```powershell
{
    python scripts/recover_calibration_correct_K3.py --config configs/default.yaml
    python scripts/14_cascading_deferral.py --results-dir results
    python scripts/20_simplified_diagnostic.py --results-dir results --data-dir data
    python scripts/23_paper_plots_v3.py --results-dir results
    python scripts/24_emit_escalate_mix.py --results-dir results
    python scripts/25_module_signatures_sweep.py --results-dir results
} *>&1 | Tee-Object -FilePath full_pipeline.log
```

## Headline empirical findings

Across the α sweep:

```
α_h=0.20  emit=69%  acc=0.79  esc=31%
α_h=0.25  emit=69%  acc=0.79  esc=31%
α_h=0.30  emit=69%  acc=0.79  esc=31%
α_h=0.35  emit=72%  acc=0.75  esc=28%
α_h=0.40  emit=92%  acc=0.70  esc= 8%
```

The framework adds value: at strict α the system emits on 69% of items
at 79% accuracy versus the unconditional pipeline's 67%.

Escalation source attribution (α_h=0.30):

```
ESCALATE-RETRIEVAL    n=6    32% of escalations    would-be acc 0.33
ESCALATE-MULTIPLE     n=13   68% of escalations    would-be acc 0.46
ESCALATE-READER       n=0
ESCALATE-VERIFIER     n=0
```

The retriever is the primary driver of escalations on this benchmark
(alone or in combination with other modules). Items escalated under
either source have substantially lower would-have-been K=4 accuracy
than the unconditional pipeline (0.33 and 0.46 versus 0.67), validating
the diagnostic suite empirically. The reader and verifier never fire
as solo attribution sources at this rank threshold — itself a finding
worth reporting.

## Tunable hyperparameters

```powershell
python scripts/20_simplified_diagnostic.py `
  --results-dir results --data-dir data `
  --rank-thresh 0.70 `
  --verifier-thresh 0.60
```

The defaults work for AVeriTeC K=4. The rank threshold controls how
easily an upstream module enters its tail (and triggers an escalation
attribution).
