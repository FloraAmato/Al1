"""
The four pipeline modules M1..M4.

Each module implements a uniform interface:

    run(state, history) -> ModuleOutput

where ModuleOutput carries the produced output, the non-conformity score
against ground truth (computed only at calibration time), and any
auxiliary data needed for downstream modules.

The modules are deliberately instantiated with *different* Ollama models
so that the joint miscoverage distribution is not trivially identical
across modules — a necessary condition for the positive-association
diagnostic of Remark 2 to be meaningful.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

import numpy as np

from .ollama_client import OllamaClient
from .scores import (
    adaptive_prediction_set_score,
    neg_log_prob_score,
    reciprocal_rank_score,
    self_consistency_score,
    semantic_similarity_score,
)


# ========== shared dataclasses ====================================== #

@dataclass
class ModuleOutput:
    """Uniform output type produced by every pipeline module."""

    value: Any                            # module-specific output
    score: Optional[float] = None         # non-conformity score (if gold known)
    aux: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineState:
    """Aggregated state threaded through the pipeline."""

    query: str
    gold: dict[str, Any] = field(default_factory=dict)
    history: list[ModuleOutput] = field(default_factory=list)
    timings: list = field(default_factory=list)   # [(k, module_name, seconds)]


# ========== M1: Query decomposer ==================================== #

DECOMPOSE_PROMPT = """\
You are a fact-checking assistant. Given a claim, produce a list of
atomic questions that, if each answered from evidence, would collectively
let you verify or refute the claim. Output one question per line,
numbered "1.", "2.", etc. No commentary, no preamble.

Claim: {query}

Questions:
"""


class QueryDecomposer:
    """M1: decomposes a multi-hop query into single-hop sub-queries."""

    def __init__(
        self,
        client: OllamaClient,
        model: str = "llama3.2:3b",
        embedder=None,                        # callable str -> np.ndarray
    ) -> None:
        self.client = client
        self.model = model
        self.embedder = embedder

    def run(self, state: PipelineState) -> ModuleOutput:
        prompt = DECOMPOSE_PROMPT.format(query=state.query)
        resp = self.client.generate(
            model=self.model,
            prompt=prompt,
            options={"num_predict": 256, "temperature": 0.0},
        )
        sub_questions = self._parse_decomposition(resp.text)

        score: Optional[float] = None
        gold_decomposition = state.gold.get("sub_questions")
        if gold_decomposition is not None and self.embedder is not None:
            score = semantic_similarity_score(
                sub_questions, gold_decomposition, self.embedder
            )

        return ModuleOutput(
            value=sub_questions,
            score=score,
            aux={"raw_text": resp.text},
        )

    @staticmethod
    def _parse_decomposition(text: str) -> list[str]:
        out: list[str] = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            # Strip common numbering like "1.", "1)", "- "
            for prefix in ("1.", "2.", "3.", "4.", "5.", "6.", "7.", "-"):
                if line.startswith(prefix):
                    line = line[len(prefix):].strip()
                    break
            # Heuristic: drop obvious leftover numbering
            while line and line[0].isdigit():
                line = line[1:].lstrip(". )-")
            if line:
                out.append(line)
        return out


# ========== M2: Retriever =========================================== #

class HybridRetriever:
    """
    M2: hybrid dense + BM25 retriever over a document corpus.

    The corpus is a list of (doc_id, text) pairs. BM25 is computed once
    at instantiation; dense embeddings are precomputed and cached.
    """

    def __init__(
        self,
        corpus: Sequence[tuple[str, str]],
        client: OllamaClient,
        embed_model: str = "nomic-embed-text",
        dense_weight: float = 0.5,
        top_k: int = 10,
    ) -> None:
        self.doc_ids = [d[0] for d in corpus]
        self.texts = [d[1] for d in corpus]
        self.client = client
        self.embed_model = embed_model
        self.dense_weight = dense_weight
        self.top_k = top_k

        self._bm25 = self._build_bm25(self.texts)
        self._dense = self._build_dense(self.texts)

    def run(self, state: PipelineState) -> ModuleOutput:
        # The query to retrieve with is the decomposed list joined, or the raw query.
        decomposer_output = state.history[-1] if state.history else None
        if decomposer_output is not None and decomposer_output.value:
            query_text = " ".join(decomposer_output.value)
        else:
            query_text = state.query

        ranked = self._rank(query_text)
        top_ids = [self.doc_ids[i] for i in ranked[: self.top_k]]

        score: Optional[float] = None
        gold_doc_ids = state.gold.get("doc_ids")
        if gold_doc_ids is not None:
            score = reciprocal_rank_score(top_ids, gold_doc_ids)

        return ModuleOutput(
            value=top_ids,
            score=score,
            aux={"ranked_indices": ranked[: self.top_k]},
        )

    # --- internals ------------------------------------------------- #

    @staticmethod
    def _build_bm25(texts: Sequence[str]):
        """Build a BM25 index. Expects rank_bm25 to be installed."""
        try:
            from rank_bm25 import BM25Okapi
        except ImportError as exc:
            raise RuntimeError(
                "rank_bm25 is required for HybridRetriever. "
                "Install with `pip install rank_bm25`."
            ) from exc
        tokenised = [t.lower().split() for t in texts]
        return BM25Okapi(tokenised)

    def _build_dense(self, texts: Sequence[str]) -> np.ndarray:
        vecs = []
        for text in texts:
            emb = self.client.embed(self.embed_model, text).vector
            vecs.append(np.asarray(emb, dtype=float))
        matrix = np.stack(vecs)
        # Normalise for cosine similarity
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        return matrix / (norms + 1e-10)

    def _rank(self, query: str) -> list[int]:
        # BM25 scores
        bm25_scores = self._bm25.get_scores(query.lower().split())
        bm25_scores = bm25_scores / (bm25_scores.max() + 1e-10)

        # Dense cosine scores
        q_vec = np.asarray(self.client.embed(self.embed_model, query).vector)
        q_vec = q_vec / (np.linalg.norm(q_vec) + 1e-10)
        dense_scores = self._dense @ q_vec

        combined = (
            self.dense_weight * dense_scores
            + (1.0 - self.dense_weight) * bm25_scores
        )
        return list(np.argsort(-combined))


# ========== M3: Reader / Reasoner =================================== #

READ_PROMPT = """\
You are a fact-checking assistant answering a claim based on retrieved
evidence. Given the evidence passages and the claim, produce a short
summary answer (one or two sentences) stating the key facts the evidence
establishes about the claim.

Evidence:
{context}

Claim: {query}

Summary answer:"""


class ReaderReasoner:
    """M3: reads retrieved documents and produces a summary answer.

    Non-conformity score: *semantic self-consistency* across N samples.
    We generate N stochastic summaries from the same prompt and compute
    one minus the average pairwise embedding similarity. If the model
    is confident in the summary, samples cluster tightly -> low
    non-conformity. If uncertain, samples diverge -> high non-conformity.

    This score is:
      - distribution-free (no gold summary needed),
      - genuinely variable (unlike the old greedy-logprob path that
        collapses to a near-constant under temperature=0),
      - robust to Ollama's inconsistent logprob support.
    """

    def __init__(
        self,
        client: OllamaClient,
        model: str = "llama3.1:8b-instruct-q4_K_M",
        corpus_lookup: Optional[dict[str, str]] = None,
        embed_model: str = "nomic-embed-text",
        use_logprob_score: bool = False,     # kept for backward compat; now ignored
        self_consistency_n: int = 5,
        equivalence_fn=None,                  # deprecated; kept for backward compat
        max_context_docs: int = 4,
    ) -> None:
        self.client = client
        self.model = model
        self.embed_model = embed_model
        self.corpus_lookup = corpus_lookup or {}
        self.self_consistency_n = self_consistency_n
        self.max_context_docs = max_context_docs

    def run(self, state: PipelineState) -> ModuleOutput:
        retriever_output = state.history[-1]
        doc_ids = retriever_output.value
        context = self._assemble_context(doc_ids, max_docs=self.max_context_docs)
        prompt = READ_PROMPT.format(context=context, query=state.query)

        # Primary (greedy) answer for downstream M4
        primary = self.client.generate(
            model=self.model,
            prompt=prompt,
            options={"num_predict": 64, "temperature": 0.0},
        )
        answer = primary.text.strip()

        # Self-consistency samples for the score
        samples = self.client.generate_samples(
            model=self.model,
            prompt=prompt,
            n=self.self_consistency_n,
            temperature=0.7,
            num_predict=64,
        )
        sample_texts = [s.text.strip() for s in samples if s.text.strip()]

        score: Optional[float] = None
        if state.gold.get("answer") is not None:
            score = self._semantic_disagreement_score(sample_texts)

        return ModuleOutput(
            value=answer,
            score=score,
            aux={"n_samples": len(sample_texts), "prompt_len": len(prompt)},
        )

    def _semantic_disagreement_score(self, samples: list[str]) -> float:
        """1 - mean pairwise cosine similarity over N samples.

        Returns 1.0 on degenerate input (0 or 1 valid samples).
        """
        if len(samples) < 2:
            return 1.0
        try:
            embeds = np.stack([
                np.asarray(self.client.embed(self.embed_model, s).vector)
                for s in samples
            ])
        except Exception:
            return 1.0
        norms = np.linalg.norm(embeds, axis=1, keepdims=True) + 1e-10
        embeds = embeds / norms
        sim = embeds @ embeds.T
        # Mean of upper-triangular off-diagonal entries
        n = len(samples)
        iu = np.triu_indices(n, k=1)
        mean_sim = float(sim[iu].mean())
        return float(np.clip(1.0 - mean_sim, 0.0, 1.0))

    def _assemble_context(self, doc_ids: Sequence[str], max_docs: int = 5) -> str:
        chunks = []
        for doc_id in list(doc_ids)[:max_docs]:
            text = self.corpus_lookup.get(doc_id, "")
            if text:
                chunks.append(f"[{doc_id}] {text}")
        return "\n\n".join(chunks)


# ========== M4: Verifier ============================================ #

VERIFY_PROMPT = """\
You are an expert fact-checker. Given a claim and retrieved evidence,
assign ONE of these four verdict labels:

  SUPPORTED            -- the evidence clearly supports the claim
  REFUTED              -- the evidence clearly contradicts the claim
  CONFLICTING          -- the evidence both supports and refutes the claim
  NOT_ENOUGH_EVIDENCE  -- the evidence is insufficient to decide

Important guidance:
- Be decisive. Prefer SUPPORTED or REFUTED when the evidence clearly
  points one direction, even if minor details are missing.
- Only use NOT_ENOUGH_EVIDENCE when the evidence truly does not address
  the claim, not just when it is partial.
- Only use CONFLICTING when multiple evidence pieces directly disagree
  with each other on the SAME aspect of the claim.

Here are examples showing all four verdict types:

CLAIM: The Moon is a star.
EVIDENCE: According to astronomy, the Moon is a natural satellite of
Earth, not a star. Stars generate their own light via fusion.
VERDICT: REFUTED

CLAIM: Water boils at 100 degrees Celsius at sea level.
EVIDENCE: At standard atmospheric pressure (1 atm, sea level), water
boils at 100 C.
VERDICT: SUPPORTED

CLAIM: A local charity raised $50,000 at last week's gala.
EVIDENCE: General reports on charity fundraising trends in the region.
No specific gala event is mentioned.
VERDICT: NOT_ENOUGH_EVIDENCE

CLAIM: Studies show that drug X reduces symptoms by 30%.
EVIDENCE: One clinical trial reports a 35% reduction. Two other studies
find no significant effect and raise safety concerns.
VERDICT: CONFLICTING

Now verify this claim.

CLAIM: {query}

EVIDENCE:
{context}

SUMMARY FROM READER: {answer}

Think briefly, then output the verdict on the last line in this format:
VERDICT: <LABEL>

where <LABEL> is one of SUPPORTED, REFUTED, CONFLICTING, NOT_ENOUGH_EVIDENCE.
"""


# AVeriTeC's four canonical verdict labels
VERIFIER_LABELS = ("SUPPORTED", "REFUTED", "NOT_ENOUGH_EVIDENCE", "CONFLICTING")

# Tolerant parsing: normalise hyphens, slashes, whitespace, punctuation
# so that "Not enough evidence", "not-enough-evidence", "Support",
# "refute.", all map to the canonical label.
_LABEL_ALIASES: dict[str, str] = {
    "SUPPORTED": "SUPPORTED",
    "SUPPORT":   "SUPPORTED",
    "SUPPORTS":  "SUPPORTED",
    "TRUE":      "SUPPORTED",
    "REFUTED":   "REFUTED",
    "REFUTE":    "REFUTED",
    "REFUTES":   "REFUTED",
    "FALSE":     "REFUTED",
    "NOTENOUGH": "NOT_ENOUGH_EVIDENCE",
    "NOT_ENOUGH_EVIDENCE": "NOT_ENOUGH_EVIDENCE",
    "NOTENOUGHEVIDENCE":   "NOT_ENOUGH_EVIDENCE",
    "NEI":        "NOT_ENOUGH_EVIDENCE",
    "UNKNOWN":    "NOT_ENOUGH_EVIDENCE",
    "INSUFFICIENT": "NOT_ENOUGH_EVIDENCE",
    "CONFLICTING":       "CONFLICTING",
    "CONFLICT":          "CONFLICTING",
    "CONFLICTED":        "CONFLICTING",
    "MIXED":             "CONFLICTING",
    "CHERRYPICKING":     "CONFLICTING",
    "CHERRY_PICKING":    "CONFLICTING",
}


def _parse_verdict_label(text: str) -> Optional[str]:
    """Try to extract a verdict label from free-form LLM output.

    Returns one of VERIFIER_LABELS, or None if no label can be
    extracted. Strategy: first look for the ``VERDICT:`` keyword
    (the format the new prompt explicitly asks for, placed on the
    last line after optional brief reasoning). If found, parse
    only what follows it. If not found, fall back to scanning the
    whole text for a recognisable label token. The parser
    normalises hyphens, slashes, underscores and punctuation so
    that ``'not-enough-evidence'``, ``'Support\\n'``, or
    ``'VERDICT: REFUTED.'`` all map to canonical labels.
    """
    import re
    if not isinstance(text, str) or not text:
        return None

    # Strategy 1: locate the VERDICT: keyword and parse what follows.
    # We look case-insensitively and take the LAST occurrence, because
    # the prompt says "output the verdict on the last line".
    verdict_matches = list(re.finditer(r"VERDICT\s*[:\-]\s*(.*)", text, re.IGNORECASE))
    candidates = []
    if verdict_matches:
        tail = verdict_matches[-1].group(1)
        candidates.append(tail)
    # Strategy 2 (fallback): parse the whole text
    candidates.append(text)

    for candidate in candidates:
        # Normalise: uppercase, collapse whitespace/hyphens/slashes to _
        t = candidate.upper()
        t = t.replace("-", "_").replace("/", "_").replace(" ", "_")
        t = re.sub(r"[^A-Z_]", "", t)
        if not t:
            continue
        # Direct canonical match on whole string
        for canonical in VERIFIER_LABELS:
            if canonical in t:
                return canonical
        # Token-level alias match
        tokens = [tok for tok in t.split("_") if tok]
        joined = "".join(tokens)
        for alias, canonical in _LABEL_ALIASES.items():
            if alias in joined:
                return canonical
        for tok in tokens:
            if tok in _LABEL_ALIASES:
                return _LABEL_ALIASES[tok]
    return None


# Map between upper-case shortcuts (as predicted by the verifier LLM) and
# canonical AVeriTeC labels (as stored in the dataset's `answer` field).
_VERIFIER_TO_AVERITEC = {
    "SUPPORTED": "Supported",
    "REFUTED": "Refuted",
    "NOT_ENOUGH_EVIDENCE": "Not Enough Evidence",
    "CONFLICTING": "Conflicting Evidence/Cherrypicking",
}
_AVERITEC_TO_VERIFIER = {v: k for k, v in _VERIFIER_TO_AVERITEC.items()}


def verifier_label_to_averitec(label: str) -> str:
    """Map one of VERIFIER_LABELS to the canonical AVeriTeC label."""
    return _VERIFIER_TO_AVERITEC.get(label, "Supported")


def averitec_label_to_verifier(label: str) -> str:
    """Map a canonical AVeriTeC label to one of VERIFIER_LABELS."""
    return _AVERITEC_TO_VERIFIER.get(label, "SUPPORTED")


class Verifier:
    """M4: verifies the reader's answer and returns a calibrated label.

    Parsing strategy: each LLM sample is passed through
    :func:`_parse_verdict_label`, which normalises case, punctuation
    and whitespace and matches the output against a dictionary of
    canonical labels plus known aliases. Samples that cannot be
    parsed to any label are dropped from the probability estimate
    rather than being silently miscounted.

    Score function: configurable via the ``score_fn`` argument. The
    default is APS, matching the original paper. Pass
    ``score_fn="disagreement_rate"`` to use the granular alternative
    introduced in Section 6 of the paper. The raw per-sample label
    counts are always recorded in ``aux["label_counts"]`` so that
    alternative scores can be computed post-hoc from saved runs
    without re-running inference.
    """

    def __init__(
        self,
        client: OllamaClient,
        model: str = "qwen2.5:14b",
        corpus_lookup: Optional[dict[str, str]] = None,
        n_samples: int = 10,                  # for black-box probability estimation
        score_fn: str = "aps",                # "aps" | "disagreement_rate" | "margin"
    ) -> None:
        self.client = client
        self.model = model
        self.corpus_lookup = corpus_lookup or {}
        self.n_samples = n_samples
        if score_fn not in ("aps", "disagreement_rate", "margin"):
            raise ValueError(
                f"score_fn must be one of 'aps', 'disagreement_rate', "
                f"'margin'; got {score_fn!r}"
            )
        self.score_fn = score_fn

    def run(self, state: PipelineState) -> ModuleOutput:
        # Find the retriever's output (list of doc_ids) and, optionally,
        # the reader's summary. The pipeline ablations (Exp A: M2+M4;
        # Exp B: M1+M2+M4) may omit the reader, in which case the verifier
        # operates on the raw retrieved evidence without an intermediate
        # synthesis. We locate outputs by structural type rather than by
        # fixed history index so the verifier works for every K.
        doc_ids = None
        answer = None
        for prev in state.history:
            v = prev.value
            if isinstance(v, list) and v and isinstance(v[0], str):
                # Heuristic: a list of strings is the retriever's doc_ids
                # (the decomposer also produces a list of strings, but
                # those are sub-questions; we prefer the most recent
                # list-valued output, which will be the retriever's).
                doc_ids = v
            elif isinstance(v, str):
                # A string output is the reader's summary
                answer = v
        if doc_ids is None:
            raise RuntimeError(
                "Verifier requires a retriever upstream that produces a list "
                "of doc_ids in its history."
            )
        if answer is None:
            # No reader in the pipeline: substitute the concatenated evidence
            # snippets as the "answer" for the verifier prompt.
            answer = "(no intermediate summary; verdict computed directly from evidence)"

        context = self._assemble_context(doc_ids)
        prompt = VERIFY_PROMPT.format(
            context=context, query=state.query, answer=answer
        )

        # Sample n times at low-moderate temperature to estimate label
        # probabilities. The prompt asks for brief reasoning followed
        # by 'VERDICT: <LABEL>' on the last line, so we need enough
        # num_predict tokens to fit that pattern (64 is a safe margin).
        # Temperature 0.3 (lowered from 0.7) concentrates the distribution
        # on the model's actual prediction, reducing the diffuse
        # behaviour observed with llama3.1:8b on this task. The parser
        # downstream extracts the label from anywhere in the output.
        samples = self.client.generate_samples(
            model=self.model,
            prompt=prompt,
            n=self.n_samples,
            temperature=0.3,
            num_predict=64,
        )
        label_counts = {lab: 0 for lab in VERIFIER_LABELS}
        parse_failures = 0
        for s in samples:
            parsed = _parse_verdict_label(s.text)
            if parsed is None:
                parse_failures += 1
                continue
            label_counts[parsed] += 1

        total = sum(label_counts.values())
        if total == 0:
            # Every sample failed to parse: fall back to uniform
            # probability (maximum entropy). This is better than
            # returning an all-zero distribution which would break
            # downstream APS computation.
            probs = {lab: 0.25 for lab in VERIFIER_LABELS}
            predicted_label = "NOT_ENOUGH_EVIDENCE"
        else:
            probs = {lab: label_counts[lab] / total for lab in VERIFIER_LABELS}
            predicted_label = max(probs.items(), key=lambda kv: kv[1])[0]

        score: Optional[float] = None
        gold_verdict_raw = state.gold.get("verdict")
        if gold_verdict_raw is not None:
            # The gold verdict is in AVeriTeC canonical form ("Supported"
            # etc.); map it to the verifier's SCREAMING_CASE label space
            # before computing the non-conformity score.
            if gold_verdict_raw in VERIFIER_LABELS:
                gold_verdict = gold_verdict_raw
            else:
                gold_verdict = averitec_label_to_verifier(gold_verdict_raw)
            if self.score_fn == "aps":
                from .scores import adaptive_prediction_set_score
                score = adaptive_prediction_set_score(probs, gold_verdict)
            elif self.score_fn == "disagreement_rate":
                from .scores import disagreement_rate_score
                score = disagreement_rate_score(label_counts, gold_verdict)
            elif self.score_fn == "margin":
                from .scores import margin_score
                score = margin_score(label_counts, gold_verdict)

        return ModuleOutput(
            value=predicted_label,
            score=score,
            aux={
                "probs": {str(k): float(v) for k, v in probs.items()},
                "label_counts": {str(k): int(v.item() if hasattr(v, "item") else v)
                                 for k, v in label_counts.items()},
                "n_samples": int(total),
                "parse_failures": int(parse_failures),
                "score_fn": str(self.score_fn),
            },
        )

    def _assemble_context(self, doc_ids: Sequence[str], max_docs: int = 5) -> str:
        chunks = []
        for doc_id in list(doc_ids)[:max_docs]:
            text = self.corpus_lookup.get(doc_id, "")
            if text:
                chunks.append(f"[{doc_id}] {text}")
        return "\n\n".join(chunks)


# ========== pipeline orchestrator =================================== #

class AgenticRAGPipeline:
    """Sequential orchestrator for an agentic RAG pipeline.

    The orchestrator is configuration-agnostic: it accepts an ordered
    list of modules with stable identifier strings and runs them in
    sequence, threading state and history. This flexibility supports
    the ablation experiments of Section 6 of the paper, in which the
    pipeline is instantiated at three different lengths:

      * K=2:  retrieval + verifier        (minimal fact-checker)
      * K=3:  decomposer + retrieval + verifier
      * K=4:  full pipeline (decomposer + retrieval + reader + verifier)

    M2 (retrieval) and M4 (verifier) are always present because they
    are structurally required: M2 produces the evidence on which the
    task is based, M4 produces the verdict that defines task success.
    """

    def __init__(self, modules: Sequence[tuple[str, Any]]) -> None:
        """Initialise from an ordered list of (module_id, module) pairs.

        Parameters
        ----------
        modules
            Ordered sequence of pairs. The first element is a stable
            identifier string (e.g. ``"M1_decomposer"``) used for
            calibration record bookkeeping; the second is a module
            instance exposing a ``run(state) -> ModuleOutput`` method.
        """
        if not modules:
            raise ValueError("AgenticRAGPipeline requires at least one module")
        self.module_ids: list[str] = [mid for mid, _ in modules]
        self.modules: list[Any] = [m for _, m in modules]

    @property
    def K(self) -> int:
        return len(self.modules)

    def run(self, query: str, gold: Optional[dict[str, Any]] = None) -> PipelineState:
        import logging
        import time
        log = logging.getLogger(__name__)
        state = PipelineState(query=query, gold=gold or {})
        timings = []
        for k, module in enumerate(self.modules):
            t0 = time.time()
            out = module.run(state)
            dt = time.time() - t0
            timings.append((k + 1, self.module_ids[k], dt))
            state.history.append(out)
        summary = " | ".join(f"{mid}:{dt:.1f}s" for _, mid, dt in timings)
        log.debug("pipeline timings: %s", summary)
        state.timings = timings
        return state
