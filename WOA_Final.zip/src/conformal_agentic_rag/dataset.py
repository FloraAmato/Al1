"""
AVeriTeC dataset loader.

The AVeriTeC dataset (Schlichtkrull et al., NeurIPS 2023 Datasets &
Benchmarks Track) contains 4,568 real-world claims collected from 50
fact-checking organisations. Each claim is annotated with:

    - A verdict label in {Supported, Refuted, Not Enough Evidence,
      Conflicting Evidence/Cherrypicking}
    - A set of question-answer pairs representing the evidence
    - URLs pointing to the source of each answer
    - A textual justification

This loader maps the raw AVeriTeC schema onto our QAItem schema:

    QAItem.query          <- claim text
    QAItem.answer         <- verdict label (categorical)
    QAItem.sub_questions  <- list of gold questions (for M1 score)
    QAItem.doc_ids        <- list of gold source URLs (for M2 score)
    QAItem.verdict        <- same as answer, kept for uniformity with M4
    QAItem.n_hops         <- number of Q&A pairs
    QAItem.source         <- "averitec"

Download instructions:
    Dev and train splits: https://fever.ai/dataset/averitec.html
    Or via GitHub:  https://github.com/MichSchli/AVeriTeC

Place the JSON files under data/averitec/{train.json, dev.json, test.json}.
"""

from __future__ import annotations

import json
import logging
import random
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


# AVeriTeC verdict label set (the four classes)
AVERITEC_LABELS = (
    "Supported",
    "Refuted",
    "Not Enough Evidence",
    "Conflicting Evidence/Cherrypicking",
)

# Normalised forms (lowercase, no punctuation) for robust label matching
_LABEL_NORMAL_MAP = {
    "supported": "Supported",
    "support": "Supported",
    "refuted": "Refuted",
    "refute": "Refuted",
    "not enough evidence": "Not Enough Evidence",
    "nei": "Not Enough Evidence",
    "conflicting evidence/cherrypicking": "Conflicting Evidence/Cherrypicking",
    "conflicting evidence": "Conflicting Evidence/Cherrypicking",
    "cherrypicking": "Conflicting Evidence/Cherrypicking",
    "conflicting": "Conflicting Evidence/Cherrypicking",
}


def normalise_label(raw: str) -> Optional[str]:
    """Normalise an AVeriTeC label to one of AVERITEC_LABELS, or None."""
    if not isinstance(raw, str):
        return None
    key = re.sub(r"\s+", " ", raw.strip().lower()).strip(" .")
    return _LABEL_NORMAL_MAP.get(key)


# ========== item schema ============================================= #

@dataclass
class QAItem:
    id: str
    query: str                             # the claim text
    answer: str                            # verdict label
    sub_questions: list[str] = field(default_factory=list)
    doc_ids: list[str] = field(default_factory=list)
    verdict: str = "Supported"
    n_hops: int = 1
    source: str = "averitec"

    # AVeriTeC-specific extras, preserved for context and prompting
    evidence_answers: list[str] = field(default_factory=list)
    justification: str = ""
    speaker: str = ""
    claim_date: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "QAItem":
        return cls(
            id=d["id"],
            query=d["query"],
            answer=d["answer"],
            sub_questions=list(d.get("sub_questions", [])),
            doc_ids=list(d.get("doc_ids", [])),
            verdict=d.get("verdict", d.get("answer", "Supported")),
            n_hops=int(d.get("n_hops", 1)),
            source=d.get("source", "averitec"),
            evidence_answers=list(d.get("evidence_answers", [])),
            justification=d.get("justification", ""),
            speaker=d.get("speaker", ""),
            claim_date=d.get("claim_date", ""),
        )


# ========== persistence ============================================= #

def save_dataset(items: list[QAItem], path: Path | str) -> None:
    Path(path).write_text(
        json.dumps([it.to_dict() for it in items], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def load_dataset(path: Path | str) -> list[QAItem]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [QAItem.from_dict(d) for d in data]


# ========== AVeriTeC loader ========================================= #

def _url_to_doc_id(url: str) -> str:
    """
    Turn a source URL into a stable document identifier for retrieval.

    The retriever operates on a corpus indexed by doc_id. We use the
    normalised URL (scheme + netloc + path) so that two different query
    strings to the same resource collapse to the same doc_id.
    """
    if not url:
        return ""
    try:
        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        return base.rstrip("/")
    except Exception:
        return url


def load_averitec(
    path: Path | str,
    max_items: Optional[int] = None,
    skip_incomplete: bool = True,
) -> list[QAItem]:
    """
    Load an AVeriTeC split (dev, train, or test) into QAItems.

    Parameters
    ----------
    path : path to the AVeriTeC .json file (a JSON array of claim objects).
    max_items : truncate after N items (useful for pilots).
    skip_incomplete : drop items missing required fields (claim, label,
        or questions).

    The official AVeriTeC test split has no `label` field (withheld);
    passing skip_incomplete=True excludes those automatically.
    """
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError(f"Expected JSON array at {path}, got {type(raw).__name__}")

    items: list[QAItem] = []
    skipped = 0
    for idx, obj in enumerate(raw):
        claim = obj.get("claim", "").strip()
        label_raw = obj.get("label", "")
        questions = obj.get("questions", [])

        if skip_incomplete and (not claim or not label_raw or not questions):
            skipped += 1
            continue

        label = normalise_label(label_raw)
        if skip_incomplete and label is None:
            logger.warning("Unknown label %r at item %d; skipping", label_raw, idx)
            skipped += 1
            continue

        sub_questions: list[str] = []
        evidence_answers: list[str] = []
        doc_ids: list[str] = []

        for q_obj in questions:
            if not isinstance(q_obj, dict):
                continue
            q_text = q_obj.get("question", "")
            if isinstance(q_text, str) and q_text.strip():
                sub_questions.append(q_text.strip())

            for a_obj in q_obj.get("answers", []):
                if not isinstance(a_obj, dict):
                    continue
                a_text = a_obj.get("answer", "")
                if isinstance(a_text, str) and a_text.strip():
                    evidence_answers.append(a_text.strip())
                src = a_obj.get("source_url", "")
                doc_id = _url_to_doc_id(src)
                if doc_id and doc_id not in doc_ids:
                    doc_ids.append(doc_id)

        items.append(QAItem(
            id=f"averitec_{idx:05d}",
            query=claim,
            answer=label or "Supported",
            sub_questions=sub_questions,
            doc_ids=doc_ids,
            verdict=label or "Supported",
            n_hops=max(1, len(sub_questions)),
            source="averitec",
            evidence_answers=evidence_answers,
            justification=obj.get("justification", ""),
            speaker=obj.get("speaker", ""),
            claim_date=obj.get("claim_date", ""),
        ))

        if max_items is not None and len(items) >= max_items:
            break

    logger.info("Loaded %d AVeriTeC items from %s (skipped %d)",
                len(items), path, skipped)
    return items


# ========== label distribution analytics ============================ #

def label_distribution(items: list[QAItem]) -> dict[str, int]:
    counts: dict[str, int] = {lab: 0 for lab in AVERITEC_LABELS}
    for it in items:
        counts[it.answer] = counts.get(it.answer, 0) + 1
    return counts


# ========== train / cal / test split ================================ #

def split_dataset(
    items: list[QAItem],
    n_cal: int,
    n_test: int,
    random_state: int = 42,
    stratify: bool = True,
) -> tuple[list[QAItem], list[QAItem]]:
    """
    Produce an exchangeable calibration/test split.

    If stratify=True (default), each label class is split proportionally
    between calibration and test, preserving the marginal label
    distribution.
    """
    rng = random.Random(random_state)
    if not stratify:
        indices = list(range(len(items)))
        rng.shuffle(indices)
        if n_cal + n_test > len(items):
            raise ValueError(
                f"Requested {n_cal + n_test} items but only {len(items)} available."
            )
        cal_idx = indices[:n_cal]
        test_idx = indices[n_cal : n_cal + n_test]
        return [items[i] for i in cal_idx], [items[i] for i in test_idx]

    # Stratified split
    by_label: dict[str, list[int]] = {}
    for i, it in enumerate(items):
        by_label.setdefault(it.answer, []).append(i)

    total = len(items)
    cal_idx: list[int] = []
    test_idx: list[int] = []
    for label, idxs in by_label.items():
        rng.shuffle(idxs)
        proportion = len(idxs) / total
        n_cal_lab = max(1, int(round(n_cal * proportion)))
        n_test_lab = max(1, int(round(n_test * proportion)))
        if n_cal_lab + n_test_lab > len(idxs):
            half = len(idxs) // 2
            n_cal_lab = half
            n_test_lab = len(idxs) - half
        cal_idx.extend(idxs[:n_cal_lab])
        test_idx.extend(idxs[n_cal_lab : n_cal_lab + n_test_lab])

    rng.shuffle(cal_idx)
    rng.shuffle(test_idx)
    return [items[i] for i in cal_idx], [items[i] for i in test_idx]
