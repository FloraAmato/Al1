"""
Non-conformity scores for the four pipeline modules.

Each module requires a score function s_k : (input, output) -> R that is
*larger* for less plausible pairs. These scores are then compared, at
calibration time, against their empirical (1 - alpha)-quantile to yield
prediction sets.

Module-to-score mapping (matches paper Section 6):

    M1 (query decomposer) : semantic_similarity_score
    M2 (retriever)        : reciprocal_rank_score
    M3 (reader)           : neg_log_prob_score  (white-box)
                            self_consistency_score (black-box fallback)
    M4 (verifier)         : least_ambiguous_set_score  (LAC / APS)
"""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np


# ========== M1: Query decomposer ==================================== #

def semantic_similarity_score(
    predicted_decomposition: Sequence[str],
    gold_decomposition: Sequence[str],
    embedder,
) -> float:
    """
    Non-conformity = 1 - mean pairwise cosine similarity between the
    predicted decomposition and the gold decomposition.

    Smaller similarity -> larger non-conformity -> less plausible.
    """
    if not predicted_decomposition or not gold_decomposition:
        return 1.0  # maximal non-conformity

    pred_vecs = np.stack([embedder(q) for q in predicted_decomposition])
    gold_vecs = np.stack([embedder(q) for q in gold_decomposition])

    pred_norm = pred_vecs / (np.linalg.norm(pred_vecs, axis=1, keepdims=True) + 1e-10)
    gold_norm = gold_vecs / (np.linalg.norm(gold_vecs, axis=1, keepdims=True) + 1e-10)

    # Best-match alignment: for each gold sub-question, take the most
    # similar predicted sub-question, then average.
    sim_matrix = pred_norm @ gold_norm.T            # (|pred|, |gold|)
    per_gold_max = sim_matrix.max(axis=0)            # (|gold|,)
    mean_sim = float(per_gold_max.mean())

    # Clip to [0, 1] to absorb numerical noise: cosine similarity is
    # mathematically in [-1, 1], so 1 - cos can in principle be in [0, 2].
    # In practice, for normalised text embeddings, similarities are
    # almost always non-negative; the clip just guards against floating
    # -point drift around the [0, 1] boundary.
    return float(np.clip(1.0 - mean_sim, 0.0, 1.0))


# ========== M2: Retriever =========================================== #

def reciprocal_rank_score(
    retrieved_doc_ids: Sequence[str],
    gold_doc_ids: Sequence[str],
) -> float:
    """
    Non-conformity = 1 - MRR over the gold documents.

    If the top retrieved list is (d1, d2, ...), the reciprocal rank of
    a gold doc d* is 1 / rank(d*). We average over the gold set.

    Score is in [0, 1]. Perfect retrieval -> 0.
    """
    if not gold_doc_ids:
        return 0.0
    rr_values: list[float] = []
    for gold in gold_doc_ids:
        try:
            rank = retrieved_doc_ids.index(gold) + 1
            rr_values.append(1.0 / rank)
        except ValueError:
            rr_values.append(0.0)
    mrr = float(np.mean(rr_values))
    return 1.0 - mrr


# ========== M3: Reader / Reasoner =================================== #

def neg_log_prob_score(token_logprobs: Sequence[float], length_norm: bool = True) -> float:
    """
    White-box non-conformity: negative log-probability of the gold answer.

    When length_norm=True, we normalise by the number of tokens to avoid
    penalising longer gold answers (standard in token-level CP for LLMs).

    This is the canonical score used in Quach et al. (ICLR 2024) and
    Kumar et al. (2023).
    """
    if not token_logprobs:
        return math.inf
    total_nll = -float(sum(token_logprobs))
    return total_nll / len(token_logprobs) if length_norm else total_nll


def self_consistency_score(
    samples: Sequence[str],
    equivalence_fn,
) -> float:
    """
    Black-box non-conformity based on sampling self-consistency
    (Wang et al., 2023; adapted for CP by Quach et al., 2024).

    Draws n samples, clusters by semantic equivalence, and returns
    1 - (size of majority cluster) / n. High non-conformity means the
    model is highly uncertain (samples disagree).

    equivalence_fn : (str, str) -> bool
        Pairwise semantic equivalence test (e.g. embedding similarity
        threshold, or an LLM judge).
    """
    if not samples:
        return 1.0

    # Greedy clustering by equivalence
    clusters: list[list[str]] = []
    for sample in samples:
        placed = False
        for cluster in clusters:
            if equivalence_fn(sample, cluster[0]):
                cluster.append(sample)
                placed = True
                break
        if not placed:
            clusters.append([sample])

    max_cluster = max(len(c) for c in clusters)
    return 1.0 - max_cluster / len(samples)


# ========== M4: Verifier ============================================ #

def least_ambiguous_set_score(probs: dict[str, float], true_label: str) -> float:
    """
    LAC (Least Ambiguous set-valued Classifier) non-conformity for the
    verifier, following Sadinle, Lei, Wasserman (2019).

    Score = 1 - P(true_label | x). Smaller model probability on the
    correct class -> higher non-conformity.
    """
    return 1.0 - float(probs.get(true_label, 0.0))


def adaptive_prediction_set_score(
    probs: dict[str, float],
    true_label: str,
) -> float:
    """
    APS non-conformity (Romano, Sesia, Candès, 2020): cumulative mass of
    classes ranked at least as likely as the true class.

    Yields smaller, more adaptive prediction sets than LAC but requires
    careful randomisation for exact coverage. Here we use the deterministic
    variant.
    """
    sorted_items = sorted(probs.items(), key=lambda kv: kv[1], reverse=True)
    cumulative = 0.0
    for label, p in sorted_items:
        cumulative += p
        if label == true_label:
            return cumulative
    return 1.0  # true_label not in probs


def disagreement_rate_score(
    label_counts: dict[str, int],
    true_label: str,
) -> float:
    """
    Disagreement-rate non-conformity for stochastic-LLM classifiers.

    Given N stochastic completions of an LLM verifier on the same input,
    aggregated as a count per parsed label, the score is

        s(x, y_true) = 1 - n_{y_true}(x) / N

    where n_{y_true}(x) is the number of completions whose parsed label
    matches y_true and N = sum(label_counts.values()).

    The score is in [0, 1] with N+1 possible distinct values, granular by
    construction. It is calibrated to a coverage event {true_label is the
    modal prediction with at least the calibrated minority share}, which
    composes with split conformal in the standard way under exchangeability.

    Rationale (paper Section 6): APS computes a cumulative softmax mass and
    saturates when the underlying classifier emits hard labels with little
    mass on non-modal classes - the regime in which a stochastic-LLM
    verifier operates. Disagreement-rate replaces cumulative softmax with
    sample-frequency disagreement, which is granular by construction and
    avoids the saturation pathology.
    """
    n_total = sum(label_counts.values())
    if n_total == 0:
        return 1.0
    n_match = label_counts.get(true_label, 0)
    return 1.0 - n_match / n_total


def margin_score(
    label_counts: dict[str, int],
    true_label: str,
) -> float:
    """
    Margin-based non-conformity (alternative non-saturating score, included
    for robustness comparison in the analysis).

    Score = (n_top1 - n_true) / N when y_true is not the modal prediction,
    else 0. Smaller scores indicate that the verifier confidently agrees
    with the gold; larger scores indicate confident disagreement.

    Note: this score is degenerate when y_true is the modal prediction
    (it returns 0 for all such cases), so it is more useful as a
    diagnostic of distribution shape than as a primary CP score.
    """
    n_total = sum(label_counts.values())
    if n_total == 0:
        return 1.0
    sorted_counts = sorted(label_counts.values(), reverse=True)
    n_top1 = sorted_counts[0]
    n_true = label_counts.get(true_label, 0)
    if n_true >= n_top1:
        return 0.0
    return (n_top1 - n_true) / n_total


# ========== quantile computation ==================================== #

def split_conformal_quantile(scores: Sequence[float], alpha: float) -> float:
    """
    Finite-sample-corrected (1 - alpha)-quantile of calibration scores.

    Implements the ceil((n+1)(1-alpha))/n empirical quantile, which
    yields the standard split-CP marginal coverage guarantee
    P(Y in C) >= 1 - alpha.
    """
    scores_array = np.sort(np.asarray(scores, dtype=float))
    n = len(scores_array)
    if n == 0:
        raise ValueError("Empty calibration scores")
    q_level = math.ceil((n + 1) * (1 - alpha)) / n
    if q_level > 1.0:
        return float(scores_array[-1])
    return float(np.quantile(scores_array, q_level, method="higher"))
