"""
Corpus construction utilities.

The cognitive-risk corpus is a list of (doc_id, text) pairs drawn from
three sources, concatenated and deduplicated:

  1. Wikipedia articles in the cognitive-science / decision-theory /
     risk-perception subgraph (seeded from a curated page list).
  2. Open-access papers from PMC/Frontiers/arXiv on cognitive-risk topics.
  3. Canonical review chapters (Kahneman-Tversky 1979, Slovic, Gigerenzer,
     Endsley) accessed through their open-access reprints.

For full reproducibility, the list of seed Wikipedia pages is pinned in
`configs/corpus_seed.txt` and the script `01_build_corpus.py` fetches
them via the Wikipedia REST API.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

logger = logging.getLogger(__name__)


@dataclass
class Document:
    doc_id: str
    title: str
    text: str
    source: str                    # "wikipedia" | "pmc" | "arxiv" | "canonical"

    def to_dict(self) -> dict:
        return {
            "doc_id": self.doc_id,
            "title": self.title,
            "text": self.text,
            "source": self.source,
        }


# ========== persistence ============================================= #

def save_corpus(docs: list[Document], path: Path | str) -> None:
    Path(path).write_text(
        json.dumps([d.to_dict() for d in docs], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def load_corpus(path: Path | str) -> list[Document]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [Document(**d) for d in data]


def corpus_to_lookup(docs: list[Document]) -> dict[str, str]:
    """Map doc_id -> text, used to assemble context in M3/M4."""
    return {d.doc_id: d.text for d in docs}


def corpus_as_pairs(docs: list[Document]) -> list[tuple[str, str]]:
    """Convert to the (doc_id, text) tuple list used by HybridRetriever."""
    return [(d.doc_id, d.text) for d in docs]


# ========== text cleaning =========================================== #

_WHITESPACE_RE = re.compile(r"\s+")
_CITATION_RE = re.compile(r"\[\d+\]")


def clean_text(raw: str, max_chars: Optional[int] = 4000) -> str:
    """Light normalisation: strip refs, collapse whitespace, truncate."""
    cleaned = _CITATION_RE.sub("", raw)
    cleaned = _WHITESPACE_RE.sub(" ", cleaned).strip()
    if max_chars is not None and len(cleaned) > max_chars:
        cleaned = cleaned[:max_chars]
    return cleaned


def chunk_document(
    text: str,
    chunk_size: int = 800,
    overlap: int = 100,
) -> Iterable[str]:
    """
    Split a long document into overlapping chunks for retrieval-friendly
    granularity. Yields chunks of ~chunk_size characters.
    """
    if len(text) <= chunk_size:
        yield text
        return
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_size)
        yield text[start:end]
        if end == len(text):
            break
        start = end - overlap
