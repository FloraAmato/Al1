"""Conformal Agentic RAG — reference implementation for the CEUR paper."""

__version__ = "0.2.0"
