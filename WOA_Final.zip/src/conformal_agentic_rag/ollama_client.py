"""
Thin wrapper around the Ollama HTTP API.

The key requirement for white-box conformal prediction is access to
per-token log-probabilities. Ollama exposes this via the /api/generate
endpoint with options.num_predict and raw=True; when logprobs are not
available for a given model, we fall back to a self-consistency score
based on sampling (à la Quach et al., ICLR 2024).

Typical usage:

    client = OllamaClient(host="http://localhost:11434")
    resp = client.generate(
        model="llama3.1:8b-instruct-q4_K_M",
        prompt="The capital of France is",
        options={"num_predict": 10, "temperature": 0.0},
    )
    print(resp["response"])          # decoded text
    print(resp["logprobs"])           # per-token logprobs (if available)
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)


@dataclass
class GenerationResult:
    """Container for a single Ollama generation result."""

    text: str
    logprobs: Optional[list[float]] = None        # per-token logprobs
    tokens: Optional[list[str]] = None            # decoded tokens
    total_nll: Optional[float] = None             # sum of -logprobs
    model: str = ""
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class EmbeddingResult:
    """Container for a single Ollama embedding result."""

    vector: list[float]
    model: str = ""


class OllamaClient:
    """
    Minimal HTTP client for Ollama.

    Thread-safe as long as you instantiate one client per thread; otherwise
    pass an explicit requests.Session.
    """

    def __init__(
        self,
        host: str = "http://localhost:11434",
        timeout: float = 300.0,
        session: Optional[requests.Session] = None,
    ) -> None:
        self.host = host.rstrip("/")
        self.timeout = timeout
        self.session = session or requests.Session()

    # ---- generation ---------------------------------------------------- #

    def generate(
        self,
        model: str,
        prompt: str,
        options: Optional[dict[str, Any]] = None,
        system: Optional[str] = None,
    ) -> GenerationResult:
        """
        Single-shot generation with optional logprob retrieval.

        The `options` dict is passed through to Ollama. Common keys:
            num_predict: int            # max tokens to generate
            temperature: float          # sampling temperature
            top_p: float
            logprobs: int               # number of top logprobs to return
        """
        payload: dict[str, Any] = {
            "model": model,
            "prompt": prompt,
            "stream": False,
        }
        if system is not None:
            payload["system"] = system
        if options is not None:
            payload["options"] = options

        url = f"{self.host}/api/generate"
        resp = self.session.post(url, json=payload, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()

        return self._parse_generation(data, model)

    def generate_samples(
        self,
        model: str,
        prompt: str,
        n: int = 10,
        temperature: float = 0.7,
        **options: Any,
    ) -> list[GenerationResult]:
        """
        Draw n independent samples for self-consistency scoring.

        Used when logprobs are unavailable (black-box fallback).
        """
        out: list[GenerationResult] = []
        for _ in range(n):
            r = self.generate(
                model=model,
                prompt=prompt,
                options={"temperature": temperature, **options},
            )
            out.append(r)
        return out

    # ---- embeddings ---------------------------------------------------- #

    def embed(self, model: str, text: str) -> EmbeddingResult:
        """Single-text embedding."""
        url = f"{self.host}/api/embeddings"
        payload = {"model": model, "prompt": text}
        resp = self.session.post(url, json=payload, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        return EmbeddingResult(vector=data["embedding"], model=model)

    # ---- internals ----------------------------------------------------- #

    @staticmethod
    def _parse_generation(data: dict[str, Any], model: str) -> GenerationResult:
        text = data.get("response", "")
        logprobs_field = data.get("logprobs")

        logprobs: Optional[list[float]] = None
        tokens: Optional[list[str]] = None
        total_nll: Optional[float] = None

        # Different Ollama versions return logprobs in slightly different shapes.
        # We defensively try the two common layouts.
        if isinstance(logprobs_field, dict) and "tokens" in logprobs_field:
            logprobs = logprobs_field.get("logprobs")
            tokens = logprobs_field.get("tokens")
        elif isinstance(logprobs_field, list) and logprobs_field:
            # List of {"token": "...", "logprob": -1.23} dicts
            try:
                tokens = [t["token"] for t in logprobs_field]
                logprobs = [t["logprob"] for t in logprobs_field]
            except (TypeError, KeyError):
                logger.debug("Unexpected logprobs format; skipping parse.")

        if logprobs:
            total_nll = -float(sum(logprobs))

        return GenerationResult(
            text=text,
            logprobs=logprobs,
            tokens=tokens,
            total_nll=total_nll,
            model=model,
            raw=data,
        )
