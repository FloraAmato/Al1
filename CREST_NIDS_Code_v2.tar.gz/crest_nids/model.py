"""
CREST-NIDS: Model Architecture
================================
Constraint-Regularized Embedding-Space Transformer
for Network Intrusion Detection

Modules:
  (A) FeatureEncoder       — 1D-CNN for packet/flow feature extraction
  (B) ConstraintField      — Geometric rule enforcement in latent space
  (C) BindingTransformer   — Role-filler attention + relational bottleneck
  (D) UncertaintyClassifier — Classification with open-set recognition

Reference equations map to the paper:
  Eq. 1: Constraint-field energy (single-premise)
  Eq. 2: Constraint-field energy (multi-premise)
  Eq. 3: Total constraint energy
  Eq. 4: Concept grounding
  Eq. 5: Binding-aware attention
  Eq. 6: Uncertainty score
  Eq. 7: Joint training objective
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Dict, Tuple, Optional

from config import (
    EncoderConfig, ConstraintFieldConfig,
    BindingTransformerConfig, ClassifierConfig, CRESTConfig
)
from rules import KnowledgeBase, SymbolicRule


# ═══════════════════════════════════════════════════════════
# MODULE A: 1D-CNN FEATURE ENCODER
# ═══════════════════════════════════════════════════════════

class FeatureEncoder(nn.Module):
    """
    1D-CNN encoder mapping raw network features to d-dimensional embeddings.

    Architecture follows [Tran et al., 2025] and [Nature Sci. Reports, 2025]:
    three convolutional layers with increasing channels, followed by
    adaptive pooling and a dense projection layer.

    Input:  x ∈ R^{batch × input_dim}
    Output: h ∈ R^{batch × embedding_dim}
    """

    def __init__(self, cfg: EncoderConfig):
        super().__init__()
        self.input_dim = cfg.input_dim
        self.embedding_dim = cfg.embedding_dim

        # Convolutional backbone
        layers = []
        in_ch = 1  # Treat features as single-channel 1D signal
        for out_ch in cfg.conv_channels:
            layers.extend([
                nn.Conv1d(in_ch, out_ch, kernel_size=cfg.kernel_size,
                          padding=cfg.kernel_size // 2),
                nn.BatchNorm1d(out_ch),
                nn.ReLU(inplace=True),
            ])
            in_ch = out_ch
        self.conv_backbone = nn.Sequential(*layers)

        # Adaptive pooling → fixed-size representation regardless of input_dim
        self.pool = nn.AdaptiveAvgPool1d(1)

        # Dense projection to embedding space
        self.projection = nn.Sequential(
            nn.Linear(cfg.conv_channels[-1], cfg.embedding_dim),
            nn.BatchNorm1d(cfg.embedding_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(cfg.dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (batch_size, input_dim) raw network features

        Returns:
            h: (batch_size, embedding_dim) latent embeddings
        """
        # Reshape: (B, D) → (B, 1, D) for 1D convolution
        h = x.unsqueeze(1)

        # Conv backbone: (B, 1, D) → (B, C_last, D)
        h = self.conv_backbone(h)

        # Pool: (B, C_last, D) → (B, C_last, 1) → (B, C_last)
        h = self.pool(h).squeeze(-1)

        # Project: (B, C_last) → (B, d)
        h = self.projection(h)

        return h


# ═══════════════════════════════════════════════════════════
# MODULE B: CONSTRAINT-FIELD REGULARIZER
# ═══════════════════════════════════════════════════════════

class PredicateHead(nn.Module):
    """
    A predicate-specific projection head.
    Maps embeddings to a predicate subspace for constraint evaluation.
    f_P: R^d → R^k
    """

    def __init__(self, embedding_dim: int, projection_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(embedding_dim, projection_dim),
            nn.ReLU(inplace=True),
            nn.Linear(projection_dim, projection_dim),
        )

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        return self.net(h)


class ConstraintField(nn.Module):
    """
    Constraint-Field Regularizer (Section III-B of paper).

    Replaces LTN fuzzy truth values with geometric constraints in
    embedding space. Each logical rule φ defines a distance-based
    energy penalty:

        E_φ(x) = max(0, ‖f_P(E(x)) − f_Q(E(x))‖ − ε_φ)   (Eq. 1)

    For exclusion rules, the constraint is inverted:
        E_φ(x) = max(0, margin − ‖f_P(E(x)) − f_Q(E(x))‖)

    Total energy over knowledge base Φ = {φ_1,...,φ_m}:
        E_total = (1/m) Σ_j (1/n_j) Σ_i E_φj(x_i)          (Eq. 3)
    """

    def __init__(self, cfg: ConstraintFieldConfig, knowledge_base: KnowledgeBase):
        super().__init__()
        self.cfg = cfg
        self.knowledge_base = knowledge_base
        self.rules = knowledge_base.get_rules()

        # Create a predicate projection head per unique class referenced in rules
        all_classes = set()
        for rule in self.rules:
            all_classes.update(rule.premise_classes)
            all_classes.update(rule.conclusion_classes)

        self.predicate_heads = nn.ModuleDict({
            str(c): PredicateHead(cfg.embedding_dim, cfg.projection_dim)
            for c in all_classes
        })

        # Learnable margins ε_φ for each rule (Eq. 1)
        self.margins = nn.ParameterDict({
            f"rule_{i}": nn.Parameter(torch.tensor(cfg.margin_init))
            for i in range(len(self.rules))
        })

        # Composition MLP for multi-premise rules (Eq. 2)
        self.composition_mlp = nn.Sequential(
            nn.Linear(cfg.projection_dim * 2, cfg.projection_dim),
            nn.ReLU(inplace=True),
            nn.Linear(cfg.projection_dim, cfg.projection_dim),
        )

        self.distance_metric = cfg.distance_metric

    def _compute_distance(self, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        """Compute distance between projection vectors."""
        if self.distance_metric == "cosine":
            # Cosine distance: 1 - cos_sim
            sim = F.cosine_similarity(a, b, dim=-1)
            return 1.0 - sim
        else:
            # Euclidean distance
            return torch.norm(a - b, p=2, dim=-1)

    def _get_class_embeddings(
        self, h: torch.Tensor, labels: torch.Tensor, class_indices: List[int]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Extract embeddings for samples belonging to specified classes.

        Returns:
            embeddings: (N_match, d) subset of h
            mask: (B,) boolean mask
        """
        mask = torch.zeros(h.size(0), dtype=torch.bool, device=h.device)
        for cls_idx in class_indices:
            mask |= (labels == cls_idx)
        return h[mask], mask

    def compute_rule_energy(
        self, rule_idx: int, rule: SymbolicRule,
        h: torch.Tensor, labels: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute constraint-field energy for a single rule.

        For implication/hierarchy rules (P → Q):
            Samples of premise classes should be CLOSE to conclusion class projections.
            E = max(0, dist(f_P(h), f_Q(h)) − ε)

        For exclusion rules (P → ¬Q):
            Samples of class_a should be FAR from class_b projections.
            E = max(0, margin − dist(f_A(h), f_B(h)))
        """
        margin = torch.clamp(
            self.margins[f"rule_{rule_idx}"],
            min=self.cfg.margin_min, max=self.cfg.margin_max
        )

        if rule.rule_type in ("implication", "hierarchy"):
            # Get premise-class samples
            h_premise, mask_p = self._get_class_embeddings(
                h, labels, rule.premise_classes
            )
            if h_premise.size(0) == 0:
                return torch.tensor(0.0, device=h.device)

            # Project through premise and conclusion heads
            # For multi-class rules, use mean projection of all premise heads
            premise_projs = []
            for cls_idx in rule.premise_classes:
                if str(cls_idx) in self.predicate_heads:
                    premise_projs.append(
                        self.predicate_heads[str(cls_idx)](h_premise)
                    )
            if not premise_projs:
                return torch.tensor(0.0, device=h.device)
            f_premise = torch.stack(premise_projs).mean(dim=0)

            conclusion_projs = []
            for cls_idx in rule.conclusion_classes:
                if str(cls_idx) in self.predicate_heads:
                    conclusion_projs.append(
                        self.predicate_heads[str(cls_idx)](h_premise)
                    )
            if not conclusion_projs:
                return torch.tensor(0.0, device=h.device)
            f_conclusion = torch.stack(conclusion_projs).mean(dim=0)

            # Eq. 1: E_φ(x) = max(0, dist − ε)
            dist = self._compute_distance(f_premise, f_conclusion)
            energy = F.relu(dist - margin)
            return energy.mean()

        elif rule.rule_type == "exclusion":
            # Get samples from both class groups
            h_a, mask_a = self._get_class_embeddings(
                h, labels, rule.premise_classes
            )
            h_b, mask_b = self._get_class_embeddings(
                h, labels, rule.conclusion_classes
            )
            if h_a.size(0) == 0 or h_b.size(0) == 0:
                return torch.tensor(0.0, device=h.device)

            # Project both groups through their respective heads
            projs_a = []
            for cls_idx in rule.premise_classes:
                if str(cls_idx) in self.predicate_heads:
                    projs_a.append(
                        self.predicate_heads[str(cls_idx)](h_a)
                    )
            f_a = torch.stack(projs_a).mean(dim=0) if projs_a else h_a

            projs_b = []
            for cls_idx in rule.conclusion_classes:
                if str(cls_idx) in self.predicate_heads:
                    projs_b.append(
                        self.predicate_heads[str(cls_idx)](h_b)
                    )
            f_b = torch.stack(projs_b).mean(dim=0) if projs_b else h_b

            # Sample-level pairwise exclusion (not just centroids)
            # Pick random subset to keep computation tractable
            max_pairs = 128
            n_a = min(f_a.size(0), max_pairs)
            n_b = min(f_b.size(0), max_pairs)
            idx_a = torch.randperm(f_a.size(0), device=h.device)[:n_a]
            idx_b = torch.randperm(f_b.size(0), device=h.device)[:n_b]
            sampled_a = f_a[idx_a]  # (n_a, k)
            sampled_b = f_b[idx_b]  # (n_b, k)

            # Compute all pairwise distances
            # sampled_a: (n_a, 1, k), sampled_b: (1, n_b, k)
            if self.distance_metric == "cosine":
                a_norm = F.normalize(sampled_a, dim=-1)
                b_norm = F.normalize(sampled_b, dim=-1)
                sim = torch.mm(a_norm, b_norm.T)  # (n_a, n_b)
                pairwise_dist = 1.0 - sim
            else:
                diff = sampled_a.unsqueeze(1) - sampled_b.unsqueeze(0)
                pairwise_dist = torch.norm(diff, p=2, dim=-1)

            # Exclusion: penalize when distance is BELOW margin (too close)
            # Use max(margin, 1.0) to ensure exclusion rules push hard
            excl_margin = torch.clamp(margin, min=1.0)
            energy = F.relu(excl_margin - pairwise_dist)
            return energy.mean()

        return torch.tensor(0.0, device=h.device)

    def forward(
        self, h: torch.Tensor, labels: torch.Tensor
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute total constraint-field energy (Eq. 3).

        Args:
            h: (B, d) embeddings from encoder
            labels: (B,) integer class labels

        Returns:
            E_total: scalar total constraint energy
            rule_energies: dict mapping rule names to their individual energies
        """
        total_energy = torch.tensor(0.0, device=h.device)
        rule_energies = {}
        active_rules = 0

        for i, rule in enumerate(self.rules):
            energy = self.compute_rule_energy(i, rule, h, labels)
            rule_energies[rule.name] = energy.item()
            if energy.item() > 0 or True:  # Always count for averaging
                total_energy = total_energy + energy
                active_rules += 1

        if active_rules > 0:
            total_energy = total_energy / active_rules

        return total_energy, rule_energies

    def compute_sample_energy(self, h: torch.Tensor) -> torch.Tensor:
        """
        Compute per-sample constraint energy (for uncertainty estimation, Eq. 6).

        Uses min-distance to predicate centroids: samples far from all
        learned predicate projections get high energy → flagged as unknown.

        Args:
            h: (B, d) embeddings

        Returns:
            energies: (B,) per-sample energy values
        """
        all_projections = []
        for key, head in self.predicate_heads.items():
            all_projections.append(head(h))

        if not all_projections:
            return torch.zeros(h.size(0), device=h.device)

        # Stack: (num_heads, B, k)
        projs = torch.stack(all_projections, dim=0)

        # Compute centroid of each predicate head's projection
        centroids = projs.mean(dim=1)  # (num_heads, k)

        # For each sample, compute distance to nearest centroid
        # projs: (num_heads, B, k) → (B, num_heads, k)
        projs_t = projs.permute(1, 0, 2)
        centroids_exp = centroids.unsqueeze(0).expand_as(projs_t)

        # Per-head distances: (B, num_heads)
        dists = torch.norm(projs_t - centroids_exp, p=2, dim=-1)

        # Min distance to any centroid — low = fits well, high = outlier
        min_dist = dists.min(dim=1).values  # (B,)

        # Also add projection variance as secondary signal
        variance = projs.var(dim=0).sum(dim=-1)  # (B,)

        # Combine both signals
        energy = 0.5 * min_dist + 0.5 * variance
        return energy


# ═══════════════════════════════════════════════════════════
# MODULE C: BINDING-AWARE TRANSFORMER
# ═══════════════════════════════════════════════════════════

class ConceptGroundingLayer(nn.Module):
    """
    Maps continuous embeddings to distributions over a finite
    concept vocabulary (Eq. 4).

        c_i = softmax(W_c · h_i / τ)

    This discretization bridges the neural-symbolic gap by creating
    reusable compositional units.
    """

    def __init__(self, embedding_dim: int, vocab_size: int, temperature: float = 0.5):
        super().__init__()
        self.projection = nn.Linear(embedding_dim, vocab_size)
        self.temperature = temperature

    def forward(self, h: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            h: (B, d) embeddings

        Returns:
            concept_dist: (B, K) soft concept assignments
            concept_embed: (B, d) concept-enriched embeddings (residual)
        """
        logits = self.projection(h) / self.temperature
        concept_dist = F.softmax(logits, dim=-1)  # (B, K)

        # Concept-enriched embedding via soft attention over concept codebook
        # concept_dist: (B, K), projection.weight: (K, d) → result: (B, d)
        concept_embed = h + concept_dist @ self.projection.weight  # (B, d)

        return concept_dist, concept_embed


class BindingAttention(nn.Module):
    """
    Binding-Aware Multi-Head Attention (Eq. 5).

    Decomposes attention into:
      - Role heads: Q_r queries symbolic roles (source, dest, protocol, alert)
      - Filler heads: K_f, V_f encode entity fillers
      - Standard heads: Regular self-attention for non-symbolic features

    BindAttn(Q_r, K_f, V_f) = softmax(Q_r K_f^T / √d) V_f

    The binding matrix B_t is regularized toward orthogonality to ensure
    clean role-filler separation: L_bind = ‖B_t^T B_t − I‖²_F
    """

    def __init__(
        self, embedding_dim: int, num_heads: int,
        num_role_heads: int, dropout: float = 0.1
    ):
        super().__init__()
        assert embedding_dim % num_heads == 0
        assert num_role_heads <= num_heads

        self.embedding_dim = embedding_dim
        self.num_heads = num_heads
        self.num_role_heads = num_role_heads
        self.num_standard_heads = num_heads - num_role_heads
        self.head_dim = embedding_dim // num_heads

        # Role-specific projections (for binding heads)
        self.W_role_q = nn.Linear(embedding_dim, num_role_heads * self.head_dim)
        self.W_filler_k = nn.Linear(embedding_dim, num_role_heads * self.head_dim)
        self.W_filler_v = nn.Linear(embedding_dim, num_role_heads * self.head_dim)

        # Standard attention projections (for non-binding heads)
        if self.num_standard_heads > 0:
            self.W_q = nn.Linear(embedding_dim, self.num_standard_heads * self.head_dim)
            self.W_k = nn.Linear(embedding_dim, self.num_standard_heads * self.head_dim)
            self.W_v = nn.Linear(embedding_dim, self.num_standard_heads * self.head_dim)

        # Output projection
        self.W_out = nn.Linear(embedding_dim, embedding_dim)
        self.dropout = nn.Dropout(dropout)
        self.scale = math.sqrt(self.head_dim)

        # Store binding matrices for regularization
        self._binding_matrix = None

    def forward(self, h: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            h: (B, d) embeddings (we treat each sample as a single token)
               For sequence processing, reshape to (B, S, d) before calling

        Returns:
            output: (B, d) attention output
            binding_matrix: (B, num_role_heads, head_dim, head_dim) for regularization
        """
        B = h.size(0)

        # For tabular data: treat as sequence of length 1
        # We create a pseudo-sequence by chunking the embedding
        S = max(1, self.embedding_dim // (self.head_dim * 2))
        chunk_dim = self.embedding_dim // S
        h_seq = h.view(B, S, chunk_dim)

        # Pad if needed to match embedding_dim
        if chunk_dim * S < self.embedding_dim:
            h_seq = h.unsqueeze(1)  # (B, 1, d)
            S = 1

        outputs = []

        # ── Binding attention heads ──
        Q_r = self.W_role_q(h).view(B, self.num_role_heads, self.head_dim)
        K_f = self.W_filler_k(h).view(B, self.num_role_heads, self.head_dim)
        V_f = self.W_filler_v(h).view(B, self.num_role_heads, self.head_dim)

        # Attention: (B, num_role_heads, head_dim) × (B, num_role_heads, head_dim)^T
        # For single-token, this produces binding coefficients
        attn_scores = torch.bmm(
            Q_r.view(B * self.num_role_heads, 1, self.head_dim),
            K_f.view(B * self.num_role_heads, self.head_dim, 1)
        ).view(B, self.num_role_heads) / self.scale

        attn_weights = F.softmax(attn_scores, dim=-1)  # (B, num_role_heads)
        attn_weights = self.dropout(attn_weights)

        # Weighted filler values
        bind_out = V_f * attn_weights.unsqueeze(-1)  # (B, num_role_heads, head_dim)

        # Store binding matrix B_t for regularization (Eq. 7: L_bind)
        # B_t = Q_r^T · K_f (per sample)
        binding_matrix = torch.bmm(
            Q_r.transpose(1, 2),  # (B, head_dim, num_role_heads)
            K_f                    # (B, num_role_heads, head_dim)
        )  # (B, head_dim, head_dim)
        self._binding_matrix = binding_matrix

        bind_out_flat = bind_out.reshape(B, self.num_role_heads * self.head_dim)
        outputs.append(bind_out_flat)

        # ── Standard attention heads ──
        if self.num_standard_heads > 0:
            Q = self.W_q(h).view(B, self.num_standard_heads, self.head_dim)
            K = self.W_k(h).view(B, self.num_standard_heads, self.head_dim)
            V = self.W_v(h).view(B, self.num_standard_heads, self.head_dim)

            std_scores = (Q * K).sum(dim=-1) / self.scale  # (B, num_standard_heads)
            std_weights = F.softmax(std_scores, dim=-1)
            std_weights = self.dropout(std_weights)

            std_out = V * std_weights.unsqueeze(-1)
            std_out_flat = std_out.reshape(B, self.num_standard_heads * self.head_dim)
            outputs.append(std_out_flat)

        # Concatenate all heads
        combined = torch.cat(outputs, dim=-1)  # (B, d)
        output = self.W_out(combined)

        return output, binding_matrix

    def get_binding_matrix(self) -> Optional[torch.Tensor]:
        return self._binding_matrix


class RelationalBottleneck(nn.Module):
    """
    Relational Bottleneck following the Abstractor architecture [Altabaa et al., 2023].

    Compresses pairwise relations through a low-rank bottleneck,
    forcing abstraction of relational patterns away from object-level features.
    This encourages learning reusable attack-pattern templates.
    """

    def __init__(self, embedding_dim: int, bottleneck_dim: int):
        super().__init__()
        self.relation_encoder = nn.Sequential(
            nn.Linear(embedding_dim * 2, bottleneck_dim),
            nn.ReLU(inplace=True),
        )
        self.relation_decoder = nn.Sequential(
            nn.Linear(bottleneck_dim, embedding_dim),
            nn.ReLU(inplace=True),
        )
        # Self-relation (single-sample case for tabular data)
        self.self_relation = nn.Sequential(
            nn.Linear(embedding_dim, bottleneck_dim),
            nn.ReLU(inplace=True),
            nn.Linear(bottleneck_dim, embedding_dim),
        )

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        """
        Args:
            h: (B, d) embeddings

        Returns:
            h_relational: (B, d) relationally-enriched embeddings
        """
        # For tabular (non-sequential) data, use self-relation encoding
        # This compresses the embedding through the bottleneck
        # to force relational abstraction
        rel = self.self_relation(h)

        # For batch-level relations (inter-sample):
        # Compute mean relation with batch centroid
        centroid = h.mean(dim=0, keepdim=True)  # (1, d)
        pair_input = torch.cat([h, centroid.expand_as(h)], dim=-1)  # (B, 2d)
        batch_rel = self.relation_decoder(self.relation_encoder(pair_input))

        # Combine self and batch relations
        return h + 0.5 * rel + 0.5 * batch_rel


class BindingTransformerLayer(nn.Module):
    """Single layer of the Binding-Aware Transformer."""

    def __init__(self, cfg: BindingTransformerConfig):
        super().__init__()
        self.binding_attention = BindingAttention(
            cfg.embedding_dim, cfg.num_heads,
            cfg.num_role_heads, cfg.dropout
        )
        self.relational_bottleneck = RelationalBottleneck(
            cfg.embedding_dim, cfg.bottleneck_dim
        )
        self.ff = nn.Sequential(
            nn.Linear(cfg.embedding_dim, cfg.ff_dim),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.ff_dim, cfg.embedding_dim),
            nn.Dropout(cfg.dropout),
        )
        self.norm1 = nn.LayerNorm(cfg.embedding_dim)
        self.norm2 = nn.LayerNorm(cfg.embedding_dim)
        self.norm3 = nn.LayerNorm(cfg.embedding_dim)

    def forward(
        self, h: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # Binding attention + residual
        attn_out, binding_matrix = self.binding_attention(h)
        h = self.norm1(h + attn_out)

        # Relational bottleneck + residual
        rel_out = self.relational_bottleneck(h)
        h = self.norm2(h + rel_out)

        # Feed-forward + residual
        h = self.norm3(h + self.ff(h))

        return h, binding_matrix


class BindingTransformer(nn.Module):
    """
    Full Binding-Aware Transformer Module (Section III-C).

    Stacks:
    1. Concept grounding layer (Eq. 4)
    2. N × BindingTransformerLayer (binding attention + relational bottleneck)
    """

    def __init__(self, cfg: BindingTransformerConfig):
        super().__init__()
        self.concept_grounding = ConceptGroundingLayer(
            cfg.embedding_dim, cfg.concept_vocab_size, cfg.concept_temperature
        )
        self.layers = nn.ModuleList([
            BindingTransformerLayer(cfg) for _ in range(cfg.num_layers)
        ])

    def forward(
        self, h: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, List[torch.Tensor]]:
        """
        Args:
            h: (B, d) encoder embeddings

        Returns:
            h_out: (B, d) transformer output
            concept_dist: (B, K) concept assignments
            binding_matrices: list of binding matrices per layer
        """
        # Concept grounding
        concept_dist, h = self.concept_grounding(h)

        # Transformer layers
        binding_matrices = []
        for layer in self.layers:
            h, B_t = layer(h)
            binding_matrices.append(B_t)

        return h, concept_dist, binding_matrices


# ═══════════════════════════════════════════════════════════
# MODULE D: UNCERTAINTY-AWARE CLASSIFIER
# ═══════════════════════════════════════════════════════════

class UncertaintyClassifier(nn.Module):
    """
    Classification head with uncertainty estimation (Section III-D).

    Combines classification with open-set recognition via dual uncertainty:
        U(x) = α H(x) + (1−α) E_sample(x)         (Eq. 6)

    where H(x) is prediction entropy and E_sample(x) is per-sample
    constraint-field energy.
    """

    def __init__(self, cfg: ClassifierConfig):
        super().__init__()
        self.alpha = cfg.uncertainty_alpha
        self.osr_threshold = cfg.osr_threshold

        # Deeper classifier head for better minority class separation
        self.classifier = nn.Sequential(
            nn.Linear(cfg.embedding_dim, cfg.hidden_dim),
            nn.BatchNorm1d(cfg.hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(cfg.hidden_dim, cfg.hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(cfg.hidden_dim // 2, cfg.num_classes),
        )

        # Running statistics for energy normalization (more stable than batch max)
        self.register_buffer('energy_running_mean', torch.tensor(0.0))
        self.register_buffer('energy_running_std', torch.tensor(1.0))
        self.energy_momentum = 0.1

    def forward(
        self, h: torch.Tensor, constraint_energy: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            h: (B, d) transformer output embeddings
            constraint_energy: (B,) per-sample constraint energy (optional)

        Returns:
            dict with keys:
                logits: (B, C) raw classification logits
                probs: (B, C) softmax probabilities
                entropy: (B,) prediction entropy H(x)
                uncertainty: (B,) combined uncertainty U(x) (Eq. 6)
                osr_flag: (B,) boolean flags for open-set detection
        """
        logits = self.classifier(h)
        probs = F.softmax(logits, dim=-1)

        # Prediction entropy: H(x) = −Σ_k p_k log p_k
        entropy = -(probs * torch.log(probs + 1e-8)).sum(dim=-1)

        # Normalize entropy to [0, 1]
        max_entropy = math.log(logits.size(-1))
        entropy_norm = entropy / max_entropy

        # Combined uncertainty (Eq. 6)
        if constraint_energy is not None:
            # Update running statistics for stable normalization
            batch_mean = constraint_energy.mean().detach()
            batch_std = constraint_energy.std().detach() + 1e-8
            if self.training:
                self.energy_running_mean = (
                    (1 - self.energy_momentum) * self.energy_running_mean
                    + self.energy_momentum * batch_mean
                )
                self.energy_running_std = (
                    (1 - self.energy_momentum) * self.energy_running_std
                    + self.energy_momentum * batch_std
                )

            # Z-score normalize then sigmoid to [0, 1]
            e_zscore = (constraint_energy - self.energy_running_mean) / (self.energy_running_std + 1e-8)
            e_norm = torch.sigmoid(e_zscore)
            uncertainty = self.alpha * entropy_norm + (1 - self.alpha) * e_norm
        else:
            uncertainty = entropy_norm

        # Open-set recognition flag
        osr_flag = uncertainty > self.osr_threshold

        return {
            "logits": logits,
            "probs": probs,
            "entropy": entropy,
            "uncertainty": uncertainty,
            "osr_flag": osr_flag,
        }


# ═══════════════════════════════════════════════════════════
# FULL CREST-NIDS MODEL
# ═══════════════════════════════════════════════════════════

class CREST_NIDS(nn.Module):
    """
    CREST-NIDS: Constraint-Regularized Embedding-Space Transformer
    for Network Intrusion Detection.

    Full pipeline: Encoder → ConstraintField → BindingTransformer → Classifier

    Training objective (Eq. 7):
        L = L_CE + λ E_total + μ L_bind + ν L_cycle
    """

    def __init__(self, cfg: CRESTConfig, knowledge_base: KnowledgeBase):
        super().__init__()
        self.cfg = cfg

        # Module A: Feature Encoder
        self.encoder = FeatureEncoder(cfg.encoder)

        # Module B: Constraint-Field Regularizer
        self.constraint_field = ConstraintField(cfg.constraint, knowledge_base)

        # Module C: Binding-Aware Transformer
        self.binding_transformer = BindingTransformer(cfg.transformer)

        # Module D: Uncertainty-Aware Classifier
        self.classifier = UncertaintyClassifier(cfg.classifier)

    def forward(
        self, x: torch.Tensor, labels: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Full forward pass.

        Args:
            x: (B, input_dim) raw network features
            labels: (B,) class labels (required for constraint field during training)

        Returns:
            dict with all outputs + loss components
        """
        results = {}

        # (A) Encode
        h = self.encoder(x)
        results["embeddings"] = h

        # (B) Constraint-field energy
        if labels is not None:
            e_total, rule_energies = self.constraint_field(h, labels)
            results["constraint_energy_total"] = e_total
            results["rule_energies"] = rule_energies

        # Per-sample energy for uncertainty (always computed)
        sample_energy = self.constraint_field.compute_sample_energy(h)
        results["sample_energy"] = sample_energy

        # (C) Binding-Aware Transformer
        h_transformed, concept_dist, binding_matrices = \
            self.binding_transformer(h)
        results["transformed_embeddings"] = h_transformed
        results["concept_dist"] = concept_dist
        results["binding_matrices"] = binding_matrices

        # (D) Classification with uncertainty
        cls_output = self.classifier(h_transformed, sample_energy)
        results.update(cls_output)

        return results

    def compute_loss(
        self, results: Dict[str, torch.Tensor],
        labels: torch.Tensor, cfg: "TrainingConfig"
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute the full CREST-NIDS loss (Eq. 7).

        L = L_cls + λ E_total + μ L_bind + ν L_cycle

        Args:
            results: output dict from forward()
            labels: (B,) class labels
            cfg: TrainingConfig with loss weights
            current_epoch: current training epoch (for warmup)

        Returns:
            total_loss: scalar
            loss_components: dict of individual loss values
        """
        device = results["logits"].device
        logits = results["logits"]

        # L_cls: Classification loss (Focal Loss or Cross-Entropy)
        if hasattr(cfg, 'use_focal_loss') and cfg.use_focal_loss:
            # Focal Loss: FL(p_t) = -α_t (1-p_t)^γ log(p_t)
            # Helps with extreme class imbalance (11 Heartbleed in 2.8M rows)
            ce_loss = F.cross_entropy(logits, labels, reduction='none')
            pt = torch.exp(-ce_loss)  # p_t = probability of correct class
            gamma = getattr(cfg, 'focal_gamma', 2.0)
            alpha = getattr(cfg, 'focal_alpha', 0.25)
            focal_weight = alpha * (1 - pt) ** gamma
            l_ce = (focal_weight * ce_loss).mean()
        else:
            l_ce = F.cross_entropy(logits, labels)

        # Constraint warmup: ramp up λ over first N epochs
        warmup = getattr(cfg, 'constraint_warmup_epochs', 3)
        current_ep = getattr(self, '_current_epoch', 0)
        if current_ep < warmup:
            warmup_factor = current_ep / max(warmup, 1)
        else:
            warmup_factor = 1.0

        # λ · E_total: Constraint-field energy (Eq. 3)
        l_constraint = results.get(
            "constraint_energy_total",
            torch.tensor(0.0, device=device)
        )

        # μ · L_bind: Binding orthogonality regularization
        # L_bind = Σ_t ‖B_t^T B_t − I‖²_F
        l_bind = torch.tensor(0.0, device=device)
        binding_matrices = results.get("binding_matrices", [])
        for B_t in binding_matrices:
            if B_t is not None:
                BtB = torch.bmm(B_t.transpose(1, 2), B_t)
                I = torch.eye(
                    BtB.size(-1), device=device
                ).unsqueeze(0).expand_as(BtB)
                l_bind = l_bind + (BtB - I).pow(2).sum(dim=(-1, -2)).mean()

        # ν · L_cycle: Bind/Unbind cycle consistency
        h_orig = results["embeddings"]
        h_trans = results["transformed_embeddings"]
        l_cycle = F.mse_loss(h_trans, h_orig)

        # Total loss (Eq. 7) with warmup on constraint terms
        total_loss = (
            l_ce
            + cfg.lambda_constraint * warmup_factor * l_constraint
            + cfg.mu_binding * warmup_factor * l_bind
            + cfg.nu_cycle * l_cycle
        )

        loss_components = {
            "L_CE": l_ce.item(),
            "L_constraint": l_constraint.item(),
            "L_bind": l_bind.item(),
            "L_cycle": l_cycle.item(),
            "L_total": total_loss.item(),
            "warmup": warmup_factor,
        }

        return total_loss, loss_components

    def explain(
        self, x: torch.Tensor, labels: Optional[torch.Tensor] = None
    ) -> Dict[str, any]:
        """
        Generate interpretable explanations for predictions.

        Returns:
            - Predicted class with confidence
            - Concept activations
            - Rule satisfaction status
            - Uncertainty assessment
        """
        self.eval()
        with torch.no_grad():
            results = self.forward(x, labels)

        probs = results["probs"]
        pred_classes = probs.argmax(dim=-1)
        pred_conf = probs.max(dim=-1).values
        concept_dist = results["concept_dist"]
        uncertainty = results["uncertainty"]
        osr_flag = results["osr_flag"]

        explanations = {
            "predicted_class": pred_classes,
            "confidence": pred_conf,
            "top_concepts": concept_dist.topk(5, dim=-1),
            "uncertainty_score": uncertainty,
            "is_unknown_attack": osr_flag,
        }

        if labels is not None and "rule_energies" in results:
            rule_satisfaction = {
                name: "SATISFIED" if energy < 0.1 else f"VIOLATED (energy={energy:.3f})"
                for name, energy in results["rule_energies"].items()
            }
            explanations["rule_satisfaction"] = rule_satisfaction

        return explanations

    def count_parameters(self) -> Dict[str, int]:
        """Count trainable parameters per module."""
        modules = {
            "Encoder": self.encoder,
            "ConstraintField": self.constraint_field,
            "BindingTransformer": self.binding_transformer,
            "Classifier": self.classifier,
        }
        counts = {}
        total = 0
        for name, module in modules.items():
            n = sum(p.numel() for p in module.parameters() if p.requires_grad)
            counts[name] = n
            total += n
        counts["Total"] = total
        return counts
